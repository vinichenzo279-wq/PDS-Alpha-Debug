'use strict';
// node run_nohold.js scripts <out.jsonl> <seedStart> <count> [K]     -- generate scripts + exact optima (XI tier)
// node run_nohold.js presets <scripts.jsonl>                        -- evaluate PRESETS against cached optima
// node run_nohold.js fitweights <scripts.jsonl> <nVectors> [seed]   -- random-search weight vectors on cached optima
// node run_nohold.js full <out.jsonl> <seedStart> <count> [K]       -- FULL-23 tier: heuristic truth + presets
const fs=require('fs');
const S=require('./nohold_sim.js');

const mode=process.argv[2];

if(mode==='scripts'){
  const out=process.argv[3];
  const seedStart=parseInt(process.argv[4],10), count=parseInt(process.argv[5],10);
  const K=parseInt(process.argv[6]||'5',10);
  for(let i=0;i<count;i++){
    const seed=seedStart+i;
    const sc=S.generateDraftScript({seed, K, mode:'xi'});
    const t0=Date.now();
    const opt=S.optimalXiOnly(sc);
    // store the script compactly: per step, the option cards
    fs.appendFileSync(out, JSON.stringify({seed, K, formName:sc.formName,
      form:sc.form, steps:sc.steps.map(st=>({kind:st.kind,pos:st.pos,options:st.options})),
      optimal:opt.best, optCapped:opt.capped, optNodes:opt.nodes, optMs:Date.now()-t0})+'\n');
    console.log(`seed=${seed} form=${sc.formName} optimal=${opt.best} nodes=${opt.nodes} capped=${opt.capped} ms=${Date.now()-t0}`);
  }
}

function loadScripts(path){
  return fs.readFileSync(path,'utf8').trim().split('\n').filter(Boolean).map(l=>{
    const r=JSON.parse(l);
    r.mode='xi';
    return r;
  });
}

if(mode==='presets'){
  const rows=loadScripts(process.argv[3]).filter(r=>!r.optCapped);
  console.log(`scripts: ${rows.length} (uncapped exact optima only)`);
  const names=Object.keys(S.PRESETS);
  const stats={};
  for(const n of names) stats[n]={regrets:[], hits:0};
  for(const r of rows){
    for(const n of names){
      const scorer = S.PRESETS[n] ? S.makeWeightedScorer(S.PRESETS[n]) : S.makeRandomPicker(r.seed*7+13);
      const committed=S.playScript(r, scorer);
      const got=S.finalScore(r, committed);
      const reg=r.optimal-got;
      stats[n].regrets.push(reg);
      if(reg===0)stats[n].hits++;
    }
  }
  const pct=(v,p)=>{const s=v.slice().sort((a,b)=>a-b);const k=(s.length-1)*p;const f=Math.floor(k);return s[f]+(s[Math.min(f+1,s.length-1)]-s[f])*(k-f);};
  console.log(`\n${'strategy'.padEnd(14)} ${'meanReg'.padStart(8)} ${'medReg'.padStart(7)} ${'p90'.padStart(5)} ${'max'.padStart(4)} ${'optimal%'.padStart(9)}`);
  for(const n of names){
    const v=stats[n].regrets;
    const mean=v.reduce((a,b)=>a+b,0)/v.length;
    console.log(`${n.padEnd(14)} ${mean.toFixed(3).padStart(8)} ${pct(v,.5).toFixed(1).padStart(7)} ${pct(v,.9).toFixed(0).padStart(5)} ${Math.max(...v).toString().padStart(4)} ${(100*stats[n].hits/v.length).toFixed(1).padStart(8)}%`);
  }
}

if(mode==='fitweights'){
  const rows=loadScripts(process.argv[3]).filter(r=>!r.optCapped);
  const nVec=parseInt(process.argv[4]||'400',10);
  const rand=S.mulberry32(parseInt(process.argv[5]||'42',10));
  console.log(`fitting on ${rows.length} scripts x ${nVec} random weight vectors`);
  // search space: r fixed at 1 (scale anchor); others sampled
  const results=[];
  for(let v=0;v<nVec;v++){
    const w={
      r:1,
      newNat: rand()*3,             // 0..3 rating-points per new nation
      newClub: rand()*3,
      newLg: rand()*3,
      prem: rand()*1.5,             // 0..1.5 per prem-pool unit
      clash: -rand()*6,             // 0..-6 hard-clash penalty
      iconHero: (rand()*4)-2        // -2..+2 icon/hero bias
    };
    const scorer=S.makeWeightedScorer(w);
    let sum=0, hits=0;
    for(const r of rows){
      const got=S.finalScore(r, S.playScript(r, scorer));
      sum += r.optimal-got;
      if(got===r.optimal)hits++;
    }
    results.push({w, meanReg:sum/rows.length, hitPct:100*hits/rows.length});
  }
  results.sort((a,b)=>a.meanReg-b.meanReg);
  console.log('\nTOP 10 weight vectors:');
  for(const x of results.slice(0,10)){
    console.log(`meanReg=${x.meanReg.toFixed(3)} opt%=${x.hitPct.toFixed(1)} w=${JSON.stringify(Object.fromEntries(Object.entries(x.w).map(([k,v])=>[k,+v.toFixed(2)])))}`);
  }
  console.log('\nBOTTOM 3 (worst):');
  for(const x of results.slice(-3)){
    console.log(`meanReg=${x.meanReg.toFixed(3)} opt%=${x.hitPct.toFixed(1)} w=${JSON.stringify(Object.fromEntries(Object.entries(x.w).map(([k,v])=>[k,+v.toFixed(2)])))}`);
  }
  // per-weight marginal picture: correlation of each weight with meanReg among top half
  fs.writeFileSync('/home/claude/nohold_fit_results.json', JSON.stringify(results));
  console.log('\nsaved all vectors -> nohold_fit_results.json');
}

if(mode==='full'){
  const out=process.argv[3];
  const seedStart=parseInt(process.argv[4],10), count=parseInt(process.argv[5],10);
  const K=parseInt(process.argv[6]||'5',10);
  const presetNames=Object.keys(S.PRESETS);
  for(let i=0;i<count;i++){
    const seed=seedStart+i;
    const sc=S.generateDraftScript({seed, K, mode:'full'});
    const t0=Date.now();
    const truth=S.heuristicFull(sc,{timeBudgetMs:8000, seed:seed*31+7});
    const row={seed, K, formName:sc.formName, mode:'full', heuristicBest:truth.best, restarts:truth.restarts, presets:{}};
    for(const n of presetNames){
      const scorer=S.PRESETS[n]?S.makeWeightedScorer(S.PRESETS[n]):S.makeRandomPicker(seed*7+13);
      const got=S.finalScore(sc, S.playScript(sc, scorer));
      row.presets[n]={got, regretVsHeuristic:truth.best-got};
    }
    fs.appendFileSync(out, JSON.stringify(row)+'\n');
    console.log(`seed=${seed} form=${sc.formName} heuristicBest=${truth.best} (restarts=${truth.restarts}) `+
      presetNames.map(n=>`${n}=${row.presets[n].got}`).join(' ')+` ms=${Date.now()-t0}`);
  }
}
