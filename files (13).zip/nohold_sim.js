'use strict';
// ============================================================================
// NO-HOLD DRAFT SIMULATOR — future-proofing testbed for the rumored 2027 change
// where every pick must be committed immediately (no holds).
//
// MODEL:
//   A "draft script" is a fixed sequence of pick steps. Step t offers K candidate
//   cards (drawn from the real playerDB). The options at each step are INDEPENDENT
//   of the player's choices (matches the real game: the pack contents are rolled
//   regardless of what you picked before). The player must commit exactly one card
//   per step, immediately, seeing only: cards committed so far + this step's options.
//
// TWO TIERS (mirrors test1_tiered.js's exact/heuristic split):
//   XI-only  : 11 steps, one per formation slot (in a shuffled reveal order, like the
//              real draft which goes GK->DEF->MID->ATT in sections but we support any
//              order). Options for a step are pos-eligible for that slot. The final
//              score is scoreXI of the 11 commits — SO perfect play over the whole
//              script is EXACTLY our production solver run on (slots, all options,
//              no holds): pick-one-per-slot to maximize scoreXI is literally its
//              problem statement. Exact ground truth, cheap.
//   FULL-23  : 11 XI steps + 12 bench steps interleaved. Bench options are unrestricted
//              (any card, like the real bench picks). Final score = best XI from the
//              23 commits (a tiny solve: 23 singletons). Perfect play is a nested
//              problem (choose-per-step x choose-XI-from-23) — K^23 exact search is
//              intractable, so ground truth is heuristic: random-restart + local
//              search over the choice VECTOR (change one step's choice, re-solve),
//              same philosophy as random_search_verifier.js. Lower bound on perfect
//              play => regret numbers in this tier are LOWER bounds too.
//
// STRATEGIES are pick-time scorers: score(option, committedSoFar, step) -> number,
// pick argmax. The whole weighting question ("rating vs rarity vs clash vs prem — the
// true balance") is expressed as one parameterized linear scorer; named presets are
// just weight vectors, and the weight-search experiment fits the vector empirically.
// ============================================================================
const fs = require('fs');
const { scoreXI, leagueOf, maxPossibleRating } = require('./engine.js');
const solver = require('./solver.js');

const playerDB = JSON.parse(fs.readFileSync(__dirname+'/playerDB.json','utf8'));
const FORMS = JSON.parse(fs.readFileSync(__dirname+'/forms.json','utf8'));

function mulberry32(seed){
  return function(){
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function shuffle(arr, rand){
  const a=arr.slice();
  for(let i=a.length-1;i>0;i--){const j=Math.floor(rand()*(i+1));const t=a[i];a[i]=a[j];a[j]=t;}
  return a;
}
function sampleN(arr,n,rand){return shuffle(arr,rand).slice(0,Math.min(n,arr.length));}

// ---------------------------------------------------------------------------
// Draft-script generation
// ---------------------------------------------------------------------------
// opts: { seed, K (options per step, default 5), mode: 'xi'|'full', formName? , revealOrder: 'shuffled'|'formation' }
function generateDraftScript(opts){
  opts=opts||{};
  const rand = mulberry32(opts.seed!==undefined?opts.seed:(Math.random()*2**31|0));
  const rnd=(a,b)=>Math.floor(rand()*(b-a+1))+a;
  const K = opts.K||5;
  const f = opts.formName ? FORMS.find(x=>x.name===opts.formName) : FORMS[rnd(0,FORMS.length-1)];

  const xiSteps = f.slots.map((p,i)=>({kind:'xi', slotIdx:i, pos:p}));
  let steps;
  if(opts.mode==='full'){
    const benchSteps = Array.from({length:12},(_,i)=>({kind:'bench', benchIdx:i, pos:null}));
    steps = shuffle(xiSteps,rand).concat(benchSteps); // real drafts: XI first (any order), bench after
  } else {
    steps = (opts.revealOrder==='formation') ? xiSteps : shuffle(xiSteps,rand);
  }

  let uid=1;
  for(const st of steps){
    const pool = st.kind==='xi' ? playerDB.filter(p=>p.pos.includes(st.pos)) : playerDB;
    st.options = sampleN(pool, K, rand).map(src=>({
      id:uid++, hold:null,
      name:src.name, type:src.type, rating:src.rating,
      nation:src.nation, league:src.league, club:src.club,
      pos:src.pos.slice()
    }));
  }
  return {formName:f.name, form:{name:f.name, slots:f.slots.slice()}, steps, K, mode:opts.mode||'xi'};
}

// ---------------------------------------------------------------------------
// Playing a script with a pick-time strategy
// ---------------------------------------------------------------------------
// scorer(option, ctx) -> number. ctx = { committed:[cards], step, form, seenNat/seenClub/seenLg:Sets,
//                                        natCnt/clubCnt/lgCnt: counts among committed }
function playScript(script, scorer){
  const committed=[];
  const seenNat=new Set(), seenClub=new Set(), seenLg=new Set();
  const natCnt={}, clubCnt={}, lgCnt={};
  for(const step of script.steps){
    let best=null, bestV=-Infinity;
    const ctx={committed, step, form:script.form, seenNat, seenClub, seenLg, natCnt, clubCnt, lgCnt};
    for(const opt of step.options){
      const v=scorer(opt, ctx);
      if(v>bestV){bestV=v; best=opt;}
    }
    committed.push(best);
    seenNat.add(best.nation);
    const lg=leagueOf(best);
    seenLg.add(lg);
    natCnt[best.nation]=(natCnt[best.nation]||0)+1;
    lgCnt[lg]=(lgCnt[lg]||0)+1;
    if(best.type==='normal'){ seenClub.add(best.club); clubCnt[best.club]=(clubCnt[best.club]||0)+1; }
  }
  return committed;
}

// Final score of a set of committed cards for this script's formation.
// XI-only: the commits ARE the XI (one per slot by construction) -> direct scoreXI.
// FULL: best XI from the 23 singletons -> tiny solve (rc from maxPossibleRating for tight pruning).
function finalScore(script, committed){
  if(script.mode!=='full'){
    // commits are slot-aligned only in formation order; scoreXI is order-independent anyway
    return scoreXI(committed).total;
  }
  let rc; try{ rc=maxPossibleRating(committed, script.form); }catch(e){ rc=99; }
  if(rc===null) rc=99;
  const r=solver.solve(script.form, committed, rc, 2000000);
  return r.error? -1 : r.best;
}

// ---------------------------------------------------------------------------
// Ground truths
// ---------------------------------------------------------------------------
// XI-only EXACT: perfect play = production solver over (form-with-step-slots, all options).
// Each step's options are candidates for exactly that slot; give every option a pos tag unique
// to its step so cross-step eligibility can't blur the mapping (an option can only be taken at
// its own step, exactly like the real draft).
function optimalXiOnly(script){
  const slots = script.steps.map((st,i)=>'S'+i);
  const cards=[];
  script.steps.forEach((st,i)=>{
    for(const o of st.options) cards.push(Object.assign({}, o, {pos:['S'+i]}));
  });
  const form={name:'draft', slots};
  let rc; try{ rc=maxPossibleRating(cards, form); }catch(e){ rc=99; }
  if(rc===null) rc=99;
  const r=solver.solve(form, cards, rc, 50000000);
  return {best:r.best, capped:r.capped, nodes:r.nodes};
}

// FULL-23 HEURISTIC: random-restart + first-improvement local search over the choice vector.
// Evaluation of a vector = finalScore (a tiny solve). Returns best found = lower bound on optimum.
function heuristicFull(script, opts){
  opts=opts||{};
  const timeBudgetMs=opts.timeBudgetMs||8000;
  const rand=opts.rng||mulberry32(opts.seed!==undefined?opts.seed:1234567);
  const deadline=Date.now()+timeBudgetMs;
  const S=script.steps.length, K=script.K;
  function evalVec(vec){
    const committed=script.steps.map((st,i)=>st.options[vec[i]]);
    return finalScore(script, committed);
  }
  let bestVec=null, best=-1, restarts=0;
  while(Date.now()<deadline){
    restarts++;
    let vec=script.steps.map(st=>Math.floor(rand()*st.options.length));
    let cur=evalVec(vec);
    let improved=true;
    while(improved && Date.now()<deadline){
      improved=false;
      for(let i=0;i<S && !improved;i++){
        for(let a=0;a<script.steps[i].options.length;a++){
          if(a===vec[i])continue;
          const old=vec[i]; vec[i]=a;
          const s=evalVec(vec);
          if(s>cur){cur=s; improved=true; break;}
          vec[i]=old;
        }
      }
    }
    if(cur>best){best=cur; bestVec=vec.slice();}
  }
  return {best, bestVec, restarts};
}

// ---------------------------------------------------------------------------
// Strategies — one parameterized scorer covers them all
// ---------------------------------------------------------------------------
// Weight vector w:
//   r      : rating (per point)
//   newNat : option's nation not yet in the squad
//   newClub: (normals) club not yet in the squad
//   newLg  : option's league not yet in the squad
//   prem   : option counts toward the Prem pool (normal, or Prem hero at 2x weight-ish; icons count via glue)
//   clash  : option adds NOTHING new (no new nation, no new club, no new league) — the hard-clash case
//   iconHero: option is icon or hero (auto-3 chem, rating usually high — lets the fit tell us if
//             they're systematically over/under-valued at pick time)
function makeWeightedScorer(w){
  return function(opt, ctx){
    const lg=leagueOf(opt);
    const isNormal=opt.type==='normal';
    const newNat=ctx.seenNat.has(opt.nation)?0:1;
    const newClub=(isNormal && !ctx.seenClub.has(opt.club))?1:0;
    const newLg=ctx.seenLg.has(lg)?0:1;
    const premGlue=(opt.type==='icon'||isNormal)?1:(lg==='England Premier League'?2:0); // premPool units from scoreXI
    const clash=(!newNat && !newClub && !newLg)?1:0;
    const iconHero=(opt.type!=='normal')?1:0;
    return w.r*opt.rating + w.newNat*newNat + w.newClub*newClub + w.newLg*newLg
         + w.prem*premGlue + w.clash*clash + w.iconHero*iconHero;
  };
}

const PRESETS = {
  rating_only:  {r:1, newNat:0,   newClub:0,   newLg:0,   prem:0,   clash:0,    iconHero:0},
  // "divstatic-spirit": rating first, small diversity nudges (mirrors the solver's presort logic)
  divstatic_ish:{r:1, newNat:0.4, newClub:0.4, newLg:0.4, prem:0,   clash:0,    iconHero:0},
  // diversity-heavy: a new nation/club/league is worth ~1 rating point each
  diversity_1x: {r:1, newNat:1,   newClub:1,   newLg:1,   prem:0,   clash:0,    iconHero:0},
  // anti-clash: like diversity_1x plus a hard penalty for total-clash picks (the -3 case)
  anti_clash:   {r:1, newNat:1,   newClub:1,   newLg:1,   prem:0,   clash:-3,   iconHero:0},
  // prem-bias: the user's "plan around the Prem pool" hypothesis
  prem_bias:    {r:1, newNat:1,   newClub:1,   newLg:1,   prem:0.5, clash:-3,   iconHero:0},
  random_pick:  null // handled specially: uniform random choice (floor baseline)
};

function makeRandomPicker(seed){
  const rand=mulberry32(seed);
  return function(opt, ctx){ return rand(); };
}

module.exports = {
  playerDB, FORMS, mulberry32,
  generateDraftScript, playScript, finalScore,
  optimalXiOnly, heuristicFull,
  makeWeightedScorer, makeRandomPicker, PRESETS
};
