# No-hold draft weighting study — first data

## The model (and why the oracle is trustworthy)

A "draft script" is a fixed sequence of pick steps; each step offers K=5 real playerDB cards and
the player must commit one immediately, seeing only prior commits + the current options (options
are independent of choices, like real packs). Two tiers:

- **XI-only (exact tier)**: 11 steps, one per formation slot, options pos-eligible for that slot.
  Final score = scoreXI of the 11 commits. The key insight making this tier *exact*: perfect play
  over the whole script is literally our production solver's problem — tag each step's options
  with a unique pseudo-position 'S<i>' and solve (one pick per step-slot, maximize scoreXI). So
  the oracle is the verified v12.4.1 solver port (cross-checked bit-for-bit against the uploaded
  index.html: 0/12 mismatches on best AND node counts), run uncapped. All 115 scripts used
  (85 train + 30 held-out) have uncapped exact optima.
- **FULL-23 (heuristic tier)**: 11 XI steps + 12 unrestricted bench steps; final score = best XI
  from the 23 commits (tiny solve). Perfect play is a nested 5^23 problem — intractable exactly,
  so ground truth is random-restart + local search over the choice vector... which turned out to
  be **too weak to be a truth reference**: the greedy strategies beat the 8-second heuristic in
  14/16 drafts. Honest handling: FULL-tier numbers below are regret vs *best-known* (max over all
  strategies + the heuristic), i.e. relative ranking only. The XI tier is where the exact
  claims live.

## Headline numbers (XI tier, 30 held-out drafts, exact regret)

| pick strategy | mean regret vs perfect play | note |
|---|---|---|
| random pick | 9.57 | floor |
| **rating only** | **5.20** | the naive default |
| divstatic-spirit (rating + 0.4 nudges) | 4.83 | the solver's tie-break weights are far too small for *pick time* |
| diversity 1x (nat/club/lg = 1 pt each) | 4.50 | |
| anti-clash (diversity 1x + hard −3 clash) | 3.93 | best hand-designed |
| prem-bias (anti-clash + prem bonus) | 3.97 | prem bonus adds nothing |
| **fitted (empirical) weights** | **3.03** | random-search over 400 vectors on 85 training drafts, validated held-out |

Training regret for the fitted vector was 2.82 — held-out 3.03, so minimal overfit; the fit is
real. FULL-23 tier confirms the same ordering with compressed gaps (fitted 0.56 vs best-known,
anti-clash 0.63, rating-only 1.31): bench slack forgives pick mistakes, so pick weights matter
most exactly where the 2027 change would bite — when a pick IS an XI slot.

## The empirically best weight vector (per rating point)

```
rating      1.00   (scale anchor)
new nation +2.91   } a fresh nation/club/league at pick time is worth
new club   +2.17   } ~2–3 RATING POINTS each — not 0.4, not 1
new league +2.93   }
prem pool  +0.36   (real but small)
hard clash −4.77   (option adds NO new nat/club/league)
icon/hero  −1.72   (they're systematically slightly overpaid at pick time —
                    their auto-3 chem is already priced into their rating)
```

Sensitivity across all 400 vectors (top-20% vs bottom-20% gap): the **clash penalty is the
single strongest signal** (gap −2.65), then newNat/newClub (+1.05 each), newLg (+0.78),
iconHero (−0.98). Prem bonus is the only dimension whose gap is ~zero (−0.21) — see below.

## Direct answers to your questions

**"Do we undervalue or overvalue rating?"** Overvalue, heavily, at pick time. Rating-only play
loses ~5.2 pts per draft vs perfect play; the fitted weights recover ~2.2 of that. A new
nation/club/league is worth ~2–3 rating points when committing a pick — which means the current
helper's divstatic-style small nudges (0.4) are the right *solver tie-break* but roughly 6x too
timid as *pick advice*. Those are genuinely different problems: the solver orders candidates
within one search; the pick decision permanently forecloses futures.

**"Is clash the big thing?"** Yes — the hard clash (a card adding nothing new) is the most
important single factor to punish, worth about −5 rating points. Your instinct in the current
hold-by-hold weighting (clashing cards rank low) is empirically correct and, if anything, should
be *harder* than it feels.

**"Prem planning?"** Directionally right but nearly priced in already. The prem-pool bonus fits
at +0.36 and its sensitivity is ~zero: because normals are all Prem in this DB, rewarding
new-club (+2.17) *already* rewards Prem picks implicitly. So "plan around Prem" is true but
mostly redundant with club-diversity — you don't need a separate weight for it unless the DB
changes such that normals span leagues.

**"Icons/heroes?"** Slightly overvalued at pick time (fit says −1.7). Their auto-3 chem is
real, but they don't extend the Prem pool and their nation is often shared — the fit says treat
a 95 icon like a ~93 normal when choosing between them.

**"How far off are we by not holding?"** With even the fitted greedy policy: ~3 pts per draft on
XI-forced picks, ~0.6 pts when there's bench slack. That's the irreducible cost of committing
without seeing the future — perfect play knows the whole script; a pick-time policy can't. The
remaining ~3-pt gap on the XI tier is mostly *unforeseeable*, not bad weighting: the top-10
fitted vectors all cluster tightly (nat/club/lg ≈ 2–3, clash ≈ −4..−6) and none breaks below
~2.8, suggesting we're near the ceiling of what memoryless pick-time scoring can do. Next-level
gains would need lookahead (e.g. rollout policies), not better weights.

## Methodology notes / caveats (for the re-run on a future DB)

- **DB dependency acknowledged and embraced**: everything reads playerDB.json/forms.json
  extracted from the current index.html (v12.4.1, 2200 cards). Rerun `run_nohold.js scripts` +
  `fitweights` on a new DB and the fitted vector updates itself. The *structure* of the answer
  (clash ≫ diversity ≫ prem; rating overvalued) is what I'd expect to survive; the exact
  magnitudes are DB-specific.
- The XI-tier oracle is exact and uncapped on every script used (capped ones are filtered out;
  none occurred in the final sets).
- FULL-tier ground truth needs a better oracle before regret numbers there can be quoted as
  absolute — the random-restart verifier from your suite is the right *independence* idea but
  needs warm-starting from the greedy solutions and a much bigger budget at 5^23. Roadmap item.
- K=5 options per step throughout; regret scales with K (more options = more to lose by picking
  wrong). Worth a K-sweep later.
- Strategies are memoryless linear scorers by design — that's what a helper weight table can
  implement. Rollout/lookahead policies would be a different (heavier) helper architecture.

## Files

- `nohold_sim.js` — simulator core (script gen, play, exact XI oracle, heuristic FULL oracle, parameterized scorer)
- `run_nohold.js` — runner (scripts / presets / fitweights / full modes)
- `nohold_scripts.jsonl` (85 train), `nohold_val.jsonl` (30 held-out) — scripts with cached exact optima
- `nohold_full.jsonl` (16 FULL-tier drafts), `nohold_fit_results.json` (all 400 fitted vectors)
- `nohold_results.png` — headline chart
