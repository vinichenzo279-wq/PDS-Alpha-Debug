'use strict';
// Extracted verbatim from pacwyn_v10_1_0_2.html (lines ~2211, 3514-3790) — the current shipped
// maxPossibleRating() = min(UB-A, UB-B, UB-C, UB-D, UB-E), plus its two helper functions and
// futRatingRaw. Copied unmodified so the fuzz test compares UB-H against the REAL current bound.

function futRatingRaw(rs){const S=rs.reduce((a,b)=>a+b,0),A=S/rs.length;let sp=0;for(const r of rs)if(r>A)sp+=r-A;return (S+sp)/rs.length;}

function ubDComponent(candList, positions, need){
  const groupOf=c=>c.hold||('C'+c.id);
  const groups={};
  for(const c of candList){
    const g=groupOf(c);
    if(!groups[g]) groups[g]={eligPos:new Set(), bestRating:-Infinity};
    for(const p of c.pos){
      if(positions.includes(p)){
        groups[g].eligPos.add(p);
        if(c.rating>groups[g].bestRating) groups[g].bestRating=c.rating;
      }
    }
  }
  const groupIds=Object.keys(groups)
    .filter(g=>groups[g].eligPos.size>0)
    .sort((a,b)=>groups[b].bestRating-groups[a].bestRating);

  const posAssignments={}; for(const p of positions) posAssignments[p]=[];

  function tryAugment(gid, visitedPos){
    for(const p of groups[gid].eligPos){
      if(visitedPos.has(p)) continue;
      visitedPos.add(p);
      if(posAssignments[p].length<need[p]){
        posAssignments[p].push(gid);
        return true;
      }
      for(let k=0;k<posAssignments[p].length;k++){
        const other=posAssignments[p][k];
        if(tryAugment(other, visitedPos)){
          posAssignments[p][k]=gid;
          return true;
        }
      }
    }
    return false;
  }

  const K=positions.reduce((s,p)=>s+need[p],0);
  const chosen=[];
  let matched=0;
  for(const gid of groupIds){
    if(tryAugment(gid, new Set())){
      matched++;
      chosen.push(groups[gid].bestRating);
      if(matched===K) break;
    }
  }
  if(matched<K) return {feasible:false};
  return {feasible:true, chosen};
}

function ubEGlobal(elig, slots, need){
  const groupOf=c=>c.hold||('C'+c.id);
  const positions=Object.keys(need);
  const groups={};
  for(const c of elig){
    const g=groupOf(c);
    if(!groups[g]) groups[g]={eligPos:new Set(), bestRating:-Infinity};
    for(const p of c.pos){
      if(need[p]!==undefined){
        groups[g].eligPos.add(p);
        if(c.rating>groups[g].bestRating) groups[g].bestRating=c.rating;
      }
    }
  }
  const groupIds=Object.keys(groups)
    .filter(g=>groups[g].eligPos.size>0)
    .sort((a,b)=>groups[b].bestRating-groups[a].bestRating);

  const posAssignments={}; for(const p of positions) posAssignments[p]=[];
  function tryAugment(gid, visitedPos){
    for(const p of groups[gid].eligPos){
      if(visitedPos.has(p)) continue;
      visitedPos.add(p);
      if(posAssignments[p].length<need[p]){
        posAssignments[p].push(gid);
        return true;
      }
      for(let k=0;k<posAssignments[p].length;k++){
        const other=posAssignments[p][k];
        if(tryAugment(other, visitedPos)){
          posAssignments[p][k]=gid;
          return true;
        }
      }
    }
    return false;
  }

  const N=slots.length;
  const chosen=[];
  let matched=0;
  for(const gid of groupIds){
    if(tryAugment(gid, new Set())){
      matched++;
      chosen.push(groups[gid].bestRating);
      if(matched===N) break;
    }
  }
  if(matched<N) return {feasible:false};
  return {feasible:true, chosen};
}

function maxPossibleRating(pool,form){
  if(!pool||!pool.length||!form)return null;
  const slots=form.slots,slotSet=new Set(slots),N=slots.length;
  const groupOf=c=>c.hold||('C'+c.id);
  const elig=pool.filter(c=>c.pos&&c.pos.some(p=>slotSet.has(p)));
  const ubs=[];
  // UB-A
  {
    const byGroup={};
    for(const c of elig){const g=groupOf(c);if(byGroup[g]===undefined||c.rating>byGroup[g])byGroup[g]=c.rating;}
    const rs=Object.keys(byGroup).map(k=>byGroup[k]).sort((a,b)=>b-a);
    if(rs.length>=N)ubs.push(futRatingRaw(rs.slice(0,N)));
  }
  // UB-B
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const chosen=[];let feasible=true;
    for(const pos in need){
      const k=need[pos];
      const cand=elig.filter(c=>c.pos.includes(pos)).sort((a,b)=>b.rating-a.rating);
      const seen=new Set(),top=[];
      for(const c of cand){const g=groupOf(c);if(seen.has(g))continue;seen.add(g);top.push(c.rating);if(top.length===k)break;}
      if(top.length<k){feasible=false;break;}
      for(const r of top)chosen.push(r);
    }
    if(feasible&&chosen.length===N)ubs.push(futRatingRaw(chosen));
  }
  // UB-C
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const posArr=Object.keys(need);
    const parent={};posArr.forEach(p=>parent[p]=p);
    const find=x=>{while(parent[x]!==x){parent[x]=parent[parent[x]];x=parent[x];}return x;};
    const union=(a,b)=>{const ra=find(a),rb=find(b);if(ra!==rb)parent[ra]=rb;};
    for(const c of elig){
      const rel=c.pos.filter(p=>need[p]!==undefined);
      for(let i=1;i<rel.length;i++)union(rel[0],rel[i]);
    }
    const comps={};
    for(const p of posArr){const r=find(p);(comps[r]=comps[r]||[]).push(p);}
    let feasible=true;const chosen=[];
    for(const r in comps){
      const compPos=new Set(comps[r]);
      const k=comps[r].reduce((s,p)=>s+need[p],0);
      const cand=elig.filter(c=>c.pos.some(p=>compPos.has(p))).sort((a,b)=>b.rating-a.rating);
      const seen=new Set(),top=[];
      for(const c of cand){const g=groupOf(c);if(seen.has(g))continue;seen.add(g);top.push(c.rating);if(top.length===k)break;}
      if(top.length<k){feasible=false;break;}
      for(const rr of top)chosen.push(rr);
    }
    if(feasible&&chosen.length===N)ubs.push(futRatingRaw(chosen));
  }
  // UB-D
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const posArr=Object.keys(need);
    const parent={};posArr.forEach(p=>parent[p]=p);
    const find=x=>{while(parent[x]!==x){parent[x]=parent[parent[x]];x=parent[x];}return x;};
    const union=(a,b)=>{const ra=find(a),rb=find(b);if(ra!==rb)parent[ra]=rb;};
    for(const c of elig){
      const rel=c.pos.filter(p=>need[p]!==undefined);
      for(let i=1;i<rel.length;i++)union(rel[0],rel[i]);
    }
    const comps={};
    for(const p of posArr){const r=find(p);(comps[r]=comps[r]||[]).push(p);}
    let feasible=true;const chosen=[];
    for(const r in comps){
      const compPos=new Set(comps[r]);
      const candList=elig.filter(c=>c.pos.some(p=>compPos.has(p)));
      const result=ubDComponent(candList, comps[r], need);
      if(!result.feasible){feasible=false;break;}
      for(const rr of result.chosen)chosen.push(rr);
    }
    if(feasible&&chosen.length===N)ubs.push(futRatingRaw(chosen));
  }
  // UB-E
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const result=ubEGlobal(elig, slots, need);
    if(result.feasible && result.chosen.length===N)ubs.push(futRatingRaw(result.chosen));
  }
  if(!ubs.length)return null;
  return Math.floor(Math.min(...ubs));
}

module.exports={maxPossibleRating, futRatingRaw, ubDComponent, ubEGlobal};
