'use strict';
const fs = require('fs');
const files = process.argv.slice(2);
let totalComparable=0, totalCapped=0, hViolations=0, hTighterCount=0, hTighterSum=0, hTighterMax=0, hLooserCount=0;
const perTag = {};
let hWorstViolations=[];
let hBiggestTightenings=[];

for(const f of files){
  const d = JSON.parse(fs.readFileSync(f,'utf8'));
  totalComparable += d.totalComparable;
  totalCapped += d.totalCapped;
  hViolations += d.hViolations;
  hTighterCount += d.hTighterCount;
  hTighterSum += d.hTighterSum;
  hTighterMax = Math.max(hTighterMax, d.hTighterMax);
  hLooserCount += d.hLooserCount;
  hWorstViolations = hWorstViolations.concat(d.hWorstViolations||[]);
  hBiggestTightenings = hBiggestTightenings.concat(d.hBiggestTightenings||[]);
  for(const tag in d.perTag){
    if(!perTag[tag]) perTag[tag]={n:0,capped:0,hViolations:0,hTighterCount:0,hTighterSum:0,hTighterMax:0,hLooserCount:0};
    const S=perTag[tag], T=d.perTag[tag];
    S.n+=T.n; S.capped+=T.capped; S.hViolations+=T.hViolations; S.hTighterCount+=T.hTighterCount;
    S.hTighterSum+=T.hTighterSum; S.hTighterMax=Math.max(S.hTighterMax,T.hTighterMax); S.hLooserCount+=T.hLooserCount;
  }
}
hBiggestTightenings.sort((a,b)=>b.delta-a.delta);
hBiggestTightenings = hBiggestTightenings.slice(0,10);

function pct(n,d){return d?(100*n/d).toFixed(2)+'%':'n/a';}
console.log('=== MERGED UB-H FUZZ RESULTS across', files.length, 'chunks ===');
console.log('total comparable trials:', totalComparable, ' | oracle gave up:', totalCapped);
console.log('TOTAL UB-H VIOLATIONS (must be 0):', hViolations);
console.log('tightens shipped bound:', hTighterCount, pct(hTighterCount,totalComparable), ' avg=',(hTighterCount?(hTighterSum/hTighterCount).toFixed(4):'n/a'),' max=',hTighterMax.toFixed(4));
console.log('UB-H looser than existing:', hLooserCount, pct(hLooserCount,totalComparable));
console.log('\nPer-scenario:');
for(const tag of Object.keys(perTag).sort((a,b)=>perTag[b].n-perTag[a].n)){
  const S=perTag[tag];
  console.log(`[${tag}] n=${S.n} violations=${S.hViolations}${S.hViolations?' <<<CRITICAL':''} tighter=${S.hTighterCount}(${pct(S.hTighterCount,S.n)}) looser=${S.hLooserCount}(${pct(S.hLooserCount,S.n)}) maxTighten=${S.hTighterMax.toFixed(2)}`);
}
if(hWorstViolations.length){
  console.log('\n!!! VIOLATIONS !!!');
  for(const v of hWorstViolations.slice(0,10)) console.log(JSON.stringify(v));
}
console.log('\nTop tightening cases overall:');
for(const w of hBiggestTightenings) console.log(`[${w.tag}] delta=${w.delta.toFixed(2)} existing=${w.existingUB} ubH=${w.hFloored} best=${w.best.toFixed(3)} slots=${JSON.stringify(w.form.slots)}`);
