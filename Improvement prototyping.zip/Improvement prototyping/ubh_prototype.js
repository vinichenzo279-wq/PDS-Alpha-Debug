'use strict';
// UB-H: decoupled mean/spread bound.
//
// WHY THIS IS A DIFFERENT KIND OF ARGUMENT (not another D/E/F/G variant): every method up to UB-E
// (and both failed attempts UB-F/UB-G) works by building ONE N-length credited vector and relying
// on it to element-wise DOMINATE whatever the true winning legal XI's vector turns out to be.
// UB-F/UB-G's counterexample showed that's fundamentally fragile once you try to use real,
// position-specific values: two real legal XIs can have INCOMPARABLE sorted vectors (neither
// dominates the other), so no single "honest" vector can safely stand in for "whichever one turns
// out to be true".
//
// UB-H sidesteps that entirely by never constructing a vector at all. futRatingRaw(x) = (S + sp)/N
// where S = sum(x) and sp = spread-above-mean(x). If we can find ANY S_max >= S* (the true
// winner's actual sum) and ANY sp_max >= sp* (the true winner's actual spread), independently and
// via TWO SEPARATE arguments, then (S_max + sp_max)/N >= (S* + sp*)/N = futRatingRaw(true winner)
// automatically -- this holds regardless of whether S_max and sp_max come from the same
// hypothetical configuration or not, because it's just "a>=a0 and b>=b0 implies a+b>=a0+b0". No
// domination of a full vector is required, so the earlier counterexample doesn't apply here.
//
// PART 1 -- S_max (exact, not a relaxation): the maximum possible SUM of ratings over any real
// legal XI is a plain weighted-matching problem (position capacity + at-most-one-card-per-hold),
// and unlike the FULL futRatingRaw objective, raw SUM genuinely IS solvable exactly via min-cost
// max-flow / assignment -- there's no analogue of the "sum-maximisation is unsound" trap here,
// because we are not pretending this sum-optimal selection's OWN spread also happens to be the
// worst case; we bound spread completely separately in part 2. S_max is computed by an honest
// min-cost-max-flow over: SOURCE -> each hold-group (cap 1) -> each position it's really eligible
// for (cap 1, cost = -that group's position-specific best rating there) -> position slot (cap
// need[p]) -> SINK. This is exact: it finds the TRUE best real sum, respecting real per-card
// eligibility (no union-of-positions artifact -- that trick was only ever needed to get a single
// SORTED VECTOR to dominate; a pure sum doesn't need it).
//
// PART 2 -- sp_max (a real upper bound, not exact, but provably safe): spread-above-mean is a
// CONVEX function of the rating vector (it's a sum of max(0, x_i - mean(x)) terms, each convex).
// The maximum of a convex function over a box-constrained region intersected with a half-space
// (here: every rating in [Lmin, Umax], sum(ratings) <= S_max) is attained at an extreme point of
// that region, and for a box-plus-one-hyperplane region, every extreme point has at most ONE
// coordinate strictly between the box bounds -- the rest all sit at Lmin or Umax. So we can find
// the true maximum of sp over this relaxed region exactly, by enumerating over k = 0..N (how many
// coordinates sit at Umax) and, for each k, checking both the pure box vertex (if it already
// satisfies the sum bound) and the vertex with one flex coordinate that exactly uses the sum
// budget. Lmin/Umax are real, computable bounds (min/max rating among cards eligible for ANY
// position in this formation) -- valid for every coordinate of every real legal XI, since every
// assigned card is drawn from that same eligible pool.
//
// CAVEAT: like every method in this file, this still needs the brute-force fuzz gauntlet before it
// goes near maxPossibleRating() -- the reasoning above is believed sound but "believed sound" is
// exactly what UB-F and UB-G looked like on paper too, right up until the fuzzer found violations.
function minCostMaxFlow(numNodes, source, sink, edges, targetFlow){
  // edges: [{to, cap, cost}] adjacency built as arrays of edge indices; simple array-based residual graph.
  const graph = Array.from({length:numNodes}, ()=>[]);
  const edgeList = [];
  function addEdge(u,v,cap,cost){
    edgeList.push({u,v,cap,cost,flow:0});
    edgeList.push({u:v,v:u,cap:0,cost:-cost,flow:0});
    graph[u].push(edgeList.length-2);
    graph[v].push(edgeList.length-1);
  }
  for(const e of edges) addEdge(e.u,e.v,e.cap,e.cost);

  let totalFlow=0, totalCost=0;
  while(totalFlow<targetFlow){
    // Bellman-Ford shortest path by cost (handles negative edges; no negative cycles in this
    // layered SOURCE->groups->positions->SINK residual graph).
    const dist = new Array(numNodes).fill(Infinity);
    const inQueue = new Array(numNodes).fill(false);
    const prevEdge = new Array(numNodes).fill(-1);
    dist[source]=0;
    const queue=[source]; inQueue[source]=true;
    let head=0, iterations=0;
    const maxIter = numNodes*numNodes*4+50;
    while(head<queue.length && iterations<maxIter){
      iterations++;
      const u=queue[head++]; inQueue[u]=false;
      for(const ei of graph[u]){
        const e=edgeList[ei];
        if(e.cap-e.flow<=0) continue;
        if(dist[u]+e.cost < dist[e.v]-1e-9){
          dist[e.v]=dist[u]+e.cost;
          prevEdge[e.v]=ei;
          if(!inQueue[e.v]){ queue.push(e.v); inQueue[e.v]=true; }
        }
      }
    }
    if(dist[sink]===Infinity) break; // no more augmenting paths
    // bottleneck along the path
    let bottleneck=targetFlow-totalFlow;
    let v=sink;
    while(v!==source){
      const ei=prevEdge[v];
      const e=edgeList[ei];
      bottleneck=Math.min(bottleneck, e.cap-e.flow);
      v=e.u;
    }
    v=sink;
    while(v!==source){
      const ei=prevEdge[v];
      edgeList[ei].flow+=bottleneck;
      edgeList[ei^1].flow-=bottleneck;
      totalCost += edgeList[ei].cost*bottleneck;
      v=edgeList[ei].u;
    }
    totalFlow+=bottleneck;
  }
  return {flow:totalFlow, cost:totalCost};
}

function spMaxBound(Lmin, Umax, N, Smax){
  function spOf(vals){
    const S=vals.reduce((a,b)=>a+b,0), A=S/vals.length;
    let sp=0; for(const v of vals) if(v>A) sp+=v-A;
    return sp;
  }
  let best=-Infinity;
  for(let k=0;k<=N;k++){
    const sumBox = k*Umax + (N-k)*Lmin;
    if(sumBox<=Smax+1e-9){
      const vals=new Array(k).fill(Umax).concat(new Array(N-k).fill(Lmin));
      best=Math.max(best, spOf(vals));
    }
    if(N-k-1>=0){
      let v = Smax - k*Umax - (N-k-1)*Lmin;
      if(v<Lmin) v=Lmin;
      if(v>Umax) v=Umax;
      const vals=new Array(k).fill(Umax).concat([v]).concat(new Array(N-k-1).fill(Lmin));
      best=Math.max(best, spOf(vals));
    }
  }
  return best;
}

function ubH(pool, form){
  const slots=form.slots, N=slots.length;
  const need={}; for(const s of slots) need[s]=(need[s]||0)+1;
  const positions=Object.keys(need);
  const elig=pool.filter(c=>c.pos&&c.pos.some(p=>need[p]!==undefined));
  if(!elig.length) return null;
  const groupOf=c=>c.hold||('C'+c.id);

  const posBest={}; // posBest[g][p]
  let Lmin=Infinity, Umax=-Infinity;
  for(const c of elig){
    const g=groupOf(c);
    if(!posBest[g]) posBest[g]={};
    for(const p of c.pos){
      if(need[p]!==undefined){
        if(posBest[g][p]===undefined || c.rating>posBest[g][p]) posBest[g][p]=c.rating;
        if(c.rating<Lmin) Lmin=c.rating;
        if(c.rating>Umax) Umax=c.rating;
      }
    }
  }
  const groupIds=Object.keys(posBest);

  // Build min-cost-max-flow network: 0=SOURCE, 1..G=groups, G+1..G+P=positions, last=SINK
  const G=groupIds.length, P=positions.length;
  const SOURCE=0, groupBase=1, posBase=1+G, SINK=1+G+P;
  const numNodes=SINK+1;
  const edges=[];
  for(let gi=0; gi<G; gi++){
    edges.push({u:SOURCE, v:groupBase+gi, cap:1, cost:0});
  }
  for(let gi=0; gi<G; gi++){
    const g=groupIds[gi];
    for(let pi=0; pi<P; pi++){
      const p=positions[pi];
      if(posBest[g][p]!==undefined){
        edges.push({u:groupBase+gi, v:posBase+pi, cap:1, cost:-posBest[g][p]});
      }
    }
  }
  for(let pi=0; pi<P; pi++){
    edges.push({u:posBase+pi, v:SINK, cap:need[positions[pi]], cost:0});
  }

  const {flow, cost} = minCostMaxFlow(numNodes, SOURCE, SINK, edges, N);
  if(flow<N) return null; // no legal XI -- consistent with other methods, just opt out

  const Smax = -cost; // exact true maximum achievable sum
  const spMax = spMaxBound(Lmin, Umax, N, Smax);
  return (Smax + spMax)/N;
}
module.exports={ubH, minCostMaxFlow, spMaxBound};
