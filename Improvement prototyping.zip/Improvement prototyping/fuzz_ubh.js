'use strict';
const {maxPossibleRating, futRatingRaw} = require('./existing_ub_module.js');
const {bruteForceMax} = require('./oracle.js');
const {ubH} = require('./ubh_prototype.js');

function randInt(a,b){return a+Math.floor(Math.random()*(b-a+1));}
function choice(arr){return arr[randInt(0,arr.length-1)];}
function sample(arr,k){const c=arr.slice();const out=[];for(let i=0;i<k&&c.length;i++){out.push(c.splice(randInt(0,c.length-1),1)[0]);}return out;}
function shuffle(arr){const c=arr.slice();for(let i=c.length-1;i>0;i--){const j=randInt(0,i);[c[i],c[j]]=[c[j],c[i]];}return c;}

const EPS=1e-6;

// ---------------------------------------------------------------------------
// GENERATORS (ported from fuzz_extreme (6).js, unchanged in spirit)
// ---------------------------------------------------------------------------
const posSets=[
  ['P','Q','R','S'],
  ['GK','CB','RB','LB','CM','ST'],
  ['A','B','C'],
  ['LB','LM','LW','CM'],
  ['GK','CB','CB','RB','LB','CM','CM','RW','LW','ST','ST'.slice(0)],
];

function genRandom(){
  const posAlphabet=[...new Set(choice(posSets))];
  const N=randInt(1,7);
  const slots=[];for(let i=0;i<N;i++)slots.push(choice(posAlphabet));
  const poolSize=randInt(N, N+7);
  const pool=[];
  for(let i=0;i<poolSize;i++){
    const nPos = Math.random()<0.3 ? randInt(2,3) : 1;
    const pos = sample(posAlphabet, Math.min(nPos, posAlphabet.length));
    if(!pos.length) continue;
    const hold = Math.random()<0.35 ? choice(['H1','H2','H3','H4']) : null;
    pool.push({id:i, rating: randInt(60,99), pos, hold});
  }
  return {pool, form:{slots}, tag:'random_baseline'};
}

function genAllSameHold(){
  const posAlphabet=[...new Set(choice(posSets))];
  const N=randInt(2,7);
  const slots=[];for(let i=0;i<N;i++)slots.push(choice(posAlphabet));
  const pool=[];
  let id=0;
  const nDominant=randInt(3,8);
  for(let i=0;i<nDominant;i++){
    const nPos=randInt(1,Math.min(3,posAlphabet.length));
    const pos=sample(posAlphabet,nPos);
    if(!pos.length)continue;
    pool.push({id:id++, rating:randInt(80,99), pos, hold:'H_SAME'});
  }
  for(let i=0;i<N+randInt(2,6);i++){
    const nPos=Math.random()<0.3?randInt(1,2):1;
    const pos=sample(posAlphabet,Math.min(nPos,posAlphabet.length));
    if(!pos.length)continue;
    const hold=Math.random()<0.4?choice(['F1','F2','F3','F4']):null;
    pool.push({id:id++, rating:randInt(60,90), pos, hold});
  }
  return {pool, form:{slots}, tag:'all_same_hold'};
}

function genFullyVersatile(){
  const posAlphabet=[...new Set(choice(posSets))];
  const N=randInt(2,6);
  const slots=[];for(let i=0;i<N;i++)slots.push(choice(posAlphabet));
  const nHolds=randInt(1,4);
  const holds=[]; for(let i=0;i<nHolds;i++) holds.push('HV'+i);
  const poolSize=randInt(N,N+5);
  const pool=[];
  for(let i=0;i<poolSize;i++){
    pool.push({id:i, rating:randInt(60,99), pos:posAlphabet.slice(), hold: Math.random()<0.7?choice(holds):null});
  }
  return {pool, form:{slots}, tag:'fully_versatile'};
}

function genStackedSinglePosition(){
  const pos = choice(['ST','CB','GK','CM']);
  const N = randInt(1,5);
  const slots = new Array(N).fill(pos);
  const poolSize = randInt(N+3, N+12);
  const pool=[];
  for(let i=0;i<poolSize;i++){
    const hold = Math.random()<0.3 ? choice(['H1','H2','H3']) : null;
    pool.push({id:i, rating:randInt(60,99), pos:[pos], hold});
  }
  return {pool, form:{slots}, tag:'stacked_single_position'};
}

function genCrossComponentSharedHold(){
  const compAPos=['P1','P2'], compBPos=['Q1','Q2'];
  const slotsA = new Array(randInt(1,3)).fill(0).map(()=>choice(compAPos));
  const slotsB = new Array(randInt(1,3)).fill(0).map(()=>choice(compBPos));
  const slots = shuffle([...slotsA, ...slotsB]);
  const sharedHold = 'SHARED';
  const pool=[];
  let id=0;
  pool.push({id:id++, rating:randInt(90,99), pos:[choice(compAPos)], hold:sharedHold});
  pool.push({id:id++, rating:randInt(90,99), pos:[choice(compBPos)], hold:sharedHold});
  for(let i=0;i<randInt(3,8);i++){
    const useA = Math.random()<0.5;
    const posAlphabet = useA?compAPos:compBPos;
    pool.push({id:id++, rating:randInt(60,95), pos:sample(posAlphabet,randInt(1,posAlphabet.length)), hold: Math.random()<0.4?choice(['F1','F2','F3']):null});
  }
  return {pool, form:{slots}, tag:'cross_component_shared_hold'};
}

function genTightPool(){
  const posAlphabet=[...new Set(choice(posSets))];
  const N=randInt(1,7);
  const slots=[];for(let i=0;i<N;i++)slots.push(choice(posAlphabet));
  const poolSize=N+randInt(0,1);
  const pool=[];
  for(let i=0;i<poolSize;i++){
    const nPos=Math.random()<0.5?randInt(1,2):1;
    const pos=sample(posAlphabet,Math.min(nPos,posAlphabet.length));
    if(!pos.length)continue;
    const hold=Math.random()<0.35?choice(['H1','H2']):null;
    pool.push({id:i, rating:randInt(60,99), pos, hold});
  }
  return {pool, form:{slots}, tag:'tight_pool_no_slack'};
}

function genHugePool(){
  const posAlphabet=[...new Set(choice(posSets))];
  const N=randInt(4,6);
  const slots=[];for(let i=0;i<N;i++)slots.push(choice(posAlphabet));
  const poolSize=randInt(N+6,N+11);
  const pool=[];
  for(let i=0;i<poolSize;i++){
    const nPos=Math.random()<0.5?randInt(2,Math.min(3,posAlphabet.length)):1;
    const pos=sample(posAlphabet,Math.min(nPos,posAlphabet.length));
    if(!pos.length)continue;
    const hold=Math.random()<0.5?choice(['H1','H2','H3','H4','H5','H6']):null;
    pool.push({id:i, rating:randInt(60,99), pos, hold});
  }
  return {pool, form:{slots}, tag:'huge_loose_pool'};
}

function genExtremeSpread(){
  const posAlphabet=[...new Set(choice(posSets))];
  const N=randInt(2,6);
  const slots=[];for(let i=0;i<N;i++)slots.push(choice(posAlphabet));
  const poolSize=randInt(N+3,N+12);
  const pool=[];
  for(let i=0;i<poolSize;i++){
    const rating = Math.random()<0.15 ? randInt(96,99) : randInt(60,65);
    const nPos = Math.random()<0.4?randInt(2,Math.min(3,posAlphabet.length)):1;
    const pos=sample(posAlphabet,Math.min(nPos,posAlphabet.length));
    if(!pos.length)continue;
    const hold=Math.random()<0.5?choice(['H1','H2','H3']):null;
    pool.push({id:i, rating, pos, hold});
  }
  return {pool, form:{slots}, tag:'extreme_rating_spread'};
}

function genBoundarySizes(){
  const posAlphabet=[...new Set(choice(posSets))];
  const N = choice([1,7]);
  const slots=[];for(let i=0;i<N;i++)slots.push(choice(posAlphabet));
  const poolSize=randInt(N,N+6);
  const pool=[];
  for(let i=0;i<poolSize;i++){
    const nPos=Math.random()<0.3?randInt(2,3):1;
    const pos=sample(posAlphabet,Math.min(nPos,posAlphabet.length));
    if(!pos.length)continue;
    const hold=Math.random()<0.35?choice(['H1','H2','H3']):null;
    pool.push({id:i, rating:randInt(60,99), pos, hold});
  }
  return {pool, form:{slots}, tag:'boundary_sizes'};
}

// NEW generator specifically targeting UB-H's own reasoning: box-vertex spread bound assumes
// every coordinate sits at the SAME pool-wide [Lmin,Umax] -- stress a case with a big rating
// range but where the true winning XI is forced (by scarcity) to use only middling cards.
function genWideRangeForcedMiddle(){
  const posAlphabet=[...new Set(choice(posSets))];
  const N=randInt(2,5);
  const slots=[];for(let i=0;i<N;i++)slots.push(choice(posAlphabet));
  const pool=[];
  let id=0;
  // one extreme-high card and one extreme-low card, both eligible for only ONE (different) slot
  // position and both hogging a hold group shared with nothing else, to widen Lmin/Umax globally
  // without actually being available to most slots.
  pool.push({id:id++, rating:99, pos:[choice(posAlphabet)], hold:'EXTREME_HI'});
  pool.push({id:id++, rating:60, pos:[choice(posAlphabet)], hold:'EXTREME_LO'});
  // filler: plenty of solidly-mid cards for everything else
  for(let i=0;i<N+randInt(4,10);i++){
    const nPos=Math.random()<0.4?randInt(1,2):1;
    const pos=sample(posAlphabet,Math.min(nPos,posAlphabet.length));
    if(!pos.length)continue;
    const hold=Math.random()<0.4?choice(['F1','F2','F3','F4']):null;
    pool.push({id:id++, rating:randInt(75,85), pos, hold});
  }
  return {pool, form:{slots}, tag:'wide_range_forced_middle'};
}

const GENERATORS = [
  [genRandom, 0.28],
  [genAllSameHold, 0.08],
  [genFullyVersatile, 0.10],
  [genStackedSinglePosition, 0.12],
  [genCrossComponentSharedHold, 0.10],
  [genTightPool, 0.08],
  [genHugePool, 0.08],
  [genExtremeSpread, 0.08],
  [genBoundarySizes, 0.04],
  [genWideRangeForcedMiddle, 0.04],
];
function pickGenerator(){
  let r=Math.random(), acc=0;
  for(const [fn,w] of GENERATORS){ acc+=w; if(r<=acc) return fn; }
  return GENERATORS[0][0];
}

// ---------------------------------------------------------------------------
// RUN
// ---------------------------------------------------------------------------
const TRIALS = parseInt(process.argv[2]||'150000',10);
const perTag = {};
let totalComparable=0, totalCapped=0;
let hViolations=0;
let hTighterCount=0, hTighterSum=0, hTighterMax=0;
let hLooserCount=0; // sanity: how often is existing bound already tighter than ubH
const hWorstViolations=[];
const hBiggestTightenings=[];

for(let t=0;t<TRIALS;t++){
  const gen = pickGenerator();
  const {pool, form, tag} = gen();
  if(!perTag[tag]) perTag[tag]={n:0, capped:0, hViolations:0, hTighterCount:0, hTighterSum:0, hTighterMax:0, hLooserCount:0, firstViolation:null};
  const S = perTag[tag];

  let existingUB, hVal, bestRes;
  try { existingUB = maxPossibleRating(pool, form); } catch(e){ continue; }
  try { hVal = ubH(pool, form); } catch(e){ hVal = undefined; }
  try { bestRes = bruteForceMax(pool, form.slots); } catch(e){ continue; }
  if(!bestRes || bestRes.capped){ totalCapped++; S.capped++; continue; }
  const best = bestRes.best;
  if(best===null) continue;          // no legal XI exists under this draft at all
  if(existingUB===null) continue;    // shouldn't happen if best exists, but guard

  totalComparable++; S.n++;
  const bestFloored = Math.floor(best);

  if(hVal!==null && hVal!==undefined){
    const hFloored = Math.floor(hVal);
    const hGap = hFloored - bestFloored;
    if(hGap < -EPS){
      S.hViolations++; hViolations++;
      if(hWorstViolations.length<8) hWorstViolations.push({tag,pool,form,best,hVal});
    }
    const combinedNew = Math.min(existingUB, hFloored);
    if(combinedNew < existingUB - EPS){
      S.hTighterCount++; hTighterCount++;
      const delta = existingUB - combinedNew;
      S.hTighterSum += delta; hTighterSum += delta;
      if(delta>S.hTighterMax) S.hTighterMax = delta;
      if(delta>hTighterMax) hTighterMax = delta;
      if(hBiggestTightenings.length<8 || delta>hBiggestTightenings[hBiggestTightenings.length-1].delta){
        hBiggestTightenings.push({tag,delta,existingUB,hFloored,best,pool,form});
        hBiggestTightenings.sort((a,b)=>b.delta-a.delta);
        if(hBiggestTightenings.length>8) hBiggestTightenings.length=8;
      }
    } else if(hFloored > existingUB + EPS){
      S.hLooserCount++; hLooserCount++;
    }
  }
}

function pct(n,d){return d?(100*n/d).toFixed(2)+'%':'n/a';}

console.log('=== UB-H FUZZ: prototype vs brute-force oracle, and vs existing shipped maxPossibleRating() ===');
console.log('trials requested:', TRIALS, ' | comparable:', totalComparable, ' | oracle gave up (skipped):', totalCapped);
console.log('');
console.log('UB-H SOUNDNESS VIOLATIONS (must be 0 to be safe to ship):', hViolations);
console.log('trials where min(existing, UB-H) tightens the shipped bound:', hTighterCount, pct(hTighterCount,totalComparable));
console.log('avg tightening when it happens:', hTighterCount?(hTighterSum/hTighterCount).toFixed(4):'n/a', ' | max tightening observed:', hTighterMax.toFixed(4));
console.log('trials where UB-H alone is LOOSER than the existing bound:', hLooserCount, pct(hLooserCount,totalComparable));

if(hWorstViolations.length){
  console.log('\n!!! UB-H VIOLATIONS FOUND (undercounts true max -- UNSAFE) !!!');
  for(const v of hWorstViolations) console.log('  ', JSON.stringify(v));
}

console.log('\nPer-scenario breakdown:');
const tags=Object.keys(perTag).sort((a,b)=>perTag[b].n-perTag[a].n);
for(const tag of tags){
  const S=perTag[tag];
  console.log(`\n[${tag}]  n=${S.n}  (oracle capped: ${S.capped})`);
  console.log('  UB-H violations:', S.hViolations, S.hViolations?'  <<< CRITICAL':'');
  console.log('  tightens combined bound:', S.hTighterCount, pct(S.hTighterCount,S.n), ' avg=',(S.hTighterCount?(S.hTighterSum/S.hTighterCount).toFixed(4):'n/a'), ' max=',S.hTighterMax.toFixed(4));
  console.log('  UB-H looser than existing:', S.hLooserCount, pct(S.hLooserCount,S.n));
  if(S.firstViolation) console.log('  FIRST VIOLATION:', JSON.stringify(S.firstViolation));
}

console.log('\n=== TOP TIGHTENING CASES (where UB-H beats the existing shipped bound the most) ===');
for(let i=0;i<hBiggestTightenings.length;i++){
  const w=hBiggestTightenings[i];
  console.log(`\n#${i+1} [${w.tag}] delta=${w.delta.toFixed(3)}  existing=${w.existingUB}  ubH_floored=${w.hFloored}  true_best=${w.best.toFixed(3)}`);
  console.log('  slots:', JSON.stringify(w.form.slots));
  console.log('  pool:', JSON.stringify(w.pool));
}

const fs=require('fs');
fs.writeFileSync(process.argv[3]||'ubh_fuzz_stats.json', JSON.stringify({
  totalComparable, totalCapped, perTag, hViolations, hTighterCount, hTighterSum, hTighterMax, hLooserCount,
  hWorstViolations, hBiggestTightenings
}, null, 2));
