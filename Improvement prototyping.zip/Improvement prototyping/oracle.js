'use strict';
const {futRatingRaw} = require('./existing_ub_module.js');

// Exact brute force: DFS over formation slots (processed fewest-candidates-first for pruning),
// picking a distinct real card for each slot such that (a) the card is eligible for that slot's
// position and (b) no two slots share a hold-group (a card with no hold is its own singleton
// group, so it can still only be used once). Returns {best, capped} — capped=true means the node
// budget ran out before exhausting the search, so the result can't be trusted as exact and the
// caller should skip that trial (matches the original harness's "oracle gave up" semantics).
function bruteForceMax(pool, slots, nodeCap){
  nodeCap = nodeCap || 300000;
  const N = slots.length;
  const groupOf = c=>c.hold||('C'+c.id);
  const candsPerSlot = slots.map(pos=>pool.filter(c=>c.pos&&c.pos.includes(pos)));
  if(candsPerSlot.some(c=>c.length===0)) return {best:null, capped:false};

  const order = [...Array(N).keys()].sort((a,b)=>candsPerSlot[a].length-candsPerSlot[b].length);
  let bestVal = -Infinity;
  let nodeCount = 0;
  let capped = false;
  const usedGroups = new Set();
  const chosen = [];

  function dfs(i){
    if(capped) return;
    nodeCount++;
    if(nodeCount>nodeCap){ capped=true; return; }
    if(i===N){
      const val = futRatingRaw(chosen);
      if(val>bestVal) bestVal=val;
      return;
    }
    const slotIdx = order[i];
    for(const c of candsPerSlot[slotIdx]){
      const g = groupOf(c);
      if(usedGroups.has(g)) continue;
      usedGroups.add(g);
      chosen.push(c.rating);
      dfs(i+1);
      chosen.pop();
      usedGroups.delete(g);
      if(capped) return;
    }
  }
  dfs(0);
  if(bestVal===-Infinity) return {best:null, capped};
  return {best:bestVal, capped};
}

module.exports={bruteForceMax};
