'use strict';
const {spMaxBoundPerSlot} = require('./ubh2_prototype.js');

function randInt(a,b){return a+Math.floor(Math.random()*(b-a+1));}
function spOf(vals){
  const S=vals.reduce((a,b)=>a+b,0), A=S/vals.length;
  let sp=0; for(const v of vals) if(v>A) sp+=v-A;
  return sp;
}

let violations=0, trials=0;
for(let t=0;t<20000;t++){
  const N=randInt(2,8);
  const bounds=[];
  for(let i=0;i<N;i++){
    const L=randInt(60,90);
    const U=L+randInt(0,39>90-L?90-L:39); // keep within a plausible rating-ish range
    bounds.push({L, U:Math.min(U,99)});
  }
  const maxSum = bounds.reduce((s,b)=>s+b.U,0);
  const minSum = bounds.reduce((s,b)=>s+b.L,0);
  if(maxSum<=minSum) continue;
  const Smax = minSum + Math.random()*(maxSum-minSum); // random feasible sum cap
  trials++;

  const claimed = spMaxBoundPerSlot(bounds, Smax);

  // Independent check: random sampling + local hill-climbing (mass transfer between two
  // coordinates) to try to beat the claimed bound. If claimed is truly the max, nothing here
  // should ever exceed it (beyond float noise).
  let best=-Infinity;
  function project(vals){
    // clamp to box, then if over budget, remove mass from any coordinate with slack (repeat)
    for(let i=0;i<vals.length;i++) vals[i]=Math.max(bounds[i].L, Math.min(bounds[i].U, vals[i]));
    let s=vals.reduce((a,b)=>a+b,0);
    let iter=0;
    while(s>Smax+1e-9 && iter<2000){
      iter++;
      // find a coordinate with room to shrink, shrink it
      let idx=-1;
      for(let i=0;i<vals.length;i++) if(vals[i]>bounds[i].L+1e-9){idx=i;break;}
      if(idx===-1) break;
      const room = vals[idx]-bounds[idx].L;
      const need = s-Smax;
      const cut = Math.min(room, need);
      vals[idx]-=cut;
      s-=cut;
    }
    return vals;
  }
  for(let r=0;r<300;r++){
    let vals = bounds.map(b=>b.L+Math.random()*(b.U-b.L));
    vals = project(vals);
    // local hill-climb: repeatedly try transferring a small amount of mass between a random pair
    for(let iter=0;iter<400;iter++){
      const i=randInt(0,N-1), j=randInt(0,N-1);
      if(i===j) continue;
      const step=(Math.random())*(bounds[i].U-bounds[i].L)*0.2+1e-6;
      const trial=vals.slice();
      trial[i]=Math.min(bounds[i].U, trial[i]+step);
      trial[j]=Math.max(bounds[j].L, trial[j]-step);
      const s=trial.reduce((a,b)=>a+b,0);
      if(s<=Smax+1e-9){
        if(spOf(trial)>spOf(vals)) vals=trial;
      }
    }
    best=Math.max(best, spOf(vals));
  }

  if(best > claimed + 1e-6){
    violations++;
    console.log('VIOLATION: search found', best.toFixed(4), 'but claimed bound was', claimed.toFixed(4));
    console.log('  bounds:', JSON.stringify(bounds), ' Smax:', Smax.toFixed(3));
  }
}
console.log('trials:', trials, ' violations (search beat the claimed bound):', violations);
