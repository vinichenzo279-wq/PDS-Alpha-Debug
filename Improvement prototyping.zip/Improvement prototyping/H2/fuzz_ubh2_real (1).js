'use strict';
// Fuzz UB-H2 at the ACTUAL problem scale, not a toy scale:
//   - 23 cards in the pool (a real draft pool size)
//   - at most 5 cards share any one hold-group (a real hold-group cap)
//   - exactly 11 formation slots, laid out as real position-dependent formations
//   - ratings span the real range, 60-104 (not the old 60-99 assumption)
//
// Checks, per trial:
//   1) SOUNDNESS: ubH2 must never fall below the true brute-force-oracle max (floored). This is
//      the only thing that matters for shipping -- everything else is a quality-of-bound metric.
//   2) Whether ubH2 is strictly tighter than ubH (the global-Lmin/Umax version already in
//      production candidate form) and/or tighter than the currently-shipped min(A..E) bound.
//   3) Timing: ubH2 must stay fast (it's a pre-search bound, not part of the DFS), so we track
//      wall-clock time per call and flag anything that looks like it could blow up.

const {maxPossibleRating} = require('./existing_ub_module.js');
const {bruteForceMax} = require('./oracle.js');
const {ubH} = require('./ubh_prototype.js');
const {ubH2} = require('./ubh2_prototype.js');

function randInt(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
function choice(arr) { return arr[randInt(0, arr.length - 1)]; }
function shuffle(arr) { const c = arr.slice(); for (let i = c.length - 1; i > 0; i--) { const j = randInt(0, i); [c[i], c[j]] = [c[j], c[i]]; } return c; }

const RATING_MIN = 60, RATING_MAX = 104;
const POOL_SIZE = 23;
const HOLD_CAP = 5;

// Real 11-slot formations (position-dependent, not abstract letters).
const FORMATIONS = [
  ['GK','RB','CB','CB','LB','CDM','CM','CM','RW','ST','LW'],           // 4-3-3
  ['GK','RB','CB','CB','LB','RM','CM','CM','LM','ST','ST'],            // 4-4-2
  ['GK','CB','CB','CB','RM','CM','CM','CM','LM','ST','ST'],            // 3-5-2
  ['GK','RB','CB','CB','LB','CDM','CDM','CAM','RM','LM','ST'],         // 4-2-3-1
  ['GK','RB','CB','CB','CB','LB','CM','CM','CM','ST','ST'],            // 5-3-2
  ['GK','RB','CB','CB','LB','CM','CM','RW','LW','ST','CAM'],           // 4-3-3 (attacking mid variant)
];

// Realistic position-family map for versatility (2nd/3rd positions a card can also cover).
const FAMILY = {
  GK:['GK'], CB:['CB'], RB:['RB','RWB','RM'], LB:['LB','LWB','LM'],
  RWB:['RWB','RB','RM'], LWB:['LWB','LB','LM'],
  CDM:['CDM','CM'], CM:['CM','CDM','CAM'], CAM:['CAM','CM','RW','LW'],
  RM:['RM','RW','RB'], LM:['LM','LW','LB'],
  RW:['RW','RM','CAM'], LW:['LW','LM','CAM'],
  ST:['ST','CF'], CF:['CF','ST','CAM'],
};
const ALL_POS = Object.keys(FAMILY);

// A real draft pool is centered on the formation being built (most cards eligible for one of its
// slots), with only a minority of off-formation filler. `slots` biases the base position choice
// so we don't waste most of a 23-card pool on positions the formation never uses -- that was
// causing spurious "no legal XI" trials that silently contributed nothing to the fuzz.
function makeCardPositions(slots) {
  const base = (slots && Math.random() < 0.8) ? choice(slots) : choice(ALL_POS);
  const pos = new Set([base]);
  const r = Math.random();
  const extras = FAMILY[base].filter(p => p !== base);
  if (r < 0.35 && extras.length) pos.add(choice(extras));
  if (r < 0.10 && extras.length > 1) pos.add(choice(extras));
  return [...pos];
}

// Guarantee every distinct position the formation needs has at least (need+1) eligible cards in
// the pool, by topping up from the pool itself (adding the position to a random filler card) if
// a real random draw left it short. This keeps trials feasible without hand-scripting the pool.
function ensureCoverage(pool, slots) {
  const need = {};
  for (const s of slots) need[s] = (need[s] || 0) + 1;
  for (const p of Object.keys(need)) {
    let have = pool.filter(c => c.pos.includes(p)).length;
    let guard = 0;
    while (have < need[p] + 1 && guard < 50) {
      guard++;
      const c = choice(pool);
      if (!c.pos.includes(p)) { c.pos = [...c.pos, p]; have++; }
    }
  }
  return pool;
}

// Assign hold-groups respecting the 5-per-hold cap. Returns a hold id or null (own singleton).
function makeHoldAssigner() {
  const counts = {};
  const GROUP_IDS = ['H1','H2','H3','H4','H5','H6','H7','H8'];
  return function assign() {
    if (Math.random() < 0.3) return null; // no hold restriction on this card
    const open = GROUP_IDS.filter(g => (counts[g]||0) < HOLD_CAP);
    if (!open.length) return null;
    const g = choice(open);
    counts[g] = (counts[g]||0) + 1;
    return g;
  };
}

function genRealisticRandom() {
  const slots = choice(FORMATIONS);
  const assign = makeHoldAssigner();
  const pool = [];
  for (let i = 0; i < POOL_SIZE; i++) {
    pool.push({ id: i, rating: randInt(RATING_MIN, RATING_MAX), pos: makeCardPositions(slots), hold: assign() });
  }
  return { pool: ensureCoverage(pool, slots), form: { slots }, tag: 'realistic_random' };
}

// Stress UB-H2's specific claim: one slot's position is scarce (narrow, low-ceiling eligible
// pool) while others are rich (wide, high-ceiling), still within the 23-card/5-hold-cap/11-slot
// real constraints.
function genRealisticScarcity() {
  const slots = choice(FORMATIONS);
  const scarcePos = choice(slots);
  const richPos = choice(slots.filter(p => p !== scarcePos)) || slots[0];
  const assign = makeHoldAssigner();
  const pool = [];
  let id = 0;
  const nScarce = randInt(2, 4);
  for (let i = 0; i < nScarce; i++) {
    pool.push({ id: id++, rating: randInt(RATING_MIN, RATING_MIN + 10), pos: [scarcePos], hold: assign() });
  }
  const nRich = randInt(6, 10);
  for (let i = 0; i < nRich; i++) {
    const versatile = Math.random() < 0.15;
    const pos = versatile ? [richPos, scarcePos] : [richPos];
    pool.push({ id: id++, rating: randInt(RATING_MAX - 25, RATING_MAX), pos, hold: assign() });
  }
  while (pool.length < POOL_SIZE) {
    pool.push({ id: id++, rating: randInt(RATING_MIN, RATING_MAX), pos: makeCardPositions(slots), hold: assign() });
  }
  return { pool: ensureCoverage(pool.slice(0, POOL_SIZE), slots), form: { slots }, tag: 'realistic_scarcity' };
}

// Bimodal rating distribution to stress the spread term specifically.
function genRealisticExtremeSpread() {
  const slots = choice(FORMATIONS);
  const assign = makeHoldAssigner();
  const pool = [];
  for (let i = 0; i < POOL_SIZE; i++) {
    const rating = Math.random() < 0.2 ? randInt(RATING_MAX - 8, RATING_MAX) : randInt(RATING_MIN, RATING_MIN + 6);
    pool.push({ id: i, rating, pos: makeCardPositions(slots), hold: assign() });
  }
  return { pool: ensureCoverage(pool, slots), form: { slots }, tag: 'realistic_extreme_spread' };
}

// A dominant hold-group at the 5-card cap boundary itself.
function genRealisticHoldCapBoundary() {
  const slots = choice(FORMATIONS);
  const pool = [];
  let id = 0;
  const dominantPositions = shuffle(slots).slice(0, randInt(2, 4));
  for (let i = 0; i < HOLD_CAP; i++) {
    pool.push({ id: id++, rating: randInt(RATING_MAX - 20, RATING_MAX), pos: [choice(dominantPositions)], hold: 'H_CAP' });
  }
  const assign = makeHoldAssigner();
  while (pool.length < POOL_SIZE) {
    pool.push({ id: id++, rating: randInt(RATING_MIN, RATING_MAX), pos: makeCardPositions(slots), hold: assign() });
  }
  return { pool: ensureCoverage(pool.slice(0, POOL_SIZE), slots), form: { slots }, tag: 'realistic_hold_cap_boundary' };
}

const GENERATORS = [
  [genRealisticRandom, 0.35],
  [genRealisticScarcity, 0.35],
  [genRealisticExtremeSpread, 0.20],
  [genRealisticHoldCapBoundary, 0.10],
];
function pickGenerator() {
  let r = Math.random(), acc = 0;
  for (const [fn, w] of GENERATORS) { acc += w; if (r <= acc) return fn; }
  return GENERATORS[0][0];
}

const EPS = 1e-6;
const TRIALS = parseInt(process.argv[2] || '2000', 10);
const NODE_CAP = parseInt(process.argv[3] || '400000', 10);

let comparable = 0, capped = 0, infeasible = 0;
let h2Violations = 0;
let h2TighterThanH = 0, h2TighterThanShipped = 0;
let totalUbH2Ms = 0, maxUbH2Ms = 0;
const violExamples = [];
const perTag = {};

for (let t = 0; t < TRIALS; t++) {
  const gen = pickGenerator();
  const { pool, form, tag } = gen();
  if (!perTag[tag]) perTag[tag] = { n: 0, violations: 0, tighterThanH: 0, tighterThanShipped: 0 };
  const S = perTag[tag];

  let existingUB, hVal, h2Val, bestRes;
  try { existingUB = maxPossibleRating(pool, form); } catch (e) { continue; }
  try { hVal = ubH(pool, form); } catch (e) { hVal = undefined; }

  const t0 = process.hrtime.bigint();
  try { h2Val = ubH2(pool, form); } catch (e) { h2Val = undefined; }
  const t1 = process.hrtime.bigint();
  const ms = Number(t1 - t0) / 1e6;
  totalUbH2Ms += ms;
  if (ms > maxUbH2Ms) maxUbH2Ms = ms;

  try { bestRes = bruteForceMax(pool, form.slots, NODE_CAP); } catch (e) { continue; }
  if (!bestRes || bestRes.capped) { capped++; continue; }
  const best = bestRes.best;
  if (best === null || existingUB === null) { infeasible++; continue; }

  comparable++; S.n++;
  const bestFloored = Math.floor(best);

  if (h2Val !== null && h2Val !== undefined) {
    const h2Floored = Math.floor(h2Val);
    if (h2Floored < bestFloored - EPS) {
      h2Violations++; S.violations++;
      if (violExamples.length < 6) violExamples.push({ tag, pool, form, best, h2Val });
    }
    if (hVal !== null && hVal !== undefined) {
      const hFloored = Math.floor(hVal);
      if (h2Floored < hFloored - EPS) { h2TighterThanH++; S.tighterThanH++; }
    }
    if (h2Floored < existingUB - EPS) { h2TighterThanShipped++; S.tighterThanShipped++; }
  }
}

function pct(n, d) { return d ? (100 * n / d).toFixed(2) + '%' : 'n/a'; }

console.log('=== UB-H2 REALISTIC-SCALE FUZZ (23 cards, 5-per-hold cap, 11 position-dependent slots, ratings 60-104) ===');
console.log('trials:', TRIALS, ' comparable:', comparable, ' oracle capped/skipped:', capped, ' infeasible (no legal XI):', infeasible);
console.log('UB-H2 SOUNDNESS VIOLATIONS (must be 0 to ship):', h2Violations);
console.log('UB-H2 strictly tighter than UB-H (global bounds):', h2TighterThanH, pct(h2TighterThanH, comparable));
console.log('UB-H2 strictly tighter than shipped min(A..E):', h2TighterThanShipped, pct(h2TighterThanShipped, comparable));
console.log('ubH2() timing: avg=', (totalUbH2Ms / Math.max(1,comparable+capped)).toFixed(3), 'ms  max=', maxUbH2Ms.toFixed(3), 'ms');
console.log('\nPer-scenario:');
for (const tag of Object.keys(perTag)) {
  const S = perTag[tag];
  console.log(`[${tag}] n=${S.n} violations=${S.violations}${S.violations ? ' <<<CRITICAL' : ''} tighterThanH=${S.tighterThanH}(${pct(S.tighterThanH,S.n)}) tighterThanShipped=${S.tighterThanShipped}(${pct(S.tighterThanShipped,S.n)})`);
}
if (violExamples.length) {
  console.log('\n!!! VIOLATIONS !!!');
  for (const v of violExamples) console.log(JSON.stringify(v));
}
