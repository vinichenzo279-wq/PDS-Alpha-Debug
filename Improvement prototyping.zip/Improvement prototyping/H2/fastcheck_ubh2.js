'use strict';
const {maxPossibleRating} = require('./existing_ub_module.js');
const {bruteForceMax} = require('./oracle.js');
const {ubH} = require('./ubh_prototype.js');
const {ubH2} = require('./ubh2_prototype.js');

function randInt(a,b){return a+Math.floor(Math.random()*(b-a+1));}
function choice(arr){return arr[randInt(0,arr.length-1)];}
function sample(arr,k){const c=arr.slice();const out=[];for(let i=0;i<k&&c.length;i++){out.push(c.splice(randInt(0,c.length-1),1)[0]);}return out;}

const EPS=1e-6;
const posSets=[
  ['P','Q','R','S'],
  ['GK','CB','RB','LB','CM','ST'],
  ['A','B','C'],
  ['LB','LM','LW','CM'],
];

function genRandom(){
  const posAlphabet=[...new Set(choice(posSets))];
  const N=randInt(1,7);
  const slots=[];for(let i=0;i<N;i++)slots.push(choice(posAlphabet));
  const poolSize=randInt(N, N+7);
  const pool=[];
  for(let i=0;i<poolSize;i++){
    const nPos = Math.random()<0.3 ? randInt(2,3) : 1;
    const pos = sample(posAlphabet, Math.min(nPos, posAlphabet.length));
    if(!pos.length) continue;
    const hold = Math.random()<0.35 ? choice(['H1','H2','H3','H4']) : null;
    pool.push({id:i, rating: randInt(60,99), pos, hold});
  }
  return {pool, form:{slots}, tag:'random_baseline'};
}

// Targets UB-H2's specific claim: give ONE position a narrow, low, scarce eligible pool while
// OTHER positions have wide, high-ceiling eligible pools -- global Lmin/Umax gets dragged wide by
// the other positions, but the scarce position's own true range should be much tighter.
function genPositionScarcity(){
  const posAlphabet=[...new Set(choice(posSets))];
  const scarcePos = choice(posAlphabet);
  const richPos = choice(posAlphabet.filter(p=>p!==scarcePos)) || posAlphabet[0];
  const N=randInt(2,6);
  const slots=[]; slots.push(scarcePos); for(let i=1;i<N;i++)slots.push(choice(posAlphabet));
  const pool=[];
  let id=0;
  // scarce position: only cards rated 60-70 are eligible there
  for(let i=0;i<randInt(2,5);i++){
    pool.push({id:id++, rating:randInt(60,70), pos:[scarcePos], hold: Math.random()<0.4?choice(['S1','S2']):null});
  }
  // rich position(s): cards rated up to 99, sometimes versatile enough to also cover scarcePos
  for(let i=0;i<randInt(6,12);i++){
    const versatile = Math.random()<0.15;
    const pos = versatile? sample([...new Set([richPos, scarcePos])],2) : [richPos];
    pool.push({id:id++, rating:randInt(75,99), pos, hold: Math.random()<0.4?choice(['R1','R2','R3']):null});
  }
  // filler for any other slots
  for(let i=0;i<N+randInt(2,6);i++){
    const pos=sample(posAlphabet, Math.random()<0.3?randInt(1,2):1);
    if(!pos.length) continue;
    pool.push({id:id++, rating:randInt(65,95), pos, hold: Math.random()<0.4?choice(['F1','F2']):null});
  }
  return {pool, form:{slots}, tag:'position_scarcity'};
}

function genExtremeSpread(){
  const posAlphabet=[...new Set(choice(posSets))];
  const N=randInt(2,6);
  const slots=[];for(let i=0;i<N;i++)slots.push(choice(posAlphabet));
  const poolSize=randInt(N+3,N+12);
  const pool=[];
  for(let i=0;i<poolSize;i++){
    const rating = Math.random()<0.15 ? randInt(96,99) : randInt(60,65);
    const nPos = Math.random()<0.4?randInt(2,Math.min(3,posAlphabet.length)):1;
    const pos=sample(posAlphabet,Math.min(nPos,posAlphabet.length));
    if(!pos.length)continue;
    const hold=Math.random()<0.5?choice(['H1','H2','H3']):null;
    pool.push({id:i, rating, pos, hold});
  }
  return {pool, form:{slots}, tag:'extreme_rating_spread'};
}

const GENERATORS = [
  [genRandom, 0.35],
  [genPositionScarcity, 0.40],
  [genExtremeSpread, 0.25],
];
function pickGenerator(){
  let r=Math.random(), acc=0;
  for(const [fn,w] of GENERATORS){ acc+=w; if(r<=acc) return fn; }
  return GENERATORS[0][0];
}

const TRIALS = parseInt(process.argv[2]||'6000',10);
let comparable=0, capped=0;
let h2Violations=0, h2TighterThanH=0, h2TighterSum=0, h2TighterMax=0;
let h2TighterThanShipped=0;
const violExamples=[];

for(let t=0;t<TRIALS;t++){
  const gen=pickGenerator();
  const {pool, form, tag} = gen();
  let existingUB, hVal, h2Val, bestRes;
  try { existingUB = maxPossibleRating(pool, form); } catch(e){ continue; }
  try { hVal = ubH(pool, form); } catch(e){ hVal=undefined; }
  try { h2Val = ubH2(pool, form); } catch(e){ h2Val=undefined; }
  try { bestRes = bruteForceMax(pool, form.slots); } catch(e){ continue; }
  if(!bestRes || bestRes.capped){ capped++; continue; }
  const best = bestRes.best;
  if(best===null || existingUB===null) continue;
  comparable++;
  const bestFloored=Math.floor(best);

  if(h2Val!==null && h2Val!==undefined){
    const h2Floored=Math.floor(h2Val);
    if(h2Floored - bestFloored < -EPS){
      h2Violations++;
      if(violExamples.length<6) violExamples.push({tag,pool,form,best,h2Val});
    }
    if(hVal!==null && hVal!==undefined){
      const hFloored=Math.floor(hVal);
      if(h2Floored < hFloored - EPS){ h2TighterThanH++; h2TighterSum += (hFloored-h2Floored); if(hFloored-h2Floored>h2TighterMax) h2TighterMax=hFloored-h2Floored; }
    }
    if(h2Floored < existingUB - EPS) h2TighterThanShipped++;
  }
}

console.log('=== UB-H2 FAST FAIL-FAST CHECK (per-position Lmin/Umax) ===');
console.log('trials:', TRIALS, ' comparable:', comparable, ' oracle capped:', capped);
console.log('UB-H2 VIOLATIONS (must be 0):', h2Violations);
console.log('UB-H2 strictly tighter than UB-H (global bounds):', h2TighterThanH, (comparable?(100*h2TighterThanH/comparable).toFixed(2)+'%':'n/a'),
            ' avg=',(h2TighterThanH?(h2TighterSum/h2TighterThanH).toFixed(3):'n/a'),' max=',h2TighterMax);
console.log('UB-H2 strictly tighter than shipped min(A..E):', h2TighterThanShipped, (comparable?(100*h2TighterThanShipped/comparable).toFixed(2)+'%':'n/a'));
if(violExamples.length){
  console.log('\\nVIOLATION EXAMPLES:');
  for(const v of violExamples) console.log(JSON.stringify(v));
}
