'use strict';
// UB-G attempt 1: instead of collapsing each hold-group to ONE node with a single global-best
// rating (UB-D/E's approach), model the ground set as (group, position) EDGES, each with its own
// position-specific best rating (posBest[g][p] = best rating among the group's members that are
// actually eligible at p). This is real per-card position eligibility, no union-of-positions
// artifact. Constraint: each POSITION can take at most need[p] edges; each GROUP can supply at most
// 1 edge (only one card per hold can ever be fielded). Process edges in descending weight order,
// greedily take an edge if both its position and group still have capacity (Kuhn's-style greedy,
// no augmenting-path backtracking attempted in this first cut -- see caveats in the writeup this
// prototype accompanies).
function ubG(pool, form){
  const slots=form.slots, N=slots.length;
  const need={}; for(const s of slots) need[s]=(need[s]||0)+1;
  const positions=Object.keys(need);
  const elig=pool.filter(c=>c.pos&&c.pos.some(p=>need[p]!==undefined));
  const groupOf=c=>c.hold||('C'+c.id);

  const posBest={}; // posBest[g][p] = best rating of group g's members eligible at position p
  for(const c of elig){
    const g=groupOf(c);
    if(!posBest[g]) posBest[g]={};
    for(const p of c.pos){
      if(need[p]!==undefined){
        if(posBest[g][p]===undefined || c.rating>posBest[g][p]) posBest[g][p]=c.rating;
      }
    }
  }

  const edges=[];
  for(const g in posBest){
    for(const p in posBest[g]){
      edges.push({g, p, w: posBest[g][p]});
    }
  }
  edges.sort((a,b)=>b.w-a.w);

  const posCount={}; for(const p of positions) posCount[p]=0;
  const groupUsed={};
  const chosen=[];
  for(const e of edges){
    if(groupUsed[e.g]) continue;
    if(posCount[e.p]>=need[e.p]) continue;
    groupUsed[e.g]=true;
    posCount[e.p]++;
    chosen.push(e.w);
  }
  if(chosen.length<N) return null; // greedy (no augmenting) couldn't complete -- opt out, not a violation
  return require('./gap_lib.js').futRatingRaw(chosen);
}
module.exports={ubG};
