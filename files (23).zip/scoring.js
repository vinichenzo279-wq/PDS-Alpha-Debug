'use strict';
// Extracted VERBATIM from index.html's appendix (prod_solver.js block). Not rewritten.
function futRatingRaw(rs){const S=rs.reduce((a,b)=>a+b,0),A=S/rs.length;let sp=0;for(const r of rs)if(r>A)sp+=r-A;return (S+sp)/rs.length;}
function futRating(rs){return Math.floor(futRatingRaw(rs));}
function leagueOf(c){return c.type==='icon'?'Icons':(c.league||'England Premier League')}
function trueChem(xi){
  const natCnt={},clubCnt={},lgCnt={};let icons=0,normals=0;
  xi.forEach(c=>{
    if(c.type==='icon'){
      icons++;
      natCnt[c.nation]=(natCnt[c.nation]||0)+2;
    } else if(c.type==='hero'){
      natCnt[c.nation]=(natCnt[c.nation]||0)+1;
      const lg=leagueOf(c);
      lgCnt[lg]=(lgCnt[lg]||0)+2;
    } else {
      normals++;
      natCnt[c.nation]=(natCnt[c.nation]||0)+1;
      clubCnt[c.club]=(clubCnt[c.club]||0)+1;
      const nlg=leagueOf(c);lgCnt[nlg]=(lgCnt[nlg]||0)+1;
    }
  });
  if(icons>0){for(const lg of Object.keys(lgCnt))lgCnt[lg]+=icons;}
  const nP=n=>n>=8?3:n>=5?2:n>=2?1:0;
  const cP=n=>n>=7?3:n>=4?2:n>=2?1:0;
  const lP=n=>n>=8?3:n>=5?2:n>=3?1:0;
  let t=0;
  xi.forEach(c=>{
    if(c.type==='icon'||c.type==='hero'){t+=3;return;}
    const lg=leagueOf(c);
    const lgScore=lP(lgCnt[lg]||0);
    t+=Math.min(3,nP(natCnt[c.nation]||0)+cP(clubCnt[c.club]||0)+lgScore);
  });
  return t;
}
function scoreXI(xi){
  const ratingExact=futRatingRaw(xi.map(c=>c.rating)),rating=Math.floor(ratingExact);
  const nations=new Set(xi.map(c=>c.nation)).size;
  const leagues=new Set(xi.map(leagueOf)).size;
  const premClubs=new Set(xi.filter(c=>c.type==='normal').map(c=>c.club)).size;
  const hasIcon=xi.some(c=>c.type==='icon'),hasHero=xi.some(c=>c.type==='hero');
  const clubs=premClubs+(hasIcon?1:0)+(hasHero?1:0);
  const glue=xi.filter(c=>c.type==='icon'||c.type==='normal').length;
  const _lgPool={};let _icons=0;
  xi.forEach(c=>{if(c.type==='icon'){_icons++;return;}const L=leagueOf(c);_lgPool[L]=(_lgPool[L]||0)+(c.type==='hero'?2:1);});
  let _bestPool=0;for(const L in _lgPool)if(_lgPool[L]>_bestPool)_bestPool=_lgPool[L];
  const premPool=_bestPool+_icons;
  const _qualifyingLgs=new Set();for(const L in _lgPool)if(_lgPool[L]>=8)_qualifyingLgs.add(L);
  const _allNormalsQualify=xi.every(c=>c.type!=='normal'||_qualifyingLgs.has(leagueOf(c)));
  const full=(_qualifyingLgs.size>0&&_allNormalsQualify)||xi.every(c=>c.type==='icon'||c.type==='hero');
  const chem=full?3*xi.length:trueChem(xi);
  return {rating,ratingExact,chem,nations,leagues,clubs,full,glue,total:rating+chem+nations+leagues+clubs,
    nationSet:new Set(xi.map(c=>c.nation)),leagueSet:new Set(xi.map(leagueOf)),
    clubSet:new Set(xi.filter(c=>c.type==='normal').map(c=>c.club))};
}
module.exports = { futRatingRaw, futRating, leagueOf, trueChem, scoreXI };
