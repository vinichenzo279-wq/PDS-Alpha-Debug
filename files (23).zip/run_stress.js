'use strict';
const { scoreXI } = require('./scoring');
const { solveBestBase, solveBestR2 } = require('./solvers');
const { bruteForce, estimateCombos } = require('./brute');
const { genSynthetic, mulberry32 } = require('./fuzzgen');

// Stress variant: crank holdP and multiPosP even higher than fuzz_gen's own 'holds'/'multiPos'
// regimes, on the small formations (so brute force stays cheap even at high density), to find
// out where the group-aware live slot max actually pays for itself vs. where it's a no-op.
const RC = 103;
const N = 60;
const BRUTE_TIME_MS = 1500;

function genStress(seed, regime){
  const draft = genSynthetic(seed, regime);
  const rng = mulberry32(seed*7919+13);
  if (regime === 'holds') {
    // re-roll holds at much higher density directly on the generated cards
    for (const c of draft.cards) c.hold = null;
    const loose = draft.cards.slice();
    let hid = 1;
    while (loose.length >= 2 && rng() < 0.9) {
      const size = Math.min(2 + Math.floor(rng()*3), loose.length);
      const gid = 'G'+(hid++);
      for (let i=0;i<size;i++){ const j=Math.floor(rng()*loose.length); loose[j].hold=gid; loose.splice(j,1); }
    }
  } else if (regime === 'multiPos') {
    const posList = [...new Set(draft.cards.map(c=>c.pos[0]).concat(draft.form.slots))];
    for (const c of draft.cards) {
      if (rng() < 0.85) {
        const extra = posList[Math.floor(rng()*posList.length)];
        if (!c.pos.includes(extra)) c.pos.push(extra);
        if (rng() < 0.5) { const extra2 = posList[Math.floor(rng()*posList.length)]; if (!c.pos.includes(extra2)) c.pos.push(extra2); }
      }
    }
  }
  for (const c of draft.cards) { c._lg = undefined; c._group = undefined; } // reset caches
  return draft;
}

let tested=0, skipped=0, mismatches=0;
let baseNodes=0, r2Nodes=0, better=0, worse=0, tie=0;
let seed=100000;
for (const regime of ['holds','multiPos']) {
  let n=0, attempts=0;
  while (n < N && attempts < N*20) {
    attempts++; seed++;
    const draft = genStress(seed, regime);
    const { form, cards } = draft;
    const combos = estimateCombos(form, cards);
    if (combos===0 || combos>2_000_000) continue;
    const brute = bruteForce(form, cards, scoreXI, {timeBudgetMs:BRUTE_TIME_MS});
    if (!brute.complete) continue;
    const base = solveBestBase(form, cards, 50_000_000, RC);
    const r2 = solveBestR2(form, cards, 50_000_000, RC);
    if (base.error || r2.error) continue;
    n++; tested++;
    if (base.best!==brute.best || r2.best!==brute.best) {
      mismatches++;
      console.log('MISMATCH', regime, seed, 'brute=',brute.best,'base=',base.best,'r2=',r2.best);
    }
    baseNodes+=base.nodes; r2Nodes+=r2.nodes;
    if (r2.nodes<base.nodes) better++; else if (r2.nodes>base.nodes) worse++; else tie++;
  }
  console.log(regime, ': tested', n, 'of', attempts, 'attempts');
}
console.log('\n=== STRESS RESULTS (holds + multiPos, amplified density) ===');
console.log('tested:', tested, 'mismatches:', mismatches);
console.log('base nodes:', baseNodes, ' r2 nodes:', r2Nodes,
  ' (' + (100*(1-r2Nodes/baseNodes)).toFixed(2) + '% fewer)');
console.log('better:', better, 'worse:', worse, 'tied:', tie);
