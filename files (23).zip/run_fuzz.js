'use strict';
const { scoreXI } = require('./scoring');
const { solveBestBase, solveBestR2 } = require('./solvers');
const { bruteForce, estimateCombos } = require('./brute');
const { generate, REGIMES } = require('./fuzzgen');

const N_PER_REGIME = 20;          // trials per regime -> 11*20 = 220 drafts
const RC = 103;                   // "loose 103" -- same convention section R's own fuzz used
const COMBO_SKIP = 1_500_000;      // skip brute-forcing anything absurd (kitchenSink can spike)
const BRUTE_TIME_MS = 1500;

let tested = 0, skipped = 0, mismatches = 0;
let baseNodesTotal = 0, r2NodesTotal = 0;
let baseTimeTotal = 0, r2TimeTotal = 0;
let scanStepsTotal = 0, dynEvalsTotal = 0;
let r2StrictlyBetter = 0, r2StrictlyWorse = 0, tieCount = 0;
const perRegime = {};
for (const r of REGIMES) perRegime[r] = { tested: 0, baseNodes: 0, r2Nodes: 0, better: 0, worse: 0 };

let seed = 1;
for (const regime of REGIMES) {
  for (let i = 0; i < N_PER_REGIME; i++) {
    seed++;
    const draft = require('./fuzzgen').genSynthetic(seed, regime);
    const { form, cards } = draft;

    const combos = estimateCombos(form, cards);
    if (combos === 0 || combos > COMBO_SKIP) { skipped++; continue; }

    const brute = bruteForce(form, cards, scoreXI, { timeBudgetMs: BRUTE_TIME_MS });
    if (!brute.complete) { skipped++; continue; }

    const t0 = process.hrtime.bigint();
    const base = solveBestBase(form, cards, 50_000_000, RC);
    const t1 = process.hrtime.bigint();
    const r2 = solveBestR2(form, cards, 50_000_000, RC);
    const t2 = process.hrtime.bigint();

    if (base.error || r2.error) { skipped++; continue; }

    tested++;
    perRegime[regime].tested++;

    // ---- SOUNDNESS: both variants must match the independent brute-force oracle ----
    if (base.best !== brute.best || r2.best !== brute.best) {
      mismatches++;
      console.log('MISMATCH seed=' + seed + ' regime=' + regime +
        ' brute=' + brute.best + ' base=' + base.best + ' r2=' + r2.best);
    }

    baseNodesTotal += base.nodes; r2NodesTotal += r2.nodes;
    baseTimeTotal += Number(t1 - t0); r2TimeTotal += Number(t2 - t1);
    scanStepsTotal += (r2.scanSteps || 0); dynEvalsTotal += (r2.dynEvals || 0);
    perRegime[regime].baseNodes += base.nodes;
    perRegime[regime].r2Nodes += r2.nodes;

    if (r2.nodes < base.nodes) { r2StrictlyBetter++; perRegime[regime].better++; }
    else if (r2.nodes > base.nodes) { r2StrictlyWorse++; perRegime[regime].worse++; }
    else tieCount++;
  }
}

console.log('\n================ RESULTS ================');
console.log('Drafts tested:', tested, '| skipped (combo/time):', skipped);
console.log('Soundness mismatches (base or r2 vs brute):', mismatches, '/', tested);
console.log('');
console.log('Node counts -- BASE (UB-R) total:', baseNodesTotal, ' R2 total:', r2NodesTotal,
  ' (R2/BASE = ' + (r2NodesTotal / baseNodesTotal * 100).toFixed(2) + '%)');
console.log('R2 strictly fewer nodes:', r2StrictlyBetter, '| strictly more:', r2StrictlyWorse, '| tied:', tieCount);
console.log('');
console.log('Wall time (ms) -- BASE total:', (baseTimeTotal/1e6).toFixed(1), ' R2 total:', (r2TimeTotal/1e6).toFixed(1),
  ' (R2/BASE = ' + (r2TimeTotal/baseTimeTotal*100).toFixed(2) + '%)');
console.log('Avg scan-steps per dynRC evaluation (R2 only):', (scanStepsTotal / Math.max(1,dynEvalsTotal)).toFixed(3),
  '  (1.0 = always found on first try, i.e. free)');
console.log('');
console.log('Per-regime breakdown (nodes: base -> r2, node reduction %):');
for (const r of REGIMES) {
  const p = perRegime[r];
  if (!p.tested) { console.log('  ' + r.padEnd(12) + ' (0 tested)'); continue; }
  const redux = p.baseNodes > 0 ? (100 * (1 - p.r2Nodes / p.baseNodes)) : 0;
  console.log('  ' + r.padEnd(12) + ' n=' + String(p.tested).padEnd(3) +
    '  ' + String(p.baseNodes).padStart(8) + ' -> ' + String(p.r2Nodes).padStart(8) +
    '   (' + redux.toFixed(2) + '% fewer)   better=' + p.better + ' worse=' + p.worse);
}
