# UB-R2: a live, group-aware refinement of UB-R's per-node dynamic rating cap

Status: PROTOTYPE, off-tree, fuzz-verified at a "first pass" scale (same status UB-R itself
had before its full merge). Not yet run against the real off-tree twelve-regime harness +
fingerprint fixtures — see "What's NOT done yet" below before this goes anywhere near the
live file.

## The idea

UB-R's per-node dynRC vector is:

```
dynRC = floor(futRatingRaw( [ratings of the k committed picks] concat
                            [__slotMaxR[slot] for each remaining slot] ))
```

`__slotMaxR` is precomputed **once**, before the search starts: the single highest rating in
each slot's whole candidate list, full stop. It never looks at `usedGroups` — the very Set
that's already sitting in scope at every node, tracking which hold-groups the *committed*
picks have already consumed.

That's real, structural slack: if a remaining slot's global-max candidate happens to share a
hold group with (or literally *be*) a card already placed higher up the path — because it's
eligible for two slots, or it's in a hold pair with something already picked — `__slotMaxR`
keeps crediting that card's rating to the remaining slot as if it were still available. This
is exactly the same shape of over-count UB-A had before UB-C fixed it for the static root
bound (a versatile/held card getting counted more than once), just showing up in the dynamic
per-node vector this time.

**UB-R2** replaces the stale global lookup with a live one: for each remaining slot, scan its
(already ratings-descending-sorted) candidate list and take the rating of the first candidate
whose group is **not** in `usedGroups`. Because the list is already sorted, this is a
short scan with early exit — usually resolves on the very first element — not a re-sort or a
matching computation.

```js
// UB-R2: live, usedGroups-aware slot max (replaces __slotMaxR[slot])
let m = 0;
for (const c of cand[slot]) { if (!usedGroups.has(c._group)) { m = c.rating; break; } }
```

## Soundness argument

Same proof shape as UB-R itself (component-wise dominance + `futRatingRaw` monotonicity),
with one more case to close:

- **Committed entries** (`j < k`): unchanged, exact.
- **Remaining entries with an available candidate**: the live scan finds the true best
  rating among candidates *not already ruled out by the committed path* — this is a tighter
  (lower-or-equal) but still valid upper bound on what that slot could contribute, since any
  real completion's card for that slot must, by construction, avoid every group already used
  by the committed picks.
- **Remaining entries where every candidate is already used up** (`m` stays `0`): this can
  only happen when the slot has **zero legal completions** on this path — every card that
  could fill it conflicts with something already committed. There is no real assignment this
  branch could ever produce, so pruning it costs nothing; soundness holds vacuously (nothing
  is lost that could have existed).

`min()` with the static `__slotMaxR`-based bound is not even needed here — UB-R2's vector is
component-wise `<=` UB-R's vector in every case (it's the same relaxation with one more valid
constraint folded in), so UB-R2's dynRC is never looser than UB-R's, by construction, not just
empirically. (Worth stress-testing that claim harder before treating it as proven the way this
file treats its own dominance claims — see section on UB-D/UB-E in section R's own writeup
about a previously-wrong "never looser" claim.)

## Testing methodology (mirrors this file's own section H / appendix)

Built entirely from the file's own appendix, extracted verbatim, not rewritten:
- `scoring.js` — `futRatingRaw`/`leagueOf`/`trueChem`/`scoreXI`, from `prod_solver.js`.
- `solvers.js` — `solveBestBase` (UB-R exactly as merged in v16.13.3) and `solveBestR2`
  (identical except the dynRC vector build), both copied from the harness-twin `solveBest`.
- `brute.js` — `bruteForce`/`estimateCombos`, from `indep_brute.js` verbatim (shares no code
  with the solver except the injected `scoreXI`, per the file's own design intent).
- `fuzzgen.js` — `fuzz_gen.js`'s synthetic generator verbatim, 11 of its 12 regimes (`realDB`
  skipped — needs your actual `playerDB.json`, which isn't in the appendix).
- `run_fuzz.js` / `run_stress.js` — new runners for this comparison.

RC fixed at 103 for every trial (the file's own "loose 103" convention from section R's fuzz
write-up) — always above any real squad's rating here, so any mismatch is attributable to the
solver's own pruning logic, not an under-set ceiling.

## Results

**Main fuzz** (11 regimes × ~18-20 drafts each, 194 drafts actually tested after skipping a
few combo-heavy/timeout cases):
- Soundness: **0/194 mismatches** against the independent brute-force oracle (both UB-R and
  UB-R2 agreed with brute force every time).
- Node count: UB-R2 **never** produced more nodes than UB-R; strictly fewer in 23/194 drafts.
- Aggregate: 6,677,343 → 6,611,990 nodes (0.98% fewer, total across all regimes).
- Per-regime spread was uneven — biggest wins on `dupSlots` (5.55% fewer) and `wide` (3.01%
  fewer), essentially flat on `ties`/`narrow`/`polyMax`/`holds`/`kitchenSink` at this sample
  size.
- Wall time: UB-R2 total was *slightly lower* than UB-R's (99.23%), not higher — the node
  reduction pays for the scan cost. Average scan length per dynRC evaluation: **1.625**,
  i.e. the "right" candidate is usually the first or second one checked. This is a cheap
  tightening in practice, not just in theory.

**Targeted stress run** (`holds` and `multiPos` only, hold-density and multi-position-density
dialed up well past the base generator's own settings, 120 drafts):
- Soundness: **0/120 mismatches**.
- Node count: 5,850,658 → 5,847,268 (0.06% fewer) — smaller than I expected going in, and a
  useful finding on its own: even with hold-groups and multi-position eligibility cranked hard,
  the specific collision this bound targets (a *remaining* slot's own top candidate having
  already been consumed by a *committed* pick) is fairly rare in absolute terms. It never hurt,
  but it's a smaller lever than the naive "holds/multiPos should obviously benefit most"
  intuition suggested — worth recording plainly rather than overselling it.

**Combined: 314 drafts, 0 soundness violations, 0 cases where UB-R2 did worse than UB-R,
35 cases where it did strictly better.**

## Honest assessment (same bar section O held UB-N to)

This is real, not inert like UB-N — node counts do move, and in the right direction only.
But the magnitude is modest (sub-1% to ~5% depending on regime) at this sample size, and it's
cheap enough that it's a "why not" rather than a "must-have": no case so far where it costs
anything, real if unspectacular upside. That's a meaningfully different verdict than UB-N's
literal zero-effect result, but a smaller win than UB-D/E were for the static bound in their
day.

## What's NOT done yet before this could go anywhere near the live file

Following the same discipline section R itself flagged before merging UB-R:
1. Run against the REAL off-tree twelve-regime harness (`test1_tiered.js` equivalent) +
   fingerprint fixtures, not just this session's from-scratch fuzz — this prototype's 314
   drafts is a first pass, not a release-grade sample (UB-R's own pre-merge fuzz was
   80×2=160; this clears that bar but isn't at the ~1,774-draft scale section H's full
   harness runs).
2. Test interaction with `skipTies` (ST) mode and the diversity/parallel-worker wrapper —
   not touched here.
3. Re-run at multiple RC settings (this used a single fixed loose RC=103 throughout; UB-R's
   own writeup measured across RC 95-99 specifically to show the compounding-toward-leaves
   effect — worth checking whether UB-R2's gain also grows with tighter/more realistic RC).
4. If this is judged worth carrying forward, the natural next iteration (call it UB-R3) is
   resolving collisions *among the remaining slots themselves* — right now UB-R2 only checks
   remaining-vs-committed, not remaining-vs-remaining (two different remaining slots can still
   both credit the same uncommitted card). That's the direct per-node analogue of UB-C fixing
   UB-B, and it's a fair next question once this smaller step has been judged worth the
   complexity.

All source files, the write-up, and the two fuzz runners are attached.
