'use strict';
const { futRatingRaw, leagueOf, scoreXI } = require('./scoring');

// ============================================================================
// BASELINE: solveBest exactly as it stands in the file today (UB-R, v16.13.3),
// copied verbatim from the appendix's prod_solver.js / harness-twin copy.
// The only change from the file: no diversity/parallel plumbing (not needed
// for this comparison), those code paths are identical to solveBest.
// ============================================================================
function solveBestBase(form, cards, nodeCap, ratingCeil, opts) {
  opts = opts || {};
  const ST = !!opts.skipTies;
  const RC = ratingCeil !== undefined ? ratingCeil : 99;
  const slots = form.slots;

  const cand = slots.map(s => {
    const list = cards.filter(c => c.pos.includes(s));
    const natCount = {}, clubCount = {};
    for (const c of list) {
      natCount[c.nation] = (natCount[c.nation] || 0) + 1;
      if (c.type === 'normal') clubCount[c.club] = (clubCount[c.club] || 0) + 1;
    }
    return list.map(c => ({ c, k: c.rating + 0.4 / (natCount[c.nation] || 1) + (c.type === 'normal' ? 0.4 / (clubCount[c.club] || 1) : 0) }))
      .sort((a, b) => b.k - a.k).map(x => x.c);
  });
  if (cand.some(l => l.length === 0))
    return { error: 'A slot has no eligible card: ' + slots.filter((s, i) => cand[i].length === 0).join(', ') };

  for (const slot of cand) for (const c of slot) {
    if (c._lg === undefined) c._lg = leagueOf(c);
    if (c._group === undefined) c._group = c.hold || ('C' + c.id);
  }
  const order = slots.map((s, i) => i).sort((a, b) => cand[a].length - cand[b].length);

  const slotTypes = cand.map(list => { const s = new Set(); for (const c of list) s.add(c.type); return s; });
  const slotHeroAllPrem = cand.map(list => {
    const heroes = list.filter(c => c.type === 'hero');
    return heroes.length > 0 && heroes.every(c => c.league === 'England Premier League');
  });
  const MULTI_LG = cards.some(c => c.type === 'normal' && c.league && c.league !== 'England Premier League');
  const N = slots.length;
  const ubBaseline = new Array(N), ubSuffixBase = new Array(N + 1).fill(0);
  const ubTopIconV = new Array(N + 1), ubTopIconI = new Array(N + 1), ubTopIconV2 = new Array(N + 1), ubTopIconI2 = new Array(N + 1);
  const ubTopHeroV = new Array(N + 1), ubTopHeroI = new Array(N + 1), ubTopHeroV2 = new Array(N + 1), ubTopHeroI2 = new Array(N + 1);
  ubTopIconV[N] = -Infinity; ubTopIconI[N] = -1; ubTopIconV2[N] = -Infinity; ubTopIconI2[N] = -1;
  ubTopHeroV[N] = -Infinity; ubTopHeroI[N] = -1; ubTopHeroV2[N] = -Infinity; ubTopHeroI2[N] = -1;
  for (let k = N - 1; k >= 0; k--) {
    const idx = order[k];
    const st = slotTypes[idx];
    const heroBase = (MULTI_LG || !slotHeroAllPrem[idx]) ? 2 : 1;
    let b = -Infinity;
    if (st.has('normal')) b = MULTI_LG ? 3 : 2;
    if (st.has('hero') && b < heroBase) b = heroBase;
    if (st.has('icon') && b < 1) b = 1;
    ubBaseline[k] = b; ubSuffixBase[k] = ubSuffixBase[k + 1] + b;
    let iv = ubTopIconV[k + 1], ii = ubTopIconI[k + 1], iv2 = ubTopIconV2[k + 1], ii2 = ubTopIconI2[k + 1];
    if (st.has('icon')) { const g = 3 - b; if (g > iv) { iv2 = iv; ii2 = ii; iv = g; ii = k; } else if (g > iv2) { iv2 = g; ii2 = k; } }
    ubTopIconV[k] = iv; ubTopIconI[k] = ii; ubTopIconV2[k] = iv2; ubTopIconI2[k] = ii2;
    let hv = ubTopHeroV[k + 1], hi = ubTopHeroI[k + 1], hv2 = ubTopHeroV2[k + 1], hi2 = ubTopHeroI2[k + 1];
    if (st.has('hero')) { const g = 1; if (g > hv) { hv2 = hv; hi2 = hi; hv = g; hi = k; } else if (g > hv2) { hv2 = g; hi2 = k; } }
    ubTopHeroV[k] = hv; ubTopHeroI[k] = hi; ubTopHeroV2[k] = hv2; ubTopHeroI2[k] = hi2;
  }
  let best = -1;
  let bestXIs = [];
  let maxRating = -1;
  let nodes = 0; const CAP = nodeCap || 3000000; let capped = false;
  const usedGroups = new Set(), pick = new Array(slots.length).fill(null);
  const seenNat = new Set(), seenLg = new Set(), seenClub = new Set();
  let partialIcon = 0, partialHero = 0;

  // v16.13.3 UB-R: per-slot max candidate rating, precomputed ONCE, ignoring usedGroups entirely.
  const __slotMaxR = cand.map(l => l.length ? Math.max.apply(null, l.map(c => c.rating)) : 0);

  function dfs(k) {
    if (nodes++ > CAP) { capped = true; return; }
    if (capped) return;
    if (k === order.length) {
      const xi = pick.slice(), sc = scoreXI(xi);
      if (sc.rating > maxRating) maxRating = sc.rating;
      if (sc.total > best) { best = sc.total; const key = xi.map(c => c.id).sort().join(','); bestXIs = [{ xi, sc, foundAt: nodes, key }]; }
      else if (!ST && sc.total === best) {
        const key = xi.map(c => c.id).sort().join(',');
        if (!bestXIs.some(b => (b.key || (b.key = b.xi.map(c => c.id).sort().join(','))) === key)) bestXIs.push({ xi, sc, foundAt: nodes, key });
      }
      return;
    }
    const slotIdx = order[k];
    if (best >= 0) {
      const premUnseen = seenLg.has('England Premier League') ? 0 : 1;
      const total0 = ubSuffixBase[k];
      let bonusGain;
      if (partialIcon && partialHero) { bonusGain = 0; }
      else {
        const ic0v = partialIcon ? 0 : (ubTopIconV[k] > 0 ? ubTopIconV[k] : 0), ic0i = partialIcon ? -1 : ubTopIconI[k];
        const he0v = partialHero ? 0 : (ubTopHeroV[k] > 0 ? ubTopHeroV[k] : 0), he0i = partialHero ? -1 : ubTopHeroI[k];
        let orderA = ic0v;
        if (!partialHero) { if (he0i !== ic0i) orderA += he0v; else orderA += (ubTopHeroV2[k] > 0 ? ubTopHeroV2[k] : 0); }
        let orderB = he0v;
        if (!partialIcon) { if (ic0i !== he0i) orderB += ic0v; else orderB += (ubTopIconV2[k] > 0 ? ubTopIconV2[k] : 0); }
        bonusGain = Math.max(orderA, orderB);
      }
      const ub = RC + 33 + seenNat.size + seenLg.size + seenClub.size + partialIcon + partialHero + total0 + bonusGain + premUnseen;
      if (ST ? ub <= best : ub < best) return;
      // ---- UB-R (baseline, exactly as in the file) ----
      if (best >= 0 && k >= 4) {
        const __v = []; for (let __j = 0; __j < order.length; __j++) __v.push(__j < k ? pick[order[__j]].rating : __slotMaxR[order[__j]]);
        const __d = Math.floor(futRatingRaw(__v));
        if (__d < RC) { const __u = ub - RC + __d; if (ST ? __u <= best : __u < best) return; }
      }
    }
    for (const c of cand[slotIdx]) {
      const g = c._group;
      if (usedGroups.has(g)) continue;
      usedGroups.add(g); pick[slotIdx] = c;
      const addNat = seenNat.has(c.nation) ? 0 : (seenNat.add(c.nation), 1);
      const addLg = seenLg.has(c._lg) ? 0 : (seenLg.add(c._lg), 1);
      const addClub = c.type === 'normal' && !seenClub.has(c.club) ? (seenClub.add(c.club), 1) : 0;
      const addIcon = !partialIcon && c.type === 'icon' ? 1 : 0; if (addIcon) partialIcon = 1;
      const addHero = !partialHero && c.type === 'hero' ? 1 : 0; if (addHero) partialHero = 1;
      dfs(k + 1);
      if (addNat) seenNat.delete(c.nation);
      if (addLg) seenLg.delete(c._lg);
      if (addClub) seenClub.delete(c.club);
      if (addIcon) partialIcon = 0;
      if (addHero) partialHero = 0;
      usedGroups.delete(g); pick[slotIdx] = null;
      if (capped) return;
    }
  }
  dfs(0);
  return { best, bestXIs, nodes, capped, slots, maxRating, rcUsed: RC };
}

// ============================================================================
// UB-R2: identical to the baseline in every respect EXCEPT the dynRC vector
// build. Instead of the precomputed, usedGroups-blind __slotMaxR, each
// remaining slot's contribution is "the highest-rated candidate in this
// slot's (already ratingdesc-sorted) list that isn't in a group already
// consumed on THIS path" -- a live scan with early exit, using the usedGroups
// Set that's already sitting in scope. Cheap in the common case (first
// element usually qualifies); falls back to 0 only when a slot has no
// legal candidate left at all, which means this branch has zero legal
// completions anyway (soundness holds vacuously -- pruning it costs nothing).
// ============================================================================
function solveBestR2(form, cards, nodeCap, ratingCeil, opts) {
  opts = opts || {};
  const ST = !!opts.skipTies;
  const RC = ratingCeil !== undefined ? ratingCeil : 99;
  const slots = form.slots;

  const cand = slots.map(s => {
    const list = cards.filter(c => c.pos.includes(s));
    const natCount = {}, clubCount = {};
    for (const c of list) {
      natCount[c.nation] = (natCount[c.nation] || 0) + 1;
      if (c.type === 'normal') clubCount[c.club] = (clubCount[c.club] || 0) + 1;
    }
    return list.map(c => ({ c, k: c.rating + 0.4 / (natCount[c.nation] || 1) + (c.type === 'normal' ? 0.4 / (clubCount[c.club] || 1) : 0) }))
      .sort((a, b) => b.k - a.k).map(x => x.c);
  });
  if (cand.some(l => l.length === 0))
    return { error: 'A slot has no eligible card: ' + slots.filter((s, i) => cand[i].length === 0).join(', ') };

  for (const slot of cand) for (const c of slot) {
    if (c._lg === undefined) c._lg = leagueOf(c);
    if (c._group === undefined) c._group = c.hold || ('C' + c.id);
  }
  const order = slots.map((s, i) => i).sort((a, b) => cand[a].length - cand[b].length);

  const slotTypes = cand.map(list => { const s = new Set(); for (const c of list) s.add(c.type); return s; });
  const slotHeroAllPrem = cand.map(list => {
    const heroes = list.filter(c => c.type === 'hero');
    return heroes.length > 0 && heroes.every(c => c.league === 'England Premier League');
  });
  const MULTI_LG = cards.some(c => c.type === 'normal' && c.league && c.league !== 'England Premier League');
  const N = slots.length;
  const ubBaseline = new Array(N), ubSuffixBase = new Array(N + 1).fill(0);
  const ubTopIconV = new Array(N + 1), ubTopIconI = new Array(N + 1), ubTopIconV2 = new Array(N + 1), ubTopIconI2 = new Array(N + 1);
  const ubTopHeroV = new Array(N + 1), ubTopHeroI = new Array(N + 1), ubTopHeroV2 = new Array(N + 1), ubTopHeroI2 = new Array(N + 1);
  ubTopIconV[N] = -Infinity; ubTopIconI[N] = -1; ubTopIconV2[N] = -Infinity; ubTopIconI2[N] = -1;
  ubTopHeroV[N] = -Infinity; ubTopHeroI[N] = -1; ubTopHeroV2[N] = -Infinity; ubTopHeroI2[N] = -1;
  for (let k = N - 1; k >= 0; k--) {
    const idx = order[k];
    const st = slotTypes[idx];
    const heroBase = (MULTI_LG || !slotHeroAllPrem[idx]) ? 2 : 1;
    let b = -Infinity;
    if (st.has('normal')) b = MULTI_LG ? 3 : 2;
    if (st.has('hero') && b < heroBase) b = heroBase;
    if (st.has('icon') && b < 1) b = 1;
    ubBaseline[k] = b; ubSuffixBase[k] = ubSuffixBase[k + 1] + b;
    let iv = ubTopIconV[k + 1], ii = ubTopIconI[k + 1], iv2 = ubTopIconV2[k + 1], ii2 = ubTopIconI2[k + 1];
    if (st.has('icon')) { const g = 3 - b; if (g > iv) { iv2 = iv; ii2 = ii; iv = g; ii = k; } else if (g > iv2) { iv2 = g; ii2 = k; } }
    ubTopIconV[k] = iv; ubTopIconI[k] = ii; ubTopIconV2[k] = iv2; ubTopIconI2[k] = ii2;
    let hv = ubTopHeroV[k + 1], hi = ubTopHeroI[k + 1], hv2 = ubTopHeroV2[k + 1], hi2 = ubTopHeroI2[k + 1];
    if (st.has('hero')) { const g = 1; if (g > hv) { hv2 = hv; hi2 = hi; hv = g; hi = k; } else if (g > hv2) { hv2 = g; hi2 = k; } }
    ubTopHeroV[k] = hv; ubTopHeroI[k] = hi; ubTopHeroV2[k] = hv2; ubTopHeroI2[k] = hi2;
  }
  let best = -1;
  let bestXIs = [];
  let maxRating = -1;
  let nodes = 0; const CAP = nodeCap || 3000000; let capped = false;
  const usedGroups = new Set(), pick = new Array(slots.length).fill(null);
  const seenNat = new Set(), seenLg = new Set(), seenClub = new Set();
  let partialIcon = 0, partialHero = 0;

  // instrumentation: total scan-steps spent finding each remaining slot's live
  // max, to measure the added per-node cost directly (not just infer it from
  // wall-clock).
  let scanSteps = 0, dynEvals = 0;

  function dfs(k) {
    if (nodes++ > CAP) { capped = true; return; }
    if (capped) return;
    if (k === order.length) {
      const xi = pick.slice(), sc = scoreXI(xi);
      if (sc.rating > maxRating) maxRating = sc.rating;
      if (sc.total > best) { best = sc.total; const key = xi.map(c => c.id).sort().join(','); bestXIs = [{ xi, sc, foundAt: nodes, key }]; }
      else if (!ST && sc.total === best) {
        const key = xi.map(c => c.id).sort().join(',');
        if (!bestXIs.some(b => (b.key || (b.key = b.xi.map(c => c.id).sort().join(','))) === key)) bestXIs.push({ xi, sc, foundAt: nodes, key });
      }
      return;
    }
    const slotIdx = order[k];
    if (best >= 0) {
      const premUnseen = seenLg.has('England Premier League') ? 0 : 1;
      const total0 = ubSuffixBase[k];
      let bonusGain;
      if (partialIcon && partialHero) { bonusGain = 0; }
      else {
        const ic0v = partialIcon ? 0 : (ubTopIconV[k] > 0 ? ubTopIconV[k] : 0), ic0i = partialIcon ? -1 : ubTopIconI[k];
        const he0v = partialHero ? 0 : (ubTopHeroV[k] > 0 ? ubTopHeroV[k] : 0), he0i = partialHero ? -1 : ubTopHeroI[k];
        let orderA = ic0v;
        if (!partialHero) { if (he0i !== ic0i) orderA += he0v; else orderA += (ubTopHeroV2[k] > 0 ? ubTopHeroV2[k] : 0); }
        let orderB = he0v;
        if (!partialIcon) { if (ic0i !== he0i) orderB += ic0v; else orderB += (ubTopIconV2[k] > 0 ? ubTopIconV2[k] : 0); }
        bonusGain = Math.max(orderA, orderB);
      }
      const ub = RC + 33 + seenNat.size + seenLg.size + seenClub.size + partialIcon + partialHero + total0 + bonusGain + premUnseen;
      if (ST ? ub <= best : ub < best) return;
      // ---- UB-R2: live, usedGroups-aware slot max, cheap early-exit scan ----
      if (best >= 0 && k >= 4) {
        dynEvals++;
        const __v = [];
        for (let __j = 0; __j < order.length; __j++) {
          if (__j < k) { __v.push(pick[order[__j]].rating); continue; }
          const __slot = order[__j];
          const __list = cand[__slot];
          let __m = 0;
          for (let __i = 0; __i < __list.length; __i++) {
            scanSteps++;
            const __c = __list[__i];
            if (!usedGroups.has(__c._group)) { __m = __c.rating; break; }
          }
          __v.push(__m);
        }
        const __d = Math.floor(futRatingRaw(__v));
        if (__d < RC) { const __u = ub - RC + __d; if (ST ? __u <= best : __u < best) return; }
      }
    }
    for (const c of cand[slotIdx]) {
      const g = c._group;
      if (usedGroups.has(g)) continue;
      usedGroups.add(g); pick[slotIdx] = c;
      const addNat = seenNat.has(c.nation) ? 0 : (seenNat.add(c.nation), 1);
      const addLg = seenLg.has(c._lg) ? 0 : (seenLg.add(c._lg), 1);
      const addClub = c.type === 'normal' && !seenClub.has(c.club) ? (seenClub.add(c.club), 1) : 0;
      const addIcon = !partialIcon && c.type === 'icon' ? 1 : 0; if (addIcon) partialIcon = 1;
      const addHero = !partialHero && c.type === 'hero' ? 1 : 0; if (addHero) partialHero = 1;
      dfs(k + 1);
      if (addNat) seenNat.delete(c.nation);
      if (addLg) seenLg.delete(c._lg);
      if (addClub) seenClub.delete(c.club);
      if (addIcon) partialIcon = 0;
      if (addHero) partialHero = 0;
      usedGroups.delete(g); pick[slotIdx] = null;
      if (capped) return;
    }
  }
  dfs(0);
  return { best, bestXIs, nodes, capped, slots, maxRating, rcUsed: RC, scanSteps, dynEvals };
}

module.exports = { solveBestBase, solveBestR2 };
