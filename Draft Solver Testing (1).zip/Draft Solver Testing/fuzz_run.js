'use strict';
// Soundness fuzzer: production solver (verbatim extraction, uncapped, RC = production auto
// maxPossibleRating AND a generous RC=103 control) vs the independent brute forcer, on drafts
// small enough for the brute to finish. Any brute > solver = FINDING with the full draft dumped.
// Resumable: state in fuzz_state.json; run with a wall-clock budget per invocation.
//   node fuzz_run.js <secondsBudget> [maxCombos] [bruteTimeMsPerDraft]
const fs = require('fs');
const P = require('./prod_solver.js');
const B = require('./indep_brute.js');
const G = require('./fuzz_gen.js');

const SECONDS = parseInt(process.argv[2] || '200', 10);
const MAX_COMBOS = parseInt(process.argv[3] || '3000000', 10); // brute does ~0.5-2M checks/sec
const BRUTE_MS = parseInt(process.argv[4] || '30000', 10);
const STATE = '/home/claude/fuzz_state.json';
const FINDINGS = '/home/claude/fuzz_findings.jsonl';

let state = { seed: 1, tested: 0, skippedBig: 0, skippedInfeasible: 0, bruteTimeouts: 0, findings: 0, byRegime: {} };
try { state = JSON.parse(fs.readFileSync(STATE, 'utf8')); } catch (e) {}

const deadline = Date.now() + SECONDS * 1000;

while (Date.now() < deadline) {
  const seed = state.seed++;
  const d = G.generate(seed);
  const est = B.estimateCombos(d.form, d.cards);
  if (est === 0) { state.skippedInfeasible++; continue; }
  if (est > MAX_COMBOS) { state.skippedBig++; continue; }

  // production solver: uncapped (nodeCap far above any possible node count for these sizes),
  // at the production auto RC. Plus an RC=103 control to attribute any miss (UB vs RC).
  let rc = null;
  try { rc = P.maxPossibleRating(d.cards, d.form); } catch (e) { rc = null; }
  const rcUsed = rc === null ? 96 : rc;
  const rs = P.solveBest(d.form, d.cards, 1e9, rcUsed);
  const rs103 = P.solveBest(d.form, d.cards, 1e9, 103);

  const bt = B.bruteForce(d.form, d.cards, P.scoreXI, { timeBudgetMs: BRUTE_MS });
  if (!bt.complete) { state.bruteTimeouts++; continue; }

  state.tested++;
  state.byRegime[d.regime] = (state.byRegime[d.regime] || 0) + 1;

  const solverBest = rs.error ? -1 : rs.best;
  const solver103 = rs103.error ? -1 : rs103.best;

  if (bt.best !== solverBest || bt.best !== solver103) {
    state.findings++;
    const finding = {
      seed, regime: d.regime, formName: d.formName, est,
      rcAuto: rcUsed, solverBestAtAutoRC: solverBest, solverBestAtRC103: solver103,
      bruteBest: bt.best,
      diagnosis: bt.best > solverBest
        ? (bt.best > solver103 ? 'UB-UNSOUND (missed even at RC 103)' : 'RC-RELATED (auto RC pruned it; RC 103 finds it)')
        : 'SOLVER-ABOVE-BRUTE (solver claims a squad brute never saw — invalid-squad bug or brute legality bug)',
      bruteXI: bt.bestXI ? bt.bestXI.map(c => c.id) : null,
      form: d.form, cards: d.cards
    };
    fs.appendFileSync(FINDINGS, JSON.stringify(finding) + '\n');
    console.log('!!! FINDING seed=' + seed + ' regime=' + d.regime + ' solver=' + solverBest + '/' + solver103 + ' brute=' + bt.best + ' -> ' + finding.diagnosis);
  }
}

fs.writeFileSync(STATE, JSON.stringify(state));
console.log(`[fuzz] cumulative: tested=${state.tested} findings=${state.findings} skippedBig=${state.skippedBig} infeasible=${state.skippedInfeasible} bruteTimeouts=${state.bruteTimeouts} nextSeed=${state.seed}`);
console.log('[fuzz] byRegime:', JSON.stringify(state.byRegime));
