'use strict';
const fs = require('fs');
const playerDB = JSON.parse(fs.readFileSync(__dirname+'/playerDB.json','utf8'));
const FORMS = JSON.parse(fs.readFileSync(__dirname+'/forms.json','utf8'));

function mulberry32(seed){
  return function(){
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// opts: { seed, minBust, maxBust, minPer, maxPer, formName? }
function generateDraft(opts){
  opts = opts||{};
  const rand = opts.rng || mulberry32(opts.seed!==undefined?opts.seed:(Math.random()*2**31|0));
  const rnd=(a,b)=>Math.floor(rand()*(b-a+1))+a;
  function shuffle(arr){const a=arr.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(rand()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
  function sampleN(arr,n){return shuffle(arr).slice(0,Math.min(n,arr.length));}

  const f = opts.formName ? FORMS.find(x=>x.name===opts.formName) : FORMS[rnd(0,FORMS.length-1)];
  const slots = f.slots.map((p,i)=>({id:'P'+i,pos:p}));
  const minBust = opts.minBust!==undefined?opts.minBust:0;
  const maxBust = opts.maxBust!==undefined?opts.maxBust:2;
  const numBusts = rnd(minBust, Math.min(maxBust, slots.length-2));
  const busted = new Set(shuffle(slots).slice(0,numBusts).map(s=>s.id));
  const nonBusted = slots.filter(s=>!busted.has(s.id));

  const minPer = opts.minPer!==undefined?opts.minPer:1;
  const maxPer = opts.maxPer!==undefined?opts.maxPer:3;

  let uid=1;
  const draftCards=[];
  nonBusted.forEach(slot=>{
    const pool = playerDB.filter(p=>p.pos.includes(slot.pos));
    if(!pool.length) return;
    const n = rnd(minPer, maxPer);
    for(const p of sampleN(pool.map((_,i)=>i), n)){
      const src = pool[p];
      draftCards.push({
        id: uid++, hold: null, genSlot: slot.id,
        name: src.name, type: src.type, rating: src.rating,
        nation: src.nation, league: src.league, club: src.club,
        pos: src.pos.slice()
      });
    }
  });

  const subForm = {name: f.name, slots: nonBusted.map(s=>s.pos)};
  return {formName: f.name, subForm, numBusts, activeSlots: nonBusted.length, cards: draftCards};
}

function estimateCombos(form, cards){
  const cand = form.slots.map(s=>cards.filter(c=>c.pos.includes(s)).length);
  if(cand.some(n=>n===0)) return 0;
  let prod=1;
  for(const n of cand){ prod*=n; if(prod>1e12) return prod; }
  return prod;
}

module.exports = { generateDraft, estimateCombos, mulberry32, playerDB, FORMS };
