// ===== Fuzz harness injected into the page =====
window.__fuzzResults = [];

function scaledRandomDraft(opts){
  opts = opts||{};
  const f = FORMS[Math.floor(Math.random()*FORMS.length)];
  const rnd=(a,b)=>Math.floor(Math.random()*(b-a+1))+a;
  function shuffle(arr){const a=arr.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}

  const slots = f.slots.map((p,i)=>({id:'P'+i,pos:p,busted:false}));
  // scaled-down bust range: bust MORE of the 11 slots so far fewer stay active
  const minBust = opts.minBust!==undefined?opts.minBust:3;
  const maxBust = opts.maxBust!==undefined?opts.maxBust:8;
  const numBusts = rnd(minBust, Math.min(maxBust, slots.length-2)); // keep at least 2 active
  const bustSet = new Set(shuffle(slots.slice()).slice(0,numBusts).map(s=>s.id));
  slots.forEach(s=>{s.busted=bustSet.has(s.id);});

  const nonBusted = slots.filter(s=>!s.busted);
  const minPer = opts.minPer!==undefined?opts.minPer:1;
  const maxPer = opts.maxPer!==undefined?opts.maxPer:2;

  function candidatesFor(pos){
    return playerDB.filter(p=>(p.pos||[]).includes(pos));
  }

  let uidLocal=1;
  const draftCards=[];
  nonBusted.forEach(slot=>{
    const pool=candidatesFor(slot.pos);
    if(!pool.length) return;
    const n=rnd(minPer,maxPer);
    const indices=shuffle(pool.map((_,i)=>i)).slice(0,Math.min(n,pool.length));
    indices.forEach(idx=>{
      const p=pool[idx];
      draftCards.push({
        id:uidLocal++,
        slot:slot.id,
        hold:null, // singles only for simplicity/scale-down (no hold-groups)
        label:p.name, type:p.type, rating:p.rating,
        nation:p.nation, league:p.league, club:p.club,
        pos:(p.pos||[]).slice()
      });
    });
  });

  return {form:f, slots, draftCards, numBusts, activeCount: nonBusted.length};
}

function estimateCombos(form, cards){
  // rough product of per-slot candidate counts (upper bound, ignores hold-group collisions)
  const cand = form.slots.map(s=>cards.filter(c=>c.pos.includes(s)).length);
  if(cand.some(n=>n===0)) return 0;
  let prod=1;
  for(const n of cand){ prod*=n; if(prod>1e9) return prod; }
  return prod;
}

async function runFuzzTrial(i, opts){
  let draft, est, tries=0;
  const maxEst = opts.maxEst || 300000;
  do{
    draft = scaledRandomDraft(opts);
    est = estimateCombos(draft.form, draft.draftCards);
    tries++;
  } while((est===0 || est>maxEst) && tries<40);

  if(est===0 || est>maxEst){
    return {trial:i, skipped:true, reason:'could_not_scale_down', est};
  }

  const trace=[];
  const cap = opts.cap || 3000000;
  const RC = opts.rc!==undefined?opts.rc:99;
  const t0=performance.now();
  const r = solveBestTraced(draft.form, draft.draftCards, cap, RC, undefined, undefined, trace);
  const ms = performance.now()-t0;

  return {
    trial:i,
    skipped:false,
    formation: draft.form.name,
    numBusts: draft.numBusts,
    activeSlots: draft.activeCount,
    estCombos: est,
    capped: r.capped,
    totalNodes: r.nodes,
    bestScore: r.best,
    maxRating: r.maxRating,
    rcUsed: RC,
    ms: ms,
    trace: trace, // [{nodes,score}, ...] every time best improved
    finalFoundAt: trace.length? trace[trace.length-1].nodes : null,
    numImprovements: trace.length
  };
}

window.__runFuzzBatch = async function(n, opts){
  const out=[];
  for(let i=0;i<n;i++){
    out.push(await runFuzzTrial(i, opts||{}));
  }
  window.__fuzzResults = out;
  return out;
};
