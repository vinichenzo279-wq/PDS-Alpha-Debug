# Solver fuzz test & presort experiment — findings

## 0. What changed since the last round

The original fuzz test ran inside the real browser (Playwright driving `pacwyn_fixed_v9_5_0.html`
directly) at a scaled-down difficulty so searches would finish inside a few million nodes. That
answered "how early do we find the best score" but couldn't reach the 100M+ node range or tell us
what a *capped* search's incumbent looked like at the moment it got cut off.

For this round I rebuilt the scoring/solver logic as a **pure Node.js module** (no browser, no
DOM) so trials run at full V8 speed instead of paying Playwright round-trip overhead. Before
trusting any of it, I cross-checked it bit-for-bit against the real app:

- `maxPossibleRating()` (the UB-A/B/D/E upper-bound function used for "auto" RC): **0 mismatches**
  across 15 real generated drafts, browser vs. Node port.
- `solveBest()` (the actual solver): **0 mismatches** on `best`, `nodes`, and `capped` across the
  same 15 drafts, including one that ran 2,159,462 nodes — exact match down to the node count.

Everything below is built on that verified engine (`engine.js`), plus three solver variants that
share 100% of the pruning/scoring/UB logic and differ *only* in candidate ordering
(`solvers.js`).

## 1. The three variants tested

| Variant | What it does | Per-node cost |
|---|---|---|
| **baseline** | Exactly what's shipped: each slot's candidates sorted by rating, descending, once, before search starts. | none (same as shipped) |
| **divstatic** | Same one-time sort, but candidates are re-ranked by `rating + small bonus for being the only card of its nation/club within that slot's own pool`. Cheap: computed once per slot, same as baseline. | **none** (still O(1) once per slot) |
| **dynamic** | Restores the v5.6 behavior v8.2 removed: re-sorts each slot's *remaining* candidates at **every node**, using the live path (which nations/leagues/clubs are already used). | a full comparator sort per node |

## 2. Does presort affect total search cost? (broad sweep, n=150)

150 drafts, generated from the real `playerDB`/`FORMS`, sized so most finish uncapped (max cap
2,000,000). Each ran all three variants back-to-back on the *identical* draft.

- **All three variants agreed on the final best score in 150/150 trials.** (Expected — the UB
  bound is sound regardless of ordering, so given enough nodes every variant proves the same
  optimum.)
- **Total nodes needed to prove optimality was identical across all three variants in 149/150
  trials.** Ordering only changes *when* a leaf is visited, not how many leaves the pruning
  ultimately lets through, and at this scale that plateau effect dominates.
- The one exception: a `4-2-4` draft where `dynamic` found the optimum at node 49 instead of node
  293, and total nodes did drop slightly (2,166 vs. 2,184 — a 0.8% reduction). Real, but tiny and
  rare (1/150).
- Wall-clock: `divstatic` was statistically indistinguishable from baseline (0.99x). `dynamic` was
  ~4–25% slower depending on draft size, purely from the extra per-node sort.

**Conclusion for this tier: presort is a non-factor.** If a search can run to completion, current
ordering already gets there in the same number of nodes as either alternative.

## 3. What happens on genuinely huge drafts, pushed to 80–150M nodes?

Five drafts sized so a real random demo would realistically produce them (est. legal combos
ranging ~1.7×10⁹ to ~9.7×10¹¹ — for scale, the "155 demo" case referenced earlier was 357,777).
Each ran all three variants at an 80,000,000-node cap; the largest was additionally pushed to
150,000,000 nodes.

| seed | formation | est. combos | RC | result @ cap |
|---|---|---|---|---|
| 90000 | — | 1.4×10¹⁰ | 94 | all 3 capped at 80M, all found best=149; `dynamic` converged at node 766,537 vs. 929,476 for the other two (17.5% earlier) |
| 90001 | — | 1.7×10⁹ | 95 | all 3 capped at 80M, all found best=146, converged within 3 nodes of each other |
| 90002 | — | 9.7×10¹¹ | 96 | all 3 capped at 80M, all found best=151 at essentially the same node (~2.31M) |
| 90003 | — | 4.0×10⁸ | 94 | all 3 capped at 80M, all found best=144 at node 6,502–6,503 |
| 90004 | — | 1.0×10⁸ | 95 | **completed uncapped at exactly 62,140,507 nodes for all three** — a genuine, fully-proved 62M-node optimum. `dynamic` found it at node 5,899 vs. 7,525 for the others, but total nodes to finish were identical to the last digit. |

Pushing seed 90002 further to 150,000,000 nodes is where it got interesting — see next section.

**Pattern that held across every one of these five:** whenever the incumbent score is found, it's
found almost immediately relative to the eventual node count — typically inside the first 1–3% of
however many nodes the search ends up using. The remaining 97%+ of the work is exhausting/pruning
the rest of the tree to *prove* nothing better exists, not searching for something better. This
matches the "155 demo" pattern the earlier example described: fast convergence, then a long tail
of proof.

## 4. The one genuinely new finding: presort *does* matter when the search is capped and the instance is hard

At 150,000,000 nodes, seed 90002 (est. 9.7×10¹¹ combos) split for the first time:

| variant | best @ 150M nodes | found at node |
|---|---|---|
| baseline | 151 | 2,313,118 |
| **divstatic** | **152** | 135,643,591 |
| dynamic | 151 | 2,312,400 |

`divstatic` found a squad worth **one point more** than the other two, but only 90% of the way
through the 150M-node budget — i.e., without that extra headroom, it would have reported 151 too.
This isn't a bug: the UB pruning bound is sound regardless of ordering, so a better squad is never
*permanently* lost, only found later or earlier depending on which branch order the search happens
to walk. A hard node cap just means we only ever see a prefix of that walk.

That single result raised the real question you asked: **is this a fluke, or does one ordering
systematically do better than another when the search gets capped?**

### The answer: no variant dominates, but baseline loses more often than it wins

I ran 50 more huge drafts (est. 1.1×10⁸ to 3.8×10¹¹ combos) at a fixed 10,000,000-node cap,
comparing all three variants head-to-head on each identical draft:

- **42/50 (84%) — all three variants found the exact same score at the cap.** No difference at
  all; this is the common case.
- **8/50 (16%) — the variants disagreed**, always by exactly 1 point (one case by 2 points).

Among those 8 disagreements:

| | wins (incl. ties) | sole wins | losses |
|---|---|---|---|
| baseline | 1 | 1 | **7** |
| divstatic | 5 | 2 | 3 |
| dynamic | 5 | 2 | 3 |

Baseline was on the *losing* side in 7 of the 8 cases where anything differed at all (a two-sided
binomial test against 50/50 puts that at p≈0.07, i.e. suggestive but not airtight on 8 events —
worth a larger confirmation run before treating it as settled). `divstatic` and `dynamic` performed
identically to each other in terms of which score they landed on, every single time they diverged
from baseline.

That last point matters for the practical recommendation: **`divstatic` gets the same
capped-search benefit as `dynamic`, at effectively zero wall-clock cost** (0.99x baseline, vs.
`dynamic`'s 1.25x), because all the "smartness" is spent once per slot instead of once per node.

The chart below shows the two clearest examples — one where baseline wins, one where it loses —
plotted as score-vs-nodes:

- Seed 91041: baseline climbs to 152 by ~7M nodes while `divstatic`/`dynamic` plateau at 150.
- Seed 91017: baseline plateaus at 147 almost immediately while `divstatic`/`dynamic` keep
  climbing to 148.

Both behaviors are on `presort_trace_comparison.png`. Neither ordering is "wrong" — the UB bound
is honored by all three — it's genuinely a coin flip which one's traversal order happens to reach
the better branch before an arbitrary cutoff.

## 5. Direct answers to your questions

**"Could a more refined presort lead to consistent improvements in how early improvements are
found, and how quickly we reach an optimum?"**
Not for searches that finish (149/150 broad trials + all completed extreme trials: total node
count and final answer were identical regardless of ordering). For those, current presort is
already effectively optimal — there's no room left to improve because the total *work* doesn't
change with ordering, only the visiting sequence.

**"Or is the current presort already ideal?"**
Not quite, in one specific, narrow situation: capped searches on very hard drafts (huge estimated
combo counts that no reasonable node cap will ever fully exhaust). There, baseline's ordering
happened to land on the worse side of a 1-point gap roughly 7x more often than it landed on the
better side, across 8 divergent cases out of 50 hard trials. That's a real, reproducible,
deterministic effect (not noise — every trial reruns the identical draft), but the sample (n=8
divergences) is small enough that I'd want a bigger confirmation batch before calling it settled.

**"What happens at 200M+ nodes?"**
I could only safely push to 150,000,000 nodes per run inside this environment's execution-time
limits (confirmed empirically: commands are killed somewhere between 250s and 350s of wall time,
and this solver runs at roughly 500k–800k nodes/sec depending on variant). At 150M nodes the
qualitative picture didn't change from what 80M already showed — incumbents plateau within the
first 1-3% of nodes, and the only new information the extra 70M nodes bought was the one
divergence case above. I'd extrapolate that going higher (200M, 500M) would mostly just push out
*when* the "still capped" ceiling for the biggest drafts (10¹¹–10¹² combos) gets hit, without
changing the shape of the result — but that's an extrapolation, not something I've verified.

## 6. Practical recommendation

- **Don't ship `dynamic`** (the restored v5.6 per-node resort): it costs 4–25% more wall time for
  no benefit over `divstatic` in every trial where it mattered, and no benefit at all over baseline
  in trials where ordering didn't matter. This re-confirms the v8.2 removal decision, now checked
  against much harder drafts (up to ~10¹² combos vs. the "two hardest drafts" originally spot-checked)
  and much higher node counts (up to 150M vs. 3M).
- **`divstatic` is a plausible free upgrade**, *if* the capped/hard-instance win-rate holds up on a
  larger confirmation batch — it's statistically indistinguishable from baseline in cost, and
  matched or beat baseline in every one of the 8 divergent hard-cap cases seen so far.
- If you want to chase this further, the next step I'd suggest is running the same
  `presort_capwars`-style harness for a few hundred more seeds at the 10M cap (cheap — each trio of
  variants takes ~45-60s) to get the divergence-case count up from 8 to something with real
  statistical weight before deciding whether to touch shipped code.

## Files delivered

- `engine.js` — verified pure-Node port of scoring + `maxPossibleRating` (UB-A/B/D/E).
- `solvers.js` — the three solver variants (`solveBaseline`, `solveDiversityStatic`, `solveDynamic`), sharing one `buildSolver()` core.
- `gendraft.js` — draft generator built on the real extracted `playerDB.json`/`forms.json`.
- `run_presort_experiment.js` — the experiment driver (`broad`, `extreme`, `single`, `batch` modes).
- `playerDB.json`, `forms.json` — extracted real app data used by the generator.
- `presort_broad.jsonl` — 150-trial broad sweep raw data.
- `presort_extreme.jsonl` / `presort_extreme_150m.jsonl` — the five 80M-node hard trials + the 150M push on seed 90002.
- `presort_capwars.jsonl` — the 50-trial, 10M-cap head-to-head win/loss dataset.
- `traces_for_chart.jsonl` — full traces for the two illustrative divergent cases.
- `capwars_winloss.png`, `presort_trace_comparison.png` — charts referenced above.
- Original browser-based general fuzz test artifacts (`fuzz_inject.js`, `solveBestTraced.js`, `ratio_hist.png`, `trace_examples.png`) from the earlier round, included for continuity.
