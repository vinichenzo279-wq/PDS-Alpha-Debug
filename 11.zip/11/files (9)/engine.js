'use strict';
// Exact port of the scoring + upper-bound functions from pacwyn_fixed_v9_5_0.html.
// No DOM/browser dependency -- lets us run at full V8 speed for 100M+ node trials.

function futRatingRaw(rs){const S=rs.reduce((a,b)=>a+b,0),A=S/rs.length;let sp=0;for(const r of rs)if(r>A)sp+=r-A;return (S+sp)/rs.length;}
function futRating(rs){return Math.floor(futRatingRaw(rs));}
function leagueOf(c){return c.type==='icon'?'Icons':c.type==='hero'?c.league:'England Premier League';}

function trueChem(xi){
  const natCnt={},clubCnt={},lgCnt={};let icons=0,normals=0;
  xi.forEach(c=>{
    if(c.type==='icon'){
      icons++;
      natCnt[c.nation]=(natCnt[c.nation]||0)+2;
    } else if(c.type==='hero'){
      natCnt[c.nation]=(natCnt[c.nation]||0)+1;
      const lg=leagueOf(c);
      lgCnt[lg]=(lgCnt[lg]||0)+2;
    } else {
      normals++;
      natCnt[c.nation]=(natCnt[c.nation]||0)+1;
      clubCnt[c.club]=(clubCnt[c.club]||0)+1;
    }
  });
  if(icons>0){
    lgCnt['England Premier League']=(lgCnt['England Premier League']||0)+icons;
    for(const lg of Object.keys(lgCnt)){
      if(lg!=='England Premier League')lgCnt[lg]+=icons;
    }
  }
  const premLeague=normals+(lgCnt['England Premier League']||0);
  const nP=n=>n>=8?3:n>=5?2:n>=2?1:0;
  const cP=n=>n>=7?3:n>=4?2:n>=2?1:0;
  const lP=n=>n>=8?3:n>=5?2:n>=3?1:0;
  let t=0;
  xi.forEach(c=>{
    if(c.type==='icon'||c.type==='hero'){t+=3;return;}
    const lg=leagueOf(c);
    const lgScore=lg==='England Premier League'?lP(premLeague):lP(lgCnt[lg]||0);
    t+=Math.min(3,nP(natCnt[c.nation]||0)+cP(clubCnt[c.club]||0)+lgScore);
  });
  return t;
}

function scoreXI(xi){
  const ratingExact=futRatingRaw(xi.map(c=>c.rating)),rating=Math.floor(ratingExact);
  const nations=new Set(xi.map(c=>c.nation)).size;
  const leagues=new Set(xi.map(leagueOf)).size;
  const premClubs=new Set(xi.filter(c=>c.type==='normal').map(c=>c.club)).size;
  const hasIcon=xi.some(c=>c.type==='icon'),hasHero=xi.some(c=>c.type==='hero');
  const clubs=premClubs+(hasIcon?1:0)+(hasHero?1:0);
  const glue=xi.filter(c=>c.type==='icon'||c.type==='normal').length;
  const premHeroCount=xi.filter(c=>c.type==='hero'&&c.league==='England Premier League').length;
  const premPool=glue+premHeroCount*2;
  const full=premPool>=8||xi.every(c=>c.type==='icon'||c.type==='hero');
  const chem=full?3*xi.length:trueChem(xi);
  return {rating,ratingExact,chem,nations,leagues,clubs,full,glue,total:rating+chem+nations+leagues+clubs};
}

// ---- maxPossibleRating (UB-A..E) ----
function ubDComponent(candList, positions, need){
  const groupOf = c => c.hold || ('C'+c.id);
  const groups={};
  for(const c of candList){
    const g=groupOf(c);
    if(!groups[g]) groups[g]={eligPos:new Set(), bestRating:-Infinity};
    for(const p of c.pos){
      if(positions.includes(p)){
        groups[g].eligPos.add(p);
        if(c.rating>groups[g].bestRating) groups[g].bestRating=c.rating;
      }
    }
  }
  const groupIds=Object.keys(groups).filter(g=>groups[g].eligPos.size>0)
    .sort((a,b)=>groups[b].bestRating-groups[a].bestRating);
  const posAssignments={}; for(const p of positions) posAssignments[p]=[];
  function tryAugment(gid, visitedPos){
    for(const p of groups[gid].eligPos){
      if(visitedPos.has(p)) continue;
      visitedPos.add(p);
      if(posAssignments[p].length<need[p]){ posAssignments[p].push(gid); return true; }
      for(let k=0;k<posAssignments[p].length;k++){
        const other=posAssignments[p][k];
        if(tryAugment(other, visitedPos)){ posAssignments[p][k]=gid; return true; }
      }
    }
    return false;
  }
  const K=positions.reduce((s,p)=>s+need[p],0);
  const chosen=[]; let matched=0;
  for(const gid of groupIds){
    if(tryAugment(gid, new Set())){ matched++; chosen.push(groups[gid].bestRating); if(matched===K) break; }
  }
  if(matched<K) return {feasible:false};
  return {feasible:true, chosen};
}
function ubEGlobal(elig, slots, need){
  const groupOf = c => c.hold || ('C'+c.id);
  const positions=Object.keys(need);
  const groups={};
  for(const c of elig){
    const g=groupOf(c);
    if(!groups[g]) groups[g]={eligPos:new Set(), bestRating:-Infinity};
    for(const p of c.pos){
      if(need[p]!==undefined){
        groups[g].eligPos.add(p);
        if(c.rating>groups[g].bestRating) groups[g].bestRating=c.rating;
      }
    }
  }
  const groupIds=Object.keys(groups).filter(g=>groups[g].eligPos.size>0)
    .sort((a,b)=>groups[b].bestRating-groups[a].bestRating);
  const posAssignments={}; for(const p of positions) posAssignments[p]=[];
  function tryAugment(gid, visitedPos){
    for(const p of groups[gid].eligPos){
      if(visitedPos.has(p)) continue;
      visitedPos.add(p);
      if(posAssignments[p].length<need[p]){ posAssignments[p].push(gid); return true; }
      for(let k=0;k<posAssignments[p].length;k++){
        const other=posAssignments[p][k];
        if(tryAugment(other, visitedPos)){ posAssignments[p][k]=gid; return true; }
      }
    }
    return false;
  }
  const N=slots.length;
  const chosen=[]; let matched=0;
  for(const gid of groupIds){
    if(tryAugment(gid, new Set())){ matched++; chosen.push(groups[gid].bestRating); if(matched===N) break; }
  }
  if(matched<N) return {feasible:false};
  return {feasible:true, chosen};
}
function maxPossibleRating(pool,form){
  if(!pool||!pool.length||!form)return null;
  const slots=form.slots,slotSet=new Set(slots),N=slots.length;
  const groupOf=c=>c.hold||('C'+c.id);
  const elig=pool.filter(c=>c.pos&&c.pos.some(p=>slotSet.has(p)));
  const ubs=[];
  {
    const byGroup={};
    for(const c of elig){const g=groupOf(c);if(byGroup[g]===undefined||c.rating>byGroup[g])byGroup[g]=c.rating;}
    const rs=Object.keys(byGroup).map(k=>byGroup[k]).sort((a,b)=>b-a);
    if(rs.length>=N)ubs.push(futRatingRaw(rs.slice(0,N)));
  }
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const chosen=[];let feasible=true;
    for(const pos in need){
      const k=need[pos];
      const cand=elig.filter(c=>c.pos.includes(pos)).sort((a,b)=>b.rating-a.rating);
      const seen=new Set(),top=[];
      for(const c of cand){const g=groupOf(c);if(seen.has(g))continue;seen.add(g);top.push(c.rating);if(top.length===k)break;}
      if(top.length<k){feasible=false;break;}
      for(const r of top)chosen.push(r);
    }
    if(feasible&&chosen.length===N)ubs.push(futRatingRaw(chosen));
  }
  // (UB-C omitted here: redundant with UB-D/UB-E's component-based bound, which is never looser)
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const posArr=Object.keys(need);
    const parent={};posArr.forEach(p=>parent[p]=p);
    const find=x=>{while(parent[x]!==x){parent[x]=parent[parent[x]];x=parent[x];}return x;};
    const union=(a,b)=>{const ra=find(a),rb=find(b);if(ra!==rb)parent[ra]=rb;};
    for(const c of elig){
      const rel=c.pos.filter(p=>need[p]!==undefined);
      for(let i=1;i<rel.length;i++)union(rel[0],rel[i]);
    }
    const comps={};
    for(const p of posArr){const r=find(p);(comps[r]=comps[r]||[]).push(p);}
    let feasible=true;const chosen=[];
    for(const r in comps){
      const compPos=new Set(comps[r]);
      const candList=elig.filter(c=>c.pos.some(p=>compPos.has(p)));
      const result=ubDComponent(candList, comps[r], need);
      if(!result.feasible){feasible=false;break;}
      for(const rr of result.chosen)chosen.push(rr);
    }
    if(feasible&&chosen.length===N)ubs.push(futRatingRaw(chosen));
  }
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const result=ubEGlobal(elig, slots, need);
    if(result.feasible && result.chosen.length===N)ubs.push(futRatingRaw(result.chosen));
  }
  if(!ubs.length)return null;
  return Math.floor(Math.min(...ubs));
}

module.exports = { futRatingRaw, futRating, leagueOf, trueChem, scoreXI, maxPossibleRating };
