'use strict';
const { leagueOf, scoreXI } = require('./engine.js');

// Shared setup: builds cand[]/order[]/UB precompute tables exactly as the shipped solver does.
// `presortFn(list)` decides the STATIC initial ordering of each slot's candidate list (called
// once per slot, before search starts). `dynamic` (optional) is a per-node re-sort hook run at
// the top of dfs() for the current slot's remaining candidate array, given the live path state --
// this is the expensive "v5.6" style option; leave undefined for O(1)-per-node static variants.
function buildSolver(opts){
  const presortFn = opts.presortFn; // (list, cards, form) => sorted list (once, per slot)
  const dynamicResort = opts.dynamicResort; // (list, state) => resorted list (per node, optional)

  return function solve(form, cards, nodeCap, ratingCeil, trace){
    const RC = ratingCeil!==undefined?ratingCeil:99;
    const slots = form.slots;
    let cand = slots.map(s=>cards.filter(c=>c.pos.includes(s)));
    cand = cand.map(list=>presortFn(list, cards, form));
    if(cand.some(l=>l.length===0))
      return {error:'A slot has no eligible card: '+slots.filter((s,i)=>cand[i].length===0).join(', ')};
    for(const slot of cand)for(const c of slot){
      if(c._lg===undefined)c._lg=leagueOf(c);
      if(c._group===undefined)c._group=c.hold||('C'+c.id);
    }
    const order=slots.map((s,i)=>i).sort((a,b)=>cand[a].length-cand[b].length);
    const slotTypes=cand.map(list=>{const s=new Set();for(const c of list)s.add(c.type);return s;});
    const N=slots.length;
    const ubBaseline=new Array(N),ubSuffixBase=new Array(N+1).fill(0);
    const ubTopIconV=new Array(N+1),ubTopIconI=new Array(N+1),ubTopIconV2=new Array(N+1),ubTopIconI2=new Array(N+1);
    const ubTopHeroV=new Array(N+1),ubTopHeroI=new Array(N+1),ubTopHeroV2=new Array(N+1),ubTopHeroI2=new Array(N+1);
    ubTopIconV[N]=-Infinity;ubTopIconI[N]=-1;ubTopIconV2[N]=-Infinity;ubTopIconI2[N]=-1;
    ubTopHeroV[N]=-Infinity;ubTopHeroI[N]=-1;ubTopHeroV2[N]=-Infinity;ubTopHeroI2[N]=-1;
    for(let k=N-1;k>=0;k--){
      const st=slotTypes[order[k]];
      let b=-Infinity;
      if(st.has('normal'))b=2;
      if(st.has('hero')&&b<2)b=2;
      if(st.has('icon')&&b<1)b=1;
      ubBaseline[k]=b;ubSuffixBase[k]=ubSuffixBase[k+1]+b;
      let iv=ubTopIconV[k+1],ii=ubTopIconI[k+1],iv2=ubTopIconV2[k+1],ii2=ubTopIconI2[k+1];
      if(st.has('icon')){const g=3-b;if(g>iv){iv2=iv;ii2=ii;iv=g;ii=k;}else if(g>iv2){iv2=g;ii2=k;}}
      ubTopIconV[k]=iv;ubTopIconI[k]=ii;ubTopIconV2[k]=iv2;ubTopIconI2[k]=ii2;
      let hv=ubTopHeroV[k+1],hi=ubTopHeroI[k+1],hv2=ubTopHeroV2[k+1],hi2=ubTopHeroI2[k+1];
      if(st.has('hero')){const g=3-b;if(g>hv){hv2=hv;hi2=hi;hv=g;hi=k;}else if(g>hv2){hv2=g;hi2=k;}}
      ubTopHeroV[k]=hv;ubTopHeroI[k]=hi;ubTopHeroV2[k]=hv2;ubTopHeroI2[k]=hi2;
    }
    let best=-1, bestXIs=[];
    let maxRating=-1;
    let nodes=0; const CAP=nodeCap||3000000; let capped=false;
    const usedGroups=new Set(), pick=new Array(slots.length).fill(null);
    const seenNat=new Set(), seenLg=new Set(), seenClub=new Set();
    let partialIcon=0, partialHero=0;

    function dfs(k){
      if(nodes++>CAP){capped=true;return;}
      if(capped)return;
      if(k===order.length){
        const xi=pick.slice(), sc=scoreXI(xi);
        if(sc.rating>maxRating)maxRating=sc.rating;
        if(sc.total>best){
          best=sc.total;
          const key=xi.map(c=>c.id).sort().join(',');
          bestXIs=[{xi,sc,foundAt:nodes,key}];
          if(trace)trace.push({nodes:nodes,score:sc.total});
        } else if(sc.total===best){
          const key=xi.map(c=>c.id).sort().join(',');
          if(!bestXIs.some(b=>(b.key||(b.key=b.xi.map(c=>c.id).sort().join(',')))===key))bestXIs.push({xi,sc,foundAt:nodes,key});
        }
        return;
      }
      const slotIdx=order[k];
      if(best>=0){
        const premUnseen=seenLg.has('England Premier League')?0:1;
        const total0=ubSuffixBase[k];
        let bonusGain;
        if(partialIcon&&partialHero){
          bonusGain=0;
        }else{
          const ic0v=partialIcon?0:(ubTopIconV[k]>0?ubTopIconV[k]:0),ic0i=partialIcon?-1:ubTopIconI[k];
          const he0v=partialHero?0:(ubTopHeroV[k]>0?ubTopHeroV[k]:0),he0i=partialHero?-1:ubTopHeroI[k];
          let orderA=ic0v;
          if(!partialHero){
            if(he0i!==ic0i)orderA+=he0v;
            else orderA+=(ubTopHeroV2[k]>0?ubTopHeroV2[k]:0);
          }
          let orderB=he0v;
          if(!partialIcon){
            if(ic0i!==he0i)orderB+=ic0v;
            else orderB+=(ubTopIconV2[k]>0?ubTopIconV2[k]:0);
          }
          bonusGain=Math.max(orderA,orderB);
        }
        const ub=RC+33+seenNat.size+seenLg.size+seenClub.size+partialIcon+partialHero+total0+bonusGain+premUnseen;
        if(ub<best)return;
      }
      let list = cand[slotIdx];
      if(dynamicResort){
        list = dynamicResort(list, {seenNat,seenLg,seenClub,partialIcon,partialHero});
      }
      for(const c of list){
        const g=c._group;
        if(usedGroups.has(g))continue;
        usedGroups.add(g);pick[slotIdx]=c;
        const addNat=seenNat.has(c.nation)?0:(seenNat.add(c.nation),1);
        const addLg =seenLg.has(c._lg)   ?0:(seenLg.add(c._lg),1);
        const addClub=c.type==='normal'&&!seenClub.has(c.club)?(seenClub.add(c.club),1):0;
        const addIcon=!partialIcon&&c.type==='icon'?1:0;if(addIcon)partialIcon=1;
        const addHero=!partialHero&&c.type==='hero'?1:0;if(addHero)partialHero=1;
        dfs(k+1);
        if(addNat) seenNat.delete(c.nation);
        if(addLg)  seenLg.delete(c._lg);
        if(addClub)seenClub.delete(c.club);
        if(addIcon)partialIcon=0;
        if(addHero)partialHero=0;
        usedGroups.delete(g);pick[slotIdx]=null;
        if(capped)return;
      }
    }
    dfs(0);
    return {best,bestXIs,nodes,capped,slots,maxRating,rcUsed:RC};
  };
}

// ---------------------------------------------------------------------------
// Variant 1: BASELINE -- exactly what's shipped. Static, rating-desc, once per slot.
// ---------------------------------------------------------------------------
const solveBaseline = buildSolver({
  presortFn: (list)=>list.slice().sort((a,b)=>b.rating-a.rating)
});

// ---------------------------------------------------------------------------
// Variant 2: STATIC DIVERSITY-WEIGHTED -- still O(1) per node (sorted once, like baseline),
// but the initial order is rating adjusted by a cheap, path-independent "rarity" signal: within
// THIS slot's own candidate pool, how rare is this card's nation/club/league combo? Cards that
// are the only representative of their nation/club in the slot's pool are nudged up, on the
// theory that grabbing a "free" diversity point early makes later slots more likely to hit
// diminishing (already-capped-at-3) diversity returns sooner, converging faster. Purely a
// re-ranking of the SAME candidate list computed once before dfs() starts -- no extra
// per-node cost versus baseline.
// ---------------------------------------------------------------------------
function rarityWeight(list){
  const natCount={}, clubCount={};
  for(const c of list){
    natCount[c.nation]=(natCount[c.nation]||0)+1;
    if(c.type==='normal') clubCount[c.club]=(clubCount[c.club]||0)+1;
  }
  return list.map(c=>{
    const natRarity = 1/(natCount[c.nation]||1);
    const clubRarity = c.type==='normal' ? 1/(clubCount[c.club]||1) : 0;
    // small, bounded nudge (<1 rating point worth) so ties/near-ties get reordered by rarity
    // but a genuinely higher-rated card is never displaced by a lower-rated rare one.
    const score = c.rating + 0.4*natRarity + 0.4*clubRarity;
    return {c, score};
  }).sort((a,b)=>b.score-a.score).map(x=>x.c);
}
const solveDiversityStatic = buildSolver({ presortFn: rarityWeight });

// ---------------------------------------------------------------------------
// Variant 3: DYNAMIC IN-FLIGHT RESORT -- restores the v5.6 behavior that v8.2 removed: at
// EVERY node, resort the current slot's remaining candidates by rating + marginal diversity
// value GIVEN the live path (seenNat/seenLg/seenClub/partialIcon/partialHero), not just the
// slot's own static pool. Expensive (a comparator sort per node), included to get a real,
// larger-scale answer on whether that cost is ever worth it -- v8.2's removal was measured on
// only two hand-picked "hardest" drafts capped at 3M nodes.
// ---------------------------------------------------------------------------
function dynamicMarginalResort(list, state){
  const {seenNat, seenLg, seenClub} = state;
  return list.slice().sort((a,b)=>{
    const av = a.rating + (seenNat.has(a.nation)?0:1) + (seenLg.has(a._lg)?0:1) + (a.type==='normal'&&!seenClub.has(a.club)?1:0);
    const bv = b.rating + (seenNat.has(b.nation)?0:1) + (seenLg.has(b._lg)?0:1) + (b.type==='normal'&&!seenClub.has(b.club)?1:0);
    return bv-av;
  });
}
const solveDynamic = buildSolver({
  presortFn: (list)=>list.slice().sort((a,b)=>b.rating-a.rating), // same starting order as baseline
  dynamicResort: dynamicMarginalResort
});

module.exports = { buildSolver, solveBaseline, solveDiversityStatic, solveDynamic };
