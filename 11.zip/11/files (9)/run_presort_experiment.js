'use strict';
// Presort A/B/C experiment: baseline (shipped) vs static-diversity vs dynamic-in-flight resort,
// run head-to-head on IDENTICAL generated drafts so any difference is attributable purely to
// candidate ordering, not to draft variance.
const fs = require('fs');
const { generateDraft, estimateCombos } = require('./gendraft.js');
const { maxPossibleRating } = require('./engine.js');
const { solveBaseline, solveDiversityStatic, solveDynamic } = require('./solvers.js');

const VARIANTS = [
  ['baseline', solveBaseline],
  ['divstatic', solveDiversityStatic],
  ['dynamic', solveDynamic],
];

function checkpointBest(trace, nodeCheckpoints){
  // for each checkpoint, the best score achieved by that many nodes (0 if none yet)
  const out = {};
  let idx = 0;
  let cur = null;
  const sorted = trace; // trace is already nodes-ascending
  for(const cp of nodeCheckpoints){
    while(idx < sorted.length && sorted[idx].nodes <= cp){ cur = sorted[idx].score; idx++; }
    out[cp] = cur;
  }
  return out;
}

function runTrial(draftOpts, cap, checkpoints){
  const d = generateDraft(draftOpts);
  const est = estimateCombos(d.subForm, d.cards);
  if(est===0) return {skipped:true, reason:'infeasible_estimate'};
  let rc;
  try { rc = maxPossibleRating(d.cards, d.subForm); } catch(e){ rc = 96; }
  if(rc===null) rc = 96;

  const result = {
    seed: draftOpts.seed, formName: d.formName, activeSlots: d.activeSlots,
    numCards: d.cards.length, estCombos: est, rc, cap,
    variants: {}
  };
  for(const [name, fn] of VARIANTS){
    const trace = [];
    const t0 = Date.now();
    const r = fn(d.subForm, d.cards, cap, rc, trace);
    const ms = Date.now()-t0;
    result.variants[name] = {
      best: r.best, totalNodes: r.nodes, capped: r.capped, ms,
      finalFoundAt: trace.length? trace[trace.length-1].nodes : null,
      firstFoundAt: trace.length? trace[0].nodes : null,
      numImprovements: trace.length,
      trace,
      checkpoints: checkpoints? checkpointBest(trace, checkpoints) : undefined
    };
  }
  return result;
}

function main(){
  const mode = process.argv[2] || 'broad';
  const outPath = process.argv[3] || `/home/claude/presort_${mode}.jsonl`;
  if(mode !== 'single' && mode !== 'batch') fs.writeFileSync(outPath, ''); // truncate only for one-shot bulk modes

  if(mode === 'broad'){
    const N = parseInt(process.argv[4]||'150',10);
    const presets = [
      {minBust:1, maxBust:4, minPer:1, maxPer:2, maxEst:150000},
      {minBust:0, maxBust:2, minPer:1, maxPer:2, maxEst:150000},
      {minBust:2, maxBust:5, minPer:1, maxPer:3, maxEst:250000},
      {minBust:0, maxBust:1, minPer:1, maxPer:2, maxEst:100000},
      {minBust:1, maxBust:3, minPer:1, maxPer:3, maxEst:250000},
    ];
    const cap = 2000000;
    let i=0, attempts=0;
    while(i<N && attempts < N*30){
      attempts++;
      const preset = presets[i % presets.length];
      const draftOpts = Object.assign({seed: 10000+attempts}, preset);
      const d = generateDraft(draftOpts);
      const est = estimateCombos(d.subForm, d.cards);
      if(est===0 || est>preset.maxEst) continue; // reroll: too big/infeasible for broad tier
      const t0=Date.now();
      const res = runTrial(draftOpts, cap, null);
      fs.appendFileSync(outPath, JSON.stringify(res)+'\n');
      i++;
      if(i%10===0) console.log(`[broad] ${i}/${N} (${Date.now()-t0}ms last trial, ${attempts} attempts so far)`);
    }
    console.log('broad sweep done ->', outPath, `(${attempts} attempts for ${i} trials)`);
  }

  if(mode === 'single'){
    // node run_presort_experiment.js single <outPath> <seed> <variantName> <cap> <minBust> <maxBust> <minPer> <maxPer>
    const seed = parseInt(process.argv[4],10);
    const variantName = process.argv[5];
    const cap = parseInt(process.argv[6],10);
    const minBust = parseInt(process.argv[7],10), maxBust=parseInt(process.argv[8],10);
    const minPer = parseInt(process.argv[9],10), maxPer=parseInt(process.argv[10],10);
    const draftOpts = {seed, minBust, maxBust, minPer, maxPer};
    const d = generateDraft(draftOpts);
    const est = estimateCombos(d.subForm, d.cards);
    let rc; try{ rc = maxPossibleRating(d.cards, d.subForm); }catch(e){ rc=96; }
    if(rc===null) rc=96;
    const fn = VARIANTS.find(v=>v[0]===variantName)[1];
    const checkpoints = [1e5,5e5,1e6,5e6,1e7,2e7,5e7,8e7,1e8,1.5e8,2e8].filter(c=>c<=cap);
    const trace = [];
    const t0 = Date.now();
    const r = fn(d.subForm, d.cards, cap, rc, trace);
    const ms = Date.now()-t0;
    const out = {
      seed, formName: d.formName, activeSlots: d.activeSlots, numCards: d.cards.length,
      estCombos: est, rc, cap, variant: variantName,
      best: r.best, totalNodes: r.nodes, capped: r.capped, ms,
      finalFoundAt: trace.length? trace[trace.length-1].nodes : null,
      firstFoundAt: trace.length? trace[0].nodes : null,
      numImprovements: trace.length,
      trace,
      checkpoints: checkpointBest(trace, checkpoints)
    };
    fs.appendFileSync(outPath, JSON.stringify(out)+'\n');
    console.log(`seed=${seed} variant=${variantName} est=${est} rc=${rc} nodes=${r.nodes} capped=${r.capped} best=${r.best} ms=${ms} finalFoundAt=${out.finalFoundAt}`);
  }

  if(mode === 'batch'){
    // node run_presort_experiment.js batch <outPath> <cap> <minBust> <maxBust> <minPer> <maxPer> <seed1> <seed2> ...
    const cap = parseInt(process.argv[4],10);
    const minBust = parseInt(process.argv[5],10), maxBust=parseInt(process.argv[6],10);
    const minPer = parseInt(process.argv[7],10), maxPer=parseInt(process.argv[8],10);
    const seeds = process.argv.slice(9).map(Number);
    for(const seed of seeds){
      const draftOpts = {seed, minBust, maxBust, minPer, maxPer};
      const d = generateDraft(draftOpts);
      const est = estimateCombos(d.subForm, d.cards);
      let rc; try{ rc = maxPossibleRating(d.cards, d.subForm); }catch(e){ rc=96; }
      if(rc===null) rc=96;
      const row = {seed, formName: d.formName, activeSlots: d.activeSlots, numCards: d.cards.length, estCombos: est, rc, cap, variants:{}};
      for(const [name, fn] of VARIANTS){
        const trace=[];
        const t0=Date.now();
        const r = fn(d.subForm, d.cards, cap, rc, trace);
        const ms=Date.now()-t0;
        row.variants[name] = {best:r.best, totalNodes:r.nodes, capped:r.capped, ms,
          finalFoundAt: trace.length?trace[trace.length-1].nodes:null, numImprovements:trace.length};
      }
      fs.appendFileSync(outPath, JSON.stringify(row)+'\n');
      const bests = Object.entries(row.variants).map(([n,v])=>`${n}=${v.best}(${v.capped?'C':'U'})`).join(' ');
      console.log(`seed=${seed} est=${est} rc=${rc} ${bests}`);
    }
  }
}

main();
