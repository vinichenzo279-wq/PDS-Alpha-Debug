'use strict';
// EXPERIMENTAL / PROTOTYPE -- NOT production logic. Identical to solver.js except the per-node
// upper bound gets one extra tightening pass: "resource scarcity" caps on how many *new*
// nations / clubs / leagues the remaining slots can actually still discover, in the same
// simplistic aggregate-count spirit as maxPossibleRating's UB-A/UB-B (no per-node bipartite
// matching -- that would be the ubDComponent/ubEGlobal style and is much more expensive).
//
// WHY THIS SHOULD BE SOUND (upper bound never becomes too tight / never prunes the true optimum):
// solveBest's existing baseline (ubSuffixBase) already assumes every remaining slot can bank a
// brand-new nation, and (for normal-only / hero-only-nonprem slots) a brand-new club / league.
// That's an overestimate whenever the remaining candidate pools don't actually contain enough
// DISTINCT not-yet-seen nation/club/league values to give each remaining slot a fresh one --
// for any such resource, the true max additional count achievable is bounded by
//     min(remaining eligible slots, distinct not-yet-seen values reachable from those slots)
// This is a standard cardinality bound (an upper bound on any matching between slots and values,
// since a matching's size can never exceed either side's size) -- so it never underestimates the
// true achievable count, and subtracting the resulting "excess" (eligible slots minus that cap)
// from the flat per-slot credit can never remove more than was already double counted.
//
// CONSERVATISM: to avoid ambiguity about which slots' baseline credit is "really" for club vs
// league (a slot offering BOTH normal and hero candidates gets baseline b=2 either way, and we
// can't tell in advance whether the eventual pick banks the club point or the league point), the
// club-scarcity correction only applies to slots whose candidate pool is 100% normal, and the
// league-scarcity correction only applies to slots whose pool is 100% hero AND not all-Prem
// (i.e. heroBase===2 is unambiguous). Nation scarcity applies to every remaining slot since every
// type's baseline credits exactly one nation point.
//
// This file exists purely to be fuzz-tested against bruteforce.js (Test 1) for soundness, and
// benchmarked against solver.js (Test 3) for node-count reduction vs added per-node cost. It has
// NOT been reviewed/merged into index.html.
const { leagueOf, scoreXI } = require('./engine.js');

function solve(form, cards, ratingCeil, nodeCap){
  const RC = ratingCeil !== undefined ? ratingCeil : 99;
  const slots = form.slots;
  const cand = slots.map(s=>{
    const list = cards.filter(c=>c.pos.includes(s));
    const natCount={}, clubCount={};
    for(const c of list){
      natCount[c.nation]=(natCount[c.nation]||0)+1;
      if(c.type==='normal') clubCount[c.club]=(clubCount[c.club]||0)+1;
    }
    return list.map(c=>({c,k:c.rating+0.4/(natCount[c.nation]||1)+(c.type==='normal'?0.4/(clubCount[c.club]||1):0)}))
      .sort((a,b)=>b.k-a.k).map(x=>x.c);
  });
  if(cand.some(l=>l.length===0))
    return {error:'A slot has no eligible card: '+slots.filter((s,i)=>cand[i].length===0).join(', ')};

  for(const slot of cand) for(const c of slot){
    if(c._lg===undefined) c._lg = leagueOf(c);
    if(c._group===undefined) c._group = c.hold || ('C'+c.id);
  }
  const order = slots.map((s,i)=>i).sort((a,b)=>cand[a].length-cand[b].length);
  const slotTypes = cand.map(list=>{const s=new Set(); for(const c of list) s.add(c.type); return s;});
  const slotHeroAllPrem = cand.map(list=>{
    const heroes = list.filter(c=>c.type==='hero');
    return heroes.length>0 && heroes.every(c=>c.league==='England Premier League');
  });

  const N = slots.length;
  const ubBaseline=new Array(N), ubSuffixBase=new Array(N+1).fill(0);
  const ubTopIconV=new Array(N+1),ubTopIconI=new Array(N+1),ubTopIconV2=new Array(N+1),ubTopIconI2=new Array(N+1);
  const ubTopHeroV=new Array(N+1),ubTopHeroI=new Array(N+1),ubTopHeroV2=new Array(N+1),ubTopHeroI2=new Array(N+1);
  ubTopIconV[N]=-Infinity;ubTopIconI[N]=-1;ubTopIconV2[N]=-Infinity;ubTopIconI2[N]=-1;
  ubTopHeroV[N]=-Infinity;ubTopHeroI[N]=-1;ubTopHeroV2[N]=-Infinity;ubTopHeroI2[N]=-1;

  // -- new: per-remaining-slot eligibility for club/league scarcity, and suffix distinct-value
  // sets (built alongside the existing suffix aggregates, k = N-1 down to 0).
  const clubEligible = new Array(N); // slot (in order[] position) is 100% normal
  const lgEligible = new Array(N);   // slot is 100% hero and not all-Prem
  const suffixNatSet = new Array(N+1);
  const suffixClubSet = new Array(N+1);
  const suffixLgSet = new Array(N+1);
  suffixNatSet[N] = new Set(); suffixClubSet[N] = new Set(); suffixLgSet[N] = new Set();
  const clubEligCount = new Array(N+1).fill(0);
  const lgEligCount = new Array(N+1).fill(0);

  for(let k=N-1;k>=0;k--){
    const idx=order[k];
    const st=slotTypes[idx];
    const heroBase = slotHeroAllPrem[idx] ? 1 : 2;
    let b=-Infinity;
    if(st.has('normal')) b=2;
    if(st.has('hero') && b<heroBase) b=heroBase;
    if(st.has('icon') && b<1) b=1;
    ubBaseline[k]=b; ubSuffixBase[k]=ubSuffixBase[k+1]+b;
    let iv=ubTopIconV[k+1],ii=ubTopIconI[k+1],iv2=ubTopIconV2[k+1],ii2=ubTopIconI2[k+1];
    if(st.has('icon')){ const g=3-b; if(g>iv){iv2=iv;ii2=ii;iv=g;ii=k;} else if(g>iv2){iv2=g;ii2=k;} }
    ubTopIconV[k]=iv;ubTopIconI[k]=ii;ubTopIconV2[k]=iv2;ubTopIconI2[k]=ii2;
    let hv=ubTopHeroV[k+1],hi=ubTopHeroI[k+1],hv2=ubTopHeroV2[k+1],hi2=ubTopHeroI2[k+1];
    if(st.has('hero')){ const g=1; if(g>hv){hv2=hv;hi2=hi;hv=g;hi=k;} else if(g>hv2){hv2=g;hi2=k;} }
    ubTopHeroV[k]=hv;ubTopHeroI[k]=hi;ubTopHeroV2[k]=hv2;ubTopHeroI2[k]=hi2;

    const isClubEligible = st.size===1 && st.has('normal');
    const isLgEligible = st.size===1 && st.has('hero') && !slotHeroAllPrem[idx];
    clubEligible[k]=isClubEligible; lgEligible[k]=isLgEligible;

    const nats = new Set(suffixNatSet[k+1]);
    const clbs = new Set(suffixClubSet[k+1]);
    const lgs = new Set(suffixLgSet[k+1]);
    for(const c of cand[idx]) nats.add(c.nation);
    if(isClubEligible) for(const c of cand[idx]) clbs.add(c.club);
    if(isLgEligible) for(const c of cand[idx]) if(c._lg !== 'England Premier League') lgs.add(c._lg);
    suffixNatSet[k]=nats; suffixClubSet[k]=clbs; suffixLgSet[k]=lgs;
    clubEligCount[k] = clubEligCount[k+1] + (isClubEligible?1:0);
    lgEligCount[k] = lgEligCount[k+1] + (isLgEligible?1:0);
  }

  function countNotIn(setA, setB){
    let n=0; for(const v of setA) if(!setB.has(v)) n++; return n;
  }

  let best=-1, bestXIs=[], maxRating=-1, nodes=0;
  const CAP = (nodeCap===undefined || nodeCap===null) ? Infinity : nodeCap;
  let capped=false;
  const usedGroups=new Set(), pick=new Array(N).fill(null);
  const seenNat=new Set(), seenLg=new Set(), seenClub=new Set();
  let partialIcon=0, partialHero=0;

  // instrumentation: count of scarcity-tightening evaluations, for per-node cost measurement
  let ubCalls = 0;

  function computeUB(k){
    ubCalls++;
    const premUnseen = seenLg.has('England Premier League') ? 0 : 1;
    const total0 = ubSuffixBase[k];
    let bonusGain;
    if(partialIcon && partialHero){ bonusGain=0; }
    else{
      const ic0v = partialIcon?0:(ubTopIconV[k]>0?ubTopIconV[k]:0), ic0i = partialIcon?-1:ubTopIconI[k];
      const he0v = partialHero?0:(ubTopHeroV[k]>0?ubTopHeroV[k]:0), he0i = partialHero?-1:ubTopHeroI[k];
      let orderA = ic0v;
      if(!partialHero){ if(he0i!==ic0i) orderA+=he0v; else orderA+=(ubTopHeroV2[k]>0?ubTopHeroV2[k]:0); }
      let orderB = he0v;
      if(!partialIcon){ if(ic0i!==he0i) orderB+=ic0v; else orderB+=(ubTopIconV2[k]>0?ubTopIconV2[k]:0); }
      bonusGain = Math.max(orderA, orderB);
    }
    const base = RC+33+seenNat.size+seenLg.size+seenClub.size+partialIcon+partialHero+total0+bonusGain+premUnseen;

    const remainingSlots = N-k;
    const natAvail = countNotIn(suffixNatSet[k], seenNat);
    const natExcess = Math.max(0, remainingSlots - Math.min(remainingSlots, natAvail));

    const clubAvail = countNotIn(suffixClubSet[k], seenClub);
    const clubExcess = Math.max(0, clubEligCount[k] - Math.min(clubEligCount[k], clubAvail));

    const lgAvail = countNotIn(suffixLgSet[k], seenLg);
    const lgExcess = Math.max(0, lgEligCount[k] - Math.min(lgEligCount[k], lgAvail));

    return base - natExcess - clubExcess - lgExcess;
  }

  function dfs(k){
    if(nodes++ > CAP){ capped=true; return; }
    if(capped) return;
    if(k===N){
      const xi=pick.slice(), sc=scoreXI(xi);
      if(sc.rating>maxRating) maxRating=sc.rating;
      if(sc.total>best){ best=sc.total; bestXIs=[{xi,sc}]; }
      return;
    }
    const slotIdx=order[k];
    if(best>=0){
      const ub=computeUB(k);
      if(ub<best) return;
    }
    for(const c of cand[slotIdx]){
      const g=c._group;
      if(usedGroups.has(g)) continue;
      usedGroups.add(g); pick[slotIdx]=c;
      const addNat=seenNat.has(c.nation)?0:(seenNat.add(c.nation),1);
      const addLg=seenLg.has(c._lg)?0:(seenLg.add(c._lg),1);
      const addClub=c.type==='normal'&&!seenClub.has(c.club)?(seenClub.add(c.club),1):0;
      const addIcon=!partialIcon&&c.type==='icon'?1:0; if(addIcon)partialIcon=1;
      const addHero=!partialHero&&c.type==='hero'?1:0; if(addHero)partialHero=1;
      dfs(k+1);
      if(addNat) seenNat.delete(c.nation);
      if(addLg) seenLg.delete(c._lg);
      if(addClub) seenClub.delete(c.club);
      if(addIcon) partialIcon=0;
      if(addHero) partialHero=0;
      usedGroups.delete(g); pick[slotIdx]=null;
      if(capped) return;
    }
  }
  dfs(0);
  return { best, bestXIs, nodes, capped, done: !capped, maxRating, ubCalls };
}

module.exports = { solve };
