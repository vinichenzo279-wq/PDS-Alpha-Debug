# Draft-solver fuzz harness

Three self-contained node scripts, no dependency on `playerDB.json`/`forms.json` (not available
here) — pool generation is synthetic (`fuzz_gendraft.js`) but exercises the same structural
features as real drafts: duplicate slot labels, flexible multi-position cards, and shared
`hold` groups (loan/link pairs) that must not be double-picked.

## Files

| File | Purpose |
|---|---|
| `engine.js` | **Unmodified**, your real `scoreXI`/`maxPossibleRating`/`leagueOf`. |
| `solver.js` | Faithful port of `index.html`'s current **v12.4.0** `solveBest` (production UB/pruning). |
| `solver_experimental.js` | Same, plus a prototype nation/club/league **scarcity-tightened UB** (v0, unmerged). |
| `bruteforce.js` | No pruning at all — ground truth for optimality checks. |
| `fuzz_gendraft.js` | Synthetic draft generator, tunable pool size / nation / club / league diversity. |
| `test1_optimality.js` | **Test 1**: fuzzes for missed-optimal bugs. |
| `test3_ub_experiment.js` | **Test 3**: node-count / per-node-cost comparison for the new UB. |
| `repro_finding.js` | Replays one exact failing draft from `findings.jsonl`. |

*(Test 2, "RC=103 to eliminate pruning", is folded into Test 1 as one of its four comparison runs
— see below.)*

## ⚠️ Found before any fuzzing even started: `resumable_solve.js` is stale

`resumable_solve.js` (and therefore `diversity_harness.js`, `run_hybrid.js`,
`run_diversity_sweep.js`, `find_hard_seeds.js` — everything that requires it) implements the
**pre-v12.4.0** upper bound: it always uses `heroBase = 2` and hardcodes the hero bonus gain as
`3-b`. `index.html`'s current `solveBest` fixed a real double-count for slots whose only hero
candidates are all Prem-league (`heroBase` becomes `1` there, and the hero bonus gain is a flat
`1`, not `3-b`) — see the `v12.4.0` comment block at index.html:2677-2718.

Net effect: on any draft where a slot's *only* hero options are all Premier League, the resumable
solver's bound is looser than production's, by a small constant. Looser is *safe* (won't cause a
missed optimum) but it means every "hard seed" / node-count number produced by those four scripts
so far is not actually measuring today's production pruning — it's measuring the old bound. If you
want apples-to-apples numbers against `index.html` as it stands today, `resumable_solve.js` needs
the same fix `solver.js` in this bundle already has (copy `slotHeroAllPrem`/`heroBase` block over).
I did **not** patch your existing file — didn't want to change production-adjacent code without
you looking at it first.

## Test 1 — do we ever miss the optimal score?

For each seed: generate a small draft (small enough that brute force finishes), then run and
compare against brute force:

- baseline solver @ **real RC** (`maxPossibleRating`) — exactly what production runs today
- baseline solver @ **RC = 103** — RC pushed artificially high, so the RC term itself can never be
  the reason for a miss; isolates the rest of the UB math from the RC calculation
- experimental solver @ real RC, and @ RC=103 — same two isolations, for the new UB idea

If any of the four don't match brute force, the exact draft (seed, form, every card, the true
optimum, and which run(s) missed) gets written to `findings.jsonl`, plus an automatic diagnosis:
if a miss disappears at RC=103, it's localized to `maxPossibleRating`/the RC term; if it persists,
the bug is in the nation/league/club/icon/hero accounting itself; if only the experimental run
misses, it's isolated to the new scarcity code, not the baseline.

```
node test1_optimality.js [numSeeds=2000] [startSeed=1] [minPer=2] [maxPer=3]
node repro_finding.js findings.jsonl [lineNumber]   # replay one exact failure
```

**Run so far: 3000 drafts, 1313 skipped (pool too big for brute force), 1687 actually compared.
Zero misses** across baseline@realRC, baseline@RC103, experimental@realRC, experimental@RC103.
`findings.jsonl` is empty. This is evidence of soundness, not a proof — bump `numSeeds` and/or
`maxPer` (bigger pools per slot = deeper trees = more pruning opportunities) for more confidence;
just keep `estimateCombos` under ~60k or brute force gets slow.

## Test 3 — does the new scarcity UB actually help, and what does it cost?

Your ask: "optimizing the nations/lgs/normals not yet seen by using a formula to count how many
nat/lg/club could possibly still exist" — implemented in `solver_experimental.js` as a resource-
scarcity cap in the same aggregate-counting spirit as `maxPossibleRating`'s UB-A/UB-B (not a full
bipartite matching like UB-D/UB-E — that'd be much more expensive per node, which is exactly the
tradeoff this test is meant to surface). Full soundness argument is in the comment block at the
top of that file, and it's the thing Test 1 verifies empirically (0 misses, see above, including
under artificially extreme scarcity).

**Result: it doesn't help.** Across both a realistic-diversity sweep and a maximally-scarce sweep
(1 nation / 1 club / 1 league total, so the tightening should fire as hard as it possibly can):

```
node test3_ub_experiment.js [numDrafts=40] [startSeed=1] [minPer=4] [maxPer=6] [nationCount=3] [clubCount=3] [leagueCount=2]
```

| Config | Drafts | Avg node reduction | Avg time delta | Per-node overhead | Excess ever fires? |
|---|---|---|---|---|---|
| Realistic diversity (8 nations/8 clubs/4 leagues, default) | 30 | **0.00%** | ~0% | ~0% | rarely |
| Moderate scarcity (3/3/2) | 30 | **0.00%** | ~0% | ~-4.5% (noise) | yes, ~66% of UB calls, but tiny (avg ≈1 point, max 3) |
| Extreme scarcity (1/1/1, everyone same nation/club/league) | 20 | **0.00%** | +2.6% | +1.5% | yes, large, but still 0 nodes saved |

Instrumented directly: the tightening term (`natExcess+clubExcess+lgExcess`) **is** computing and
firing correctly — I logged it separately from the node counts to be sure this wasn't just a bug
making the correction always zero. It fires often and, under extreme scarcity, by large amounts.
It just never happens to be the deciding factor: `RC+33` alone puts the untightened bound ~30-90
points above `best` for most of the tree (rating dominates the score, and pruning only starts
biting once the incumbent gets close to the ceiling), so shaving a handful of diversity points off
one component of the bound essentially never crosses `ub < best` when the untightened version
didn't already. Where it *could* plausibly matter is very late-game, near-full-tree states where
`best` is already close to the true ceiling — and that's exactly where `remainingSlots` (and hence
the maximum possible excess) is smallest, so the effect caps out at 1-3 points there too.

**Bottom line: this specific first-draft formula is sound (per Test 1) but not worth shipping** —
it adds real per-node cost (extra Set diffs) for a reduction that rounds to zero in every
configuration tried, including the most favorable one we could construct. If you want to revisit
this idea, it would need to interact with a term that isn't dwarfed by `RC+33` — e.g. tightening
`RC` itself per-branch (a cheaper per-branch rating cap) rather than the diversity side terms,
since `rating` is the term that actually decides most prunes at this score scale.

## Notes / things to double check if you extend this

- `fuzz_gendraft.js`'s synthetic universe is intentionally small/tunable; it is **not** a stand-in
  for real card-pool statistics (rating distribution, position frequency, nation/club skew all
  differ from `playerDB.json`). Conclusions about *soundness* (Test 1) generalize fine since they
  only depend on the solver logic, not the data distribution. Conclusions about the UB's practical
  *value* (Test 3) are more data-shape-dependent — if you have `playerDB.json`/`forms.json` handy,
  swapping `fuzz_gendraft.js` for the real `gendraft.js` (already written to the same interface:
  `generateDraft(opts) -> {formName, subForm, cards}`, `estimateCombos(form, cards)`) would let
  these same three test scripts run directly against real data with no other changes.
- Test 1's brute force cap (`COMBO_CAP = 60000`) is conservative for speed; it's fine to raise if
  you want to fuzz bigger/more realistic pools overnight.
