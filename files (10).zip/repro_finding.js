'use strict';
// node repro_finding.js findings.jsonl <lineNumber 1-based>  (default: last line)
const fs = require('fs');
const baseline = require('./solver.js');
const experimental = require('./solver_experimental.js');
const bruteforce = require('./bruteforce.js');

const file = process.argv[2] || 'findings.jsonl';
const lines = fs.readFileSync(file, 'utf8').trim().split('\n').filter(Boolean);
const lineNo = process.argv[3] ? parseInt(process.argv[3],10) : lines.length;
const finding = JSON.parse(lines[lineNo-1]);

console.log('Seed:', finding.seed, 'Form:', finding.formName, 'RC:', finding.rc);
console.log('Diagnosis:', finding.diagnosis);
console.log('Cards:', JSON.stringify(finding.cards, null, 2));

const truth = bruteforce.solve(finding.subForm, finding.cards);
console.log('\nBrute force best:', truth.best);
console.log('Baseline @ real RC:', baseline.solve(finding.subForm, finding.cards, finding.rc, Infinity).best);
console.log('Baseline @ RC=103:', baseline.solve(finding.subForm, finding.cards, 103, Infinity).best);
console.log('Experimental @ real RC:', experimental.solve(finding.subForm, finding.cards, finding.rc, Infinity).best);
console.log('Experimental @ RC=103:', experimental.solve(finding.subForm, finding.cards, 103, Infinity).best);
