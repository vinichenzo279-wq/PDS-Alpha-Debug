'use strict';
// True exhaustive enumeration: every legal assignment of candidates to slots (respecting only
// the hold/group-uniqueness constraint that solver.js also respects), no upper-bound pruning
// at all. This is the ground truth Test 1 compares solver.js (and the experimental variant)
// against. Only safe to run on small pools -- check estimateCombos() before calling.
const { scoreXI } = require('./engine.js');

function solve(form, cards){
  const slots = form.slots;
  const cand = slots.map(s => cards.filter(c => c.pos.includes(s)));
  if(cand.some(l => l.length === 0))
    return { error: 'A slot has no eligible card: ' + slots.filter((s,i)=>cand[i].length===0).join(', ') };

  for(const slot of cand) for(const c of slot){
    if(c._group === undefined) c._group = c.hold || ('C'+c.id);
  }
  // Smallest candidate lists first purely for enumeration speed; doesn't affect correctness.
  const order = slots.map((s,i)=>i).sort((a,b)=>cand[a].length-cand[b].length);
  const N = slots.length;

  let best = -1, bestXIs = [], nodes = 0;
  const usedGroups = new Set(), pick = new Array(N).fill(null);

  function dfs(k){
    nodes++;
    if(k === N){
      const xi = pick.slice(), sc = scoreXI(xi);
      if(sc.total > best){ best = sc.total; bestXIs = [{xi, sc}]; }
      else if(sc.total === best){ bestXIs.push({xi, sc}); }
      return;
    }
    const slotIdx = order[k];
    for(const c of cand[slotIdx]){
      const g = c._group;
      if(usedGroups.has(g)) continue;
      usedGroups.add(g); pick[slotIdx] = c;
      dfs(k+1);
      usedGroups.delete(g); pick[slotIdx] = null;
    }
  }
  dfs(0);
  return { best, bestXIs, nodes };
}

module.exports = { solve };
