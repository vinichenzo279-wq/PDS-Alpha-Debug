'use strict';
// TEST 3 -- does the scarcity-tightened UB (solver_experimental.js) actually reduce node count,
// and how much extra per-node compute does it cost to find out?
//
// Strategy: scan seeds with bigger pools (real pruning/search space) than Test 1 uses, keep
// ones whose combo count falls in a "genuinely searched, but finishable" band, then run BOTH
// solvers to completion (no cap) on each and record nodes + wall time. This gives:
//   - node-count reduction %  (does the tighter bound cut the tree down)
//   - time-per-node overhead % (does the extra scarcity bookkeeping cost more than it saves)
//   - net wall-time delta (the number that actually matters)
// Also runs both under a shared hard node cap to compare incumbent quality (best-so-far) when
// neither can finish -- the scenario the production diversity/hybrid solvers actually live in.
//
// Usage: node test3_ub_experiment.js [numDrafts] [startSeed] [minPer] [maxPer]
const { generateDraft, estimateCombos } = require('./fuzz_gendraft.js');
const { maxPossibleRating } = require('./engine.js');
const baseline = require('./solver.js');
const experimental = require('./solver_experimental.js');

const numDrafts = parseInt(process.argv[2] || '40', 10);
const startSeed = parseInt(process.argv[3] || '1', 10);
const minPer = parseInt(process.argv[4] || '4', 10);
const maxPer = parseInt(process.argv[5] || '6', 10);
// nation/club/league pool sizes: SMALL relative to slot count is what actually creates scarcity
// for the new UB to exploit (the real generator's default of 8/8/4 vs ~5-7 slots rarely runs out).
const nationCount = parseInt(process.argv[6] || '3', 10);
const clubCount = parseInt(process.argv[7] || '3', 10);
const leagueCount = parseInt(process.argv[8] || '2', 10);
const MIN_COMBOS = 1e3;    // want the tree big enough that pruning matters
const MAX_COMBOS = 2e6;    // but still finishable uncapped in a reasonable time
const HARD_CAP = 200000;   // shared node budget for the "capped" quality-comparison pass

function hrtimeMs(){ const t = process.hrtime.bigint(); return Number(t) / 1e6; }

let found = 0;
const rows = [];
const t0 = Date.now();

for(let seed = startSeed; found < numDrafts; seed++){
  const opts = { seed, minPer, maxPer, nationCount, clubCount, leagueCount };
  const d = generateDraft(opts);
  const est = estimateCombos(d.subForm, d.cards);
  if(est < MIN_COMBOS || est > MAX_COMBOS) continue;
  let rc; try{ rc = maxPossibleRating(d.cards, d.subForm); }catch(e){ continue; }
  if(rc === null) continue;

  found++;

  // -- uncapped: full completion, compare total nodes + wall time
  let t = hrtimeMs();
  const bFull = baseline.solve(d.subForm, d.cards, rc, Infinity);
  const bMs = hrtimeMs() - t;
  t = hrtimeMs();
  const eFull = experimental.solve(d.subForm, d.cards, rc, Infinity);
  const eMs = hrtimeMs() - t;

  // -- capped: shared node budget, compare incumbent quality
  const bCap = baseline.solve(d.subForm, d.cards, rc, HARD_CAP);
  const eCap = experimental.solve(d.subForm, d.cards, rc, HARD_CAP);

  const row = {
    seed, formName: d.formName, numCards: d.cards.length, est, rc,
    baselineNodes: bFull.nodes, baselineMs: +bMs.toFixed(2), baselineBest: bFull.best,
    expNodes: eFull.nodes, expMs: +eMs.toFixed(2), expBest: eFull.best,
    nodeReductionPct: +(100 * (1 - eFull.nodes / bFull.nodes)).toFixed(2),
    timeDeltaPct: +(100 * (eMs / bMs - 1)).toFixed(2),
    nsPerNodeBaseline: +((bMs*1e6) / bFull.nodes).toFixed(1),
    nsPerNodeExp: +((eMs*1e6) / eFull.nodes).toFixed(1),
    bestsAgree: bFull.best === eFull.best,
    cappedBaselineBest: bCap.best, cappedExpBest: eCap.best, cappedBaselineDone: bCap.done, cappedExpDone: eCap.done
  };
  rows.push(row);
  console.log(`seed=${seed} form=${d.formName} est=${est.toExponential(1)} nodes ${bFull.nodes}->${eFull.nodes} (${row.nodeReductionPct}%) time ${bMs.toFixed(0)}ms->${eMs.toFixed(0)}ms (${row.timeDeltaPct>0?'+':''}${row.timeDeltaPct}%) bestsAgree=${row.bestsAgree}`);
  if(!row.bestsAgree) console.log('  !! bests disagree -- see Test 1 for soundness, this run is suspect');
}

function avg(arr){ return arr.reduce((a,b)=>a+b,0)/arr.length; }
const avgNodeReduction = avg(rows.map(r=>r.nodeReductionPct));
const avgTimeDelta = avg(rows.map(r=>r.timeDeltaPct));
const avgNsBaseline = avg(rows.map(r=>r.nsPerNodeBaseline));
const avgNsExp = avg(rows.map(r=>r.nsPerNodeExp));
const perNodeOverheadPct = 100*(avgNsExp/avgNsBaseline - 1);
const disagreements = rows.filter(r=>!r.bestsAgree).length;
const cappedWins = rows.filter(r=>r.cappedExpBest > r.cappedBaselineBest).length;
const cappedLosses = rows.filter(r=>r.cappedExpBest < r.cappedBaselineBest).length;

console.log('\n=== TEST 3 SUMMARY ===');
console.log(`Drafts: ${found} (combo range ${MIN_COMBOS.toExponential(0)}-${MAX_COMBOS.toExponential(0)}, minPer=${minPer} maxPer=${maxPer})`);
console.log(`Avg node-count reduction from scarcity UB: ${avgNodeReduction.toFixed(2)}%`);
console.log(`Avg wall-time delta (full completion):     ${avgTimeDelta>0?'+':''}${avgTimeDelta.toFixed(2)}%  (negative = experimental is faster overall)`);
console.log(`Avg ns/node -- baseline: ${avgNsBaseline.toFixed(1)}, experimental: ${avgNsExp.toFixed(1)}  (per-node overhead: +${perNodeOverheadPct.toFixed(1)}%)`);
console.log(`bestsAgree mismatches: ${disagreements} / ${found}  ${disagreements>0 ? '<-- investigate with Test 1 / repro_finding.js' : '(good)'}`);
console.log(`Under shared ${HARD_CAP}-node cap: experimental found a BETTER incumbent in ${cappedWins}, WORSE in ${cappedLosses}, tied in ${found-cappedWins-cappedLosses}`);
console.log(`Total time: ${Date.now()-t0}ms`);

require('fs').writeFileSync(require('path').join(__dirname,'test3_results.json'), JSON.stringify(rows, null, 2));
console.log('Full per-draft results written to test3_results.json');
