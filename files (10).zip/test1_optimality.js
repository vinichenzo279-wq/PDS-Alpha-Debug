'use strict';
// TEST 1 -- "do we ever miss the optimal score?"
//
// For each seed: generate a SMALL draft (small enough that brute force is tractable), compute
// the real rating ceiling via maxPossibleRating (engine.js, unmodified production code), then
// run FOUR solves and compare all of them against the brute-force ground truth:
//   A) baseline solver  @ real RC   (production pruning as it actually runs today)
//   B) baseline solver  @ RC=103    (RC pushed artificially high so the RC term in the UB can
//                                    never be the thing that causes a miss -- isolates whether a
//                                    miss comes from the RC calculation vs the rest of the UB math)
//   C) experimental solver @ real RC   (new scarcity-tightened UB, per user's follow-up: verify
//                                       this never prunes away the optimum before judging its speed)
//   D) experimental solver @ RC=103    (same isolation logic as B, for the experimental UB)
//
// All four must equal brute force's best score, on every single draft, or it's a soundness bug.
// On any mismatch we dump the FULL reproducible draft (seed, opts, formName, every card, the
// brute-force optimum, and exactly which run(s) missed it and by how much) to findings.jsonl so
// the exact failing combo can be replayed later with node repro_finding.js findings.jsonl <line>.
//
// Usage: node test1_optimality.js [numSeeds] [startSeed] [minPer] [maxPer]
const fs = require('fs');
const path = require('path');
const { generateDraft, estimateCombos } = require('./fuzz_gendraft.js');
const { maxPossibleRating } = require('./engine.js');
const baseline = require('./solver.js');
const experimental = require('./solver_experimental.js');
const bruteforce = require('./bruteforce.js');

const numSeeds = parseInt(process.argv[2] || '2000', 10);
const startSeed = parseInt(process.argv[3] || '1', 10);
const minPer = parseInt(process.argv[4] || '2', 10);
const maxPer = parseInt(process.argv[5] || '3', 10);
const COMBO_CAP = 60000; // skip/regenerate anything bigger than this -- keep brute force fast
const RC_HIGH = 103;

const findingsPath = path.join(__dirname, 'findings.jsonl');
fs.writeFileSync(findingsPath, '');

let tested = 0, skipped = 0;
let misses = { baselineReal:0, baselineHigh:0, expReal:0, expHigh:0 };
const t0 = Date.now();

for(let seed = startSeed; tested < numSeeds; seed++){
  const opts = { seed, minPer, maxPer };
  const d = generateDraft(opts);
  const est = estimateCombos(d.subForm, d.cards);
  if(est === 0 || est > COMBO_CAP){ skipped++; continue; }
  tested++;

  let rc;
  try{ rc = maxPossibleRating(d.cards, d.subForm); }catch(e){ rc = null; }
  if(rc === null) rc = 99;

  const truth = bruteforce.solve(d.subForm, d.cards);
  if(truth.error){ skipped++; tested--; continue; }

  const runs = {
    baselineReal: baseline.solve(d.subForm, d.cards, rc, Infinity),
    baselineHigh: baseline.solve(d.subForm, d.cards, RC_HIGH, Infinity),
    expReal:      experimental.solve(d.subForm, d.cards, rc, Infinity),
    expHigh:      experimental.solve(d.subForm, d.cards, RC_HIGH, Infinity),
  };

  let anyMiss = false;
  const missDetail = {};
  for(const key of Object.keys(runs)){
    const r = runs[key];
    if(r.error){ missDetail[key] = 'error: '+r.error; anyMiss = true; continue; }
    if(!r.done){ missDetail[key] = 'DID NOT COMPLETE (should have -- combo cap should prevent this)'; anyMiss = true; continue; }
    if(r.best < truth.best){
      misses[key]++;
      missDetail[key] = { got: r.best, truth: truth.best, deficit: truth.best - r.best };
      anyMiss = true;
    } else if(r.best > truth.best){
      missDetail[key] = 'IMPOSSIBLE: solver beat brute force ('+r.best+' > '+truth.best+') -- bug in bruteforce.js or scoreXI mismatch';
      anyMiss = true;
    }
  }

  if(anyMiss){
    // Diagnostic categorization: does the miss disappear at RC=103? If so it's localized to the
    // RC term / maxPossibleRating; if it persists at RC=103 too, it's in the rest of the UB math.
    const diagnosis = [];
    if(missDetail.baselineReal && !missDetail.baselineHigh) diagnosis.push('baseline: RC-dependent (maxPossibleRating likely too tight, or RC term in UB)');
    if(missDetail.baselineReal && missDetail.baselineHigh) diagnosis.push('baseline: NOT RC-dependent -- bug in nation/league/club/icon/hero UB math itself');
    if(missDetail.expReal && !missDetail.expHigh) diagnosis.push('experimental: RC-dependent');
    if(missDetail.expReal && missDetail.expHigh) diagnosis.push('experimental: NOT RC-dependent -- bug in the new scarcity-tightening logic');
    if((missDetail.expReal || missDetail.expHigh) && !missDetail.baselineReal && !missDetail.baselineHigh)
      diagnosis.push('ONLY the experimental UB misses -- baseline is fine -- bug is isolated to the scarcity tightening added in solver_experimental.js');

    const finding = {
      seed, opts, formName: d.formName, subForm: d.subForm,
      numCards: d.cards.length, estimateCombos: est, rc,
      bruteForceBest: truth.best, bruteForceNodes: truth.nodes,
      missDetail, diagnosis,
      cards: d.cards
    };
    fs.appendFileSync(findingsPath, JSON.stringify(finding) + '\n');
    console.log(`MISS seed=${seed} form=${d.formName} truth=${truth.best} -> ${JSON.stringify(missDetail)}`);
  }

  if(tested % 200 === 0) console.log(`...tested ${tested} drafts (skipped ${skipped}, ${Date.now()-t0}ms)`);
}

console.log('\n=== TEST 1 SUMMARY ===');
console.log(`Drafts tested: ${tested} (skipped ${skipped} for being too big/degenerate, cap=${COMBO_CAP})`);
console.log(`Misses -- baseline@realRC: ${misses.baselineReal}, baseline@RC103: ${misses.baselineHigh}, experimental@realRC: ${misses.expReal}, experimental@RC103: ${misses.expHigh}`);
if(Object.values(misses).every(v=>v===0)){
  console.log('No soundness bugs found in this run: every solver run matched brute force on every draft.');
} else {
  console.log(`Findings with full repro data written to ${findingsPath}`);
}
console.log(`Total time: ${Date.now()-t0}ms`);
