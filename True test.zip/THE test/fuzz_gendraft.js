'use strict';
// Self-contained synthetic draft generator for fuzz testing. Deliberately does NOT depend on
// playerDB.json / forms.json (not available in this environment) -- instead builds a small,
// deterministic synthetic "universe" of nations/leagues/clubs/positions so we can dial pool
// size up or down to control combo counts (needed to keep brute force tractable for Test 1,
// and to dial pool size UP for Test 3's node-count comparisons).

function mulberry32(seed){
  return function(){
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const NATIONS = ['Argentina','Brazil','France','England','Spain','Germany','Portugal','Nigeria'];
const LEAGUES_NONPREM = ['La Liga','Bundesliga','Ligue 1','Serie A']; // hero-only leagues; normals are always Prem
const CLUBS = ['Redcliff','Kingsford','Northgate','Rovers','United','Athletic','City','Wanderers'];
const PREM = 'England Premier League';

// A handful of small formations, including duplicate-slot-label formations (e.g. 2x CB) so the
// group/hold-uniqueness logic and per-label indexing get exercised, same as real formations do.
// These stay small on purpose -- they're the pool used for brute-forceable tiers.
const FORMS_TINY = [
  {name:'Tiny-433',  slots:['GK','CB','CB','CM','ST']},
  {name:'Tiny-4231', slots:['GK','CB','CB','CDM','CAM','ST']},
  {name:'Tiny-352',  slots:['GK','CB','CB','CB','CM','ST','ST']},
];

// Full 11-slot formations, same structural shape as real drafts (index.html's forms.json),
// used for the "small"/"medium"/"large-realistic" complexity tiers where we want combo counts
// in the millions-to-hundreds-of-millions range without brute force being in play. Slot labels
// intentionally repeat (2x CB, 2x CM, etc.) so the group/hold-uniqueness logic is exercised at
// realistic width, not just the 5-7 slot Tiny forms.
const FORMS_REALISTIC = [
  {name:'Real-433',  slots:['GK','RB','CB','CB','LB','CDM','CM','CM','RW','ST','LW']},
  {name:'Real-4231', slots:['GK','RB','CB','CB','LB','CDM','CDM','CAM','RM','ST','LM']},
  {name:'Real-4141', slots:['GK','RB','CB','CB','LB','CDM','RM','CM','CM','LM','ST']},
  {name:'Real-352',  slots:['GK','CB','CB','CB','RM','CM','CM','CM','LM','ST','ST']},
];

const FORMS = [...FORMS_TINY, ...FORMS_REALISTIC];

function pick(rand, arr){ return arr[Math.floor(rand()*arr.length)]; }

// opts: { seed, minPer, maxPer, nationCount, clubCount, leagueCount, holdProb, formName }
function generateDraft(opts){
  opts = opts || {};
  const rand = opts.rng || mulberry32(opts.seed !== undefined ? opts.seed : (Math.random()*2**31|0));
  const rnd = (a,b) => Math.floor(rand()*(b-a+1))+a;

  const nations = NATIONS.slice(0, opts.nationCount || NATIONS.length);
  const clubs = CLUBS.slice(0, opts.clubCount || CLUBS.length);
  const leagues = LEAGUES_NONPREM.slice(0, opts.leagueCount || LEAGUES_NONPREM.length);

  // opts.formPool: optional array of form names to restrict random selection to (used by the
  // complexity tiers in test1_tiered.js so each tier draws from formations sized appropriately
  // for its target combo range). Falls back to the full FORMS list if omitted/empty.
  const pool = (opts.formPool && opts.formPool.length) ? FORMS.filter(x => opts.formPool.includes(x.name)) : FORMS;
  const f = opts.formName ? FORMS.find(x=>x.name===opts.formName) : pool[rnd(0, pool.length-1)];
  const minPer = opts.minPer !== undefined ? opts.minPer : 2;
  const maxPer = opts.maxPer !== undefined ? opts.maxPer : 3;
  const holdProb = opts.holdProb !== undefined ? opts.holdProb : 0.12; // chance a card shares a hold-group with a prior card

  let uid = 1;
  const cards = [];
  const priorIds = []; // for occasionally assigning a shared hold group to simulate loan/link pairs

  f.slots.forEach((pos, slotIdx) => {
    const n = rnd(minPer, maxPer);
    for(let i=0;i<n;i++){
      const r = rand();
      const type = r < 0.6 ? 'normal' : (r < 0.85 ? 'hero' : 'icon');
      const nation = pick(rand, nations);
      let league, club;
      if(type === 'normal'){ league = PREM; club = pick(rand, clubs); }
      else if(type === 'hero'){ league = rand() < 0.4 ? PREM : pick(rand, leagues); club = null; }
      else { league = 'Icons'; club = null; } // icon league is derived (leagueOf), club unused

      // Occasionally give this card 1-2 eligible positions (own slot's position, sometimes also
      // a neighboring slot's position) so a card can be a candidate for more than one slot --
      // exercises the group/usedGroups sharing logic across slots, like real flexible cards do.
      const posSet = new Set([pos]);
      if(rand() < 0.25){
        const other = pick(rand, f.slots);
        posSet.add(other);
      }

      let hold = null;
      if(priorIds.length && rand() < holdProb){
        const targetId = pick(rand, priorIds);
        hold = 'H' + targetId; // shared group string
        const target = cards.find(c => c.id === targetId);
        if(target && !target.hold) target.hold = hold; // retroactively link the earlier card into the same group
      }

      const id = uid++;
      cards.push({
        id, hold,
        name: 'C'+id, type,
        rating: rnd(75, 99),
        nation, league, club,
        pos: Array.from(posSet)
      });
      priorIds.push(id);
    }
  });

  const subForm = { name: f.name, slots: f.slots.slice() };
  return { formName: f.name, subForm, activeSlots: f.slots.length, cards };
}

function estimateCombos(form, cards){
  const cand = form.slots.map(s => cards.filter(c => c.pos.includes(s)).length);
  if(cand.some(n => n === 0)) return 0;
  let prod = 1;
  for(const n of cand){ prod *= n; if(prod > 1e15) return prod; }
  return prod;
}

module.exports = { generateDraft, estimateCombos, mulberry32, FORMS, FORMS_TINY, FORMS_REALISTIC, NATIONS, CLUBS, LEAGUES_NONPREM };
