'use strict';
// True exhaustive enumeration: every legal assignment of candidates to slots (respecting only
// the hold/group-uniqueness constraint that solver.js also respects), no upper-bound pruning
// at all. This is the ground truth Test 1 (and the "exact" complexity tiers in test1_tiered.js)
// compares solver.js (and the experimental variant) against. Only safe to run on small pools --
// check estimateCombos() before calling, and/or pass a nodeCap/timeBudgetMs (see opts below) so
// a misjudged pool size degrades to "inconclusive, capped" instead of hanging the process.
const { scoreXI } = require('./engine.js');

// opts (all optional, default = uncapped, matching the original signature/behavior exactly):
//   nodeCap:      stop after this many DFS nodes and return {capped:true}
//   timeBudgetMs: stop after this much wall-clock time and return {capped:true}
function solve(form, cards, opts){
  opts = opts || {};
  const nodeCap = opts.nodeCap !== undefined ? opts.nodeCap : Infinity;
  const timeBudgetMs = opts.timeBudgetMs !== undefined ? opts.timeBudgetMs : Infinity;
  const deadline = timeBudgetMs === Infinity ? Infinity : Date.now() + timeBudgetMs;
  const slots = form.slots;
  const cand = slots.map(s => cards.filter(c => c.pos.includes(s)));
  if(cand.some(l => l.length === 0))
    return { error: 'A slot has no eligible card: ' + slots.filter((s,i)=>cand[i].length===0).join(', ') };

  for(const slot of cand) for(const c of slot){
    if(c._group === undefined) c._group = c.hold || ('C'+c.id);
  }
  // Smallest candidate lists first purely for enumeration speed; doesn't affect correctness.
  const order = slots.map((s,i)=>i).sort((a,b)=>cand[a].length-cand[b].length);
  const N = slots.length;

  let best = -1, bestXIs = [], nodes = 0, capped = false;
  const usedGroups = new Set(), pick = new Array(N).fill(null);
  const TIME_CHECK_EVERY = 8192;

  function dfs(k){
    if(capped) return;
    nodes++;
    if(nodes > nodeCap){ capped = true; return; }
    if((nodes & (TIME_CHECK_EVERY-1)) === 0 && Date.now() > deadline){ capped = true; return; }
    if(k === N){
      const xi = pick.slice(), sc = scoreXI(xi);
      if(sc.total > best){ best = sc.total; bestXIs = [{xi, sc}]; }
      else if(sc.total === best){ bestXIs.push({xi, sc}); }
      return;
    }
    const slotIdx = order[k];
    for(const c of cand[slotIdx]){
      const g = c._group;
      if(usedGroups.has(g)) continue;
      usedGroups.add(g); pick[slotIdx] = c;
      dfs(k+1);
      usedGroups.delete(g); pick[slotIdx] = null;
      if(capped) return;
    }
  }
  dfs(0);
  return { best, bestXIs, nodes, capped, done: !capped };
}

module.exports = { solve };
