'use strict';
// Heuristic ground-truth PROXY for the "large-realistic" complexity tier, where combo counts
// (10s-100s of millions) make bruteforce.js intractable and the whole point of the tier is to
// exercise the solver at sizes it actually sees in production.
//
// This is deliberately NOT another tree search over the same recursive structure as
// solver.js/solver_experimental.js/bruteforce.js -- it's random-restart construction + local
// search (single-slot swaps), so a bug shared between the DFS-based tools (e.g. a scoreXI misuse,
// or an off-by-one in the group/hold logic that all three shared authors of the DFS code happened
// to share) is much less likely to be replicated here too. It gives an empirical LOWER BOUND on
// the true optimum, not an exact answer -- so it can only ever catch a solver returning LESS than
// what this found (a real miss), never certify a solver's answer as optimal. That asymmetry is
// intentional and is reflected in how test1_tiered.js interprets its output (see "heuristic"
// ground-truth handling there).
//
// Method:
//   1. Repeatedly build a random valid assignment (respecting hold/group uniqueness) by visiting
//      slots in a random order and picking uniformly among not-yet-used-group candidates.
//   2. Local-search each construction: repeatedly look for a single-slot swap (replace one pick
//      with another eligible, not-already-used-group card) that improves scoreXI().total, using
//      first-improvement steepest descent-ish hill climbing, until no improving move is found or
//      the local time budget runs out.
//   3. Keep the best result seen across all restarts within the overall time budget.
const { scoreXI } = require('./engine.js');

function buildCandidates(form, cards){
  const slots = form.slots;
  const cand = slots.map(s => cards.filter(c => c.pos.includes(s)));
  for(const slot of cand) for(const c of slot){
    if(c._group === undefined) c._group = c.hold || ('C'+c.id);
  }
  return cand;
}

function shuffle(arr, rng){
  const a = arr.slice();
  for(let i=a.length-1;i>0;i--){
    const j = Math.floor(rng()*(i+1));
    const t = a[i]; a[i]=a[j]; a[j]=t;
  }
  return a;
}

// Builds one random valid assignment. Returns null if it paints itself into a corner (some slot
// has no candidate left with an unused group) -- caller just retries with a fresh shuffle, cheap
// since these pools are richly populated at the sizes this tool targets.
function randomAssignment(cand, order, rng){
  const usedGroups = new Set();
  const pick = new Array(cand.length).fill(null);
  for(const idx of order){
    const options = cand[idx].filter(c => !usedGroups.has(c._group));
    if(options.length === 0) return null;
    const c = options[Math.floor(rng()*options.length)];
    usedGroups.add(c._group);
    pick[idx] = c;
  }
  return pick;
}

function localSearch(cand, pick, rng, deadline){
  let usedGroups = new Set(pick.map(c=>c._group));
  let sc = scoreXI(pick).total;
  let improved = true;
  let steps = 0;
  while(improved){
    improved = false;
    for(let i=0;i<pick.length;i++){
      if(Date.now() >= deadline) return { pick, score: sc, steps };
      const cur = pick[i];
      for(const alt of cand[i]){
        if(alt === cur) continue;
        if(alt._group !== cur._group && usedGroups.has(alt._group)) continue;
        const trial = pick.slice();
        trial[i] = alt;
        const s = scoreXI(trial).total;
        if(s > sc){
          pick = trial; sc = s; steps++;
          usedGroups = new Set(pick.map(c=>c._group));
          improved = true;
          break;
        }
      }
      if(improved) break;
    }
  }
  return { pick, score: sc, steps };
}

// opts: { timeBudgetMs (default 3000), rng, maxRestartAttempts (default 20 per restart to find
//         a feasible random assignment before giving up on that restart) }
function verify(form, cards, opts){
  opts = opts || {};
  const timeBudgetMs = opts.timeBudgetMs !== undefined ? opts.timeBudgetMs : 3000;
  const rng = opts.rng || Math.random;
  const maxRestartAttempts = opts.maxRestartAttempts || 20;
  const cand = buildCandidates(form, cards);
  if(cand.some(l => l.length === 0))
    return { error: 'A slot has no eligible card' };

  const baseOrder = cand.map((_,i)=>i);
  const deadline = Date.now() + timeBudgetMs;

  let best = -1, bestPick = null, restarts = 0, feasibleRestarts = 0, totalSteps = 0;
  while(Date.now() < deadline){
    restarts++;
    let pick = null, attempts = 0;
    while(pick === null && attempts < maxRestartAttempts){
      const order = shuffle(baseOrder, rng);
      pick = randomAssignment(cand, order, rng);
      attempts++;
    }
    if(pick === null) continue; // this restart couldn't find a feasible seed, skip it
    feasibleRestarts++;
    // Give each local search a slice of whatever time remains so one slow restart can't eat
    // the whole budget with nothing to show for it.
    const localDeadline = Math.min(deadline, Date.now() + Math.max(10, timeBudgetMs/8));
    const res = localSearch(cand, pick, rng, localDeadline);
    totalSteps += res.steps;
    if(res.score > best){ best = res.score; bestPick = res.pick; }
  }
  return { best, bestPick, restarts, feasibleRestarts, totalSteps };
}

module.exports = { verify };
