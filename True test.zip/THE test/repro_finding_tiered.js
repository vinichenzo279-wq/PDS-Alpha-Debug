'use strict';
// node repro_finding_tiered.js [findings_tiered.jsonl] [lineNumber 1-based]  (default: last line)
//
// Replays one exact failing draft from test1_tiered.js's findings file. Unlike repro_finding.js
// (which always has an exact bruteforce.js answer available), a tiered finding may have been
// generated against a heuristic ground truth ('heuristic' or 'heuristic-fallback' -- see
// finding.groundTruthUsed and finding.truthNote). This script re-runs everything it can
// (bruteforce too, uncapped, since if you're bothering to replay a finding you probably want the
// strongest answer available) and prints what ground truth was actually used when the finding
// was first recorded, so you don't mistake a heuristic-tier finding for a confirmed exact miss.
const fs = require('fs');
const baseline = require('./solver.js');
const experimental = require('./solver_experimental.js');
const bruteforce = require('./bruteforce.js');
const { verify: heuristicVerify } = require('./random_search_verifier.js');

const file = process.argv[2] || 'findings_tiered.jsonl';
const lines = fs.readFileSync(file, 'utf8').trim().split('\n').filter(Boolean);
if(lines.length === 0){ console.log('No findings in', file); process.exit(0); }
const lineNo = process.argv[3] ? parseInt(process.argv[3],10) : lines.length;
const finding = JSON.parse(lines[lineNo-1]);

console.log('Tier:', finding.tier, ' Seed:', finding.seed, ' Form:', finding.formName, ' RC:', finding.rc);
console.log('Ground truth used when this finding was recorded:', finding.groundTruthUsed, finding.truthNote ? '(' + finding.truthNote + ')' : '');
console.log('Diagnosis:', finding.diagnosis);
console.log('estimateCombos at record time:', finding.estimateCombos);

console.log('\n--- Re-running solvers ---');
console.log('Baseline @ real RC:', baseline.solve(finding.subForm, finding.cards, finding.rc, Infinity).best);
console.log('Baseline @ RC=103:', baseline.solve(finding.subForm, finding.cards, 103, Infinity).best);
console.log('Experimental @ real RC:', experimental.solve(finding.subForm, finding.cards, finding.rc, Infinity).best);
console.log('Experimental @ RC=103:', experimental.solve(finding.subForm, finding.cards, 103, Infinity).best);

console.log('\n--- Re-running heuristic verifier (10s budget, independent of the DFS solvers) ---');
const h = heuristicVerify(finding.subForm, finding.cards, { timeBudgetMs: 10000 });
console.log('Heuristic best found:', h.best, '(restarts:', h.restarts, ', feasible:', h.feasibleRestarts, ')');

if(finding.estimateCombos <= 6e4){
  console.log('\n--- Combo count is small enough to re-run exact brute force ---');
  const truth = bruteforce.solve(finding.subForm, finding.cards, { timeBudgetMs: 30000 });
  console.log('Brute force best:', truth.best, truth.capped ? '(TIMED OUT -- not exhaustive, treat as inconclusive)' : '(exhaustive)');
} else {
  console.log('\n--- estimateCombos =', finding.estimateCombos.toExponential(2), '-- too big to casually re-run exact brute force here.');
  console.log('    Pass a generous --bruteMs if you want to attempt it anyway; otherwise treat the');
  console.log('    heuristic verifier result above, and the RC-isolation runs, as the available evidence.');
}

console.log('\nFull card list:', JSON.stringify(finding.cards, null, 2));
