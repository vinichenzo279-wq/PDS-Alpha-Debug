'use strict';
// RC-sensitivity variant of fuzz_run.js. Same soundness check as the original (auto-RC and
// RC=103 vs brute), PLUS two extra probes at rcUsed-1 and rcUsed-2:
//
//   RC-1 ("boundary") probe: since maxPossibleRating()'s auto RC is only a bound on the RATING
//   term (not total score), lowering RC by 1 prunes branches whose rating alone could reach
//   rcUsed but not rcUsed-1. In theory this should only ever discard TIES for the true best total
//   score (never the score itself) UNLESS the true optimum's own rating component sits exactly at
//   rcUsed (a knife-edge case) or the auto-RC was already loose. We classify each RC-1 mismatch as
//   "score-preserved" (same best total, different/no XI) vs "score-dropped" (worse best total than
//   brute) so we can see which one actually happens and how often.
//
//   RC-2 ("smoke") probe: deliberately over-tightens RC by 2. This is a POSITIVE control: we
//   EXPECT this to sometimes miss the true best (prove RC pruning is load-bearing, i.e. not a
//   no-op) while still never exceeding brute. If RC-2 never once misses across many drafts, that
//   is itself worth flagging (either RC has a lot of natural slack, or the auto-RC formula already
//   bakes in extra margin).
const fs = require('fs');
const P = require('./prod_solver.js');
const B = require('./indep_brute.js');
const G = require('./fuzz_gen.js');

const SECONDS = parseInt(process.argv[2] || '60', 10);
const MAX_COMBOS = parseInt(process.argv[3] || '3000000', 10);
const BRUTE_MS = parseInt(process.argv[4] || '10000', 10);
const STATE = '/home/claude/fuzz_rcsens_state.json';
const FINDINGS = '/home/claude/fuzz_rcsens_findings.jsonl';

let state = {
  seed: 1, tested: 0, skippedBig: 0, skippedInfeasible: 0, bruteTimeouts: 0,
  findings: 0,                       // genuine UB-unsoundness (auto-RC or RC103 miss vs brute)
  rcm1_scorePreserved: 0,            // RC-1 matched brute's best total (ties may differ)
  rcm1_scoreDropped: 0,              // RC-1 found a WORSE total than brute -> not just a tie loss
  rcm1_tested: 0,
  rcm2_misses: 0,                    // RC-2 found worse than brute (expected/positive control)
  rcm2_matches: 0,                   // RC-2 still matched brute (RC had slack at -2 too)
  rcm2_tested: 0,
  byRegime: {}
};
try { state = Object.assign(state, JSON.parse(fs.readFileSync(STATE, 'utf8'))); } catch (e) {}

const deadline = Date.now() + SECONDS * 1000;

while (Date.now() < deadline) {
  const seed = state.seed++;
  const d = G.generate(seed);
  const est = B.estimateCombos(d.form, d.cards);
  if (est === 0) { state.skippedInfeasible++; continue; }
  if (est > MAX_COMBOS) { state.skippedBig++; continue; }

  let rc = null;
  try { rc = P.maxPossibleRating(d.cards, d.form); } catch (e) { rc = null; }
  const rcUsed = rc === null ? 96 : rc;

  const rs = P.solveBest(d.form, d.cards, 1e9, rcUsed);
  const rs103 = P.solveBest(d.form, d.cards, 1e9, 103);

  const bt = B.bruteForce(d.form, d.cards, P.scoreXI, { timeBudgetMs: BRUTE_MS });
  if (!bt.complete) { state.bruteTimeouts++; continue; }

  state.tested++;
  state.byRegime[d.regime] = (state.byRegime[d.regime] || 0) + 1;

  const solverBest = rs.error ? -1 : rs.best;
  const solver103 = rs103.error ? -1 : rs103.best;

  // --- original soundness check (auto-RC / RC103 vs brute) ---
  if (bt.best !== solverBest || bt.best !== solver103) {
    state.findings++;
    const finding = {
      kind: 'SOUNDNESS', seed, regime: d.regime, formName: d.formName, est,
      rcAuto: rcUsed, solverBestAtAutoRC: solverBest, solverBestAtRC103: solver103,
      bruteBest: bt.best,
      diagnosis: bt.best > solverBest
        ? (bt.best > solver103 ? 'UB-UNSOUND (missed even at RC 103)' : 'RC-RELATED (auto RC pruned it; RC 103 finds it)')
        : 'SOLVER-ABOVE-BRUTE (invalid-squad bug or brute legality bug)',
      form: d.form, cards: d.cards
    };
    fs.appendFileSync(FINDINGS, JSON.stringify(finding) + '\n');
    console.log('!!! SOUNDNESS FINDING seed=' + seed + ' -> ' + finding.diagnosis);
  }

  // --- RC-1 boundary probe ---
  const rcm1 = rcUsed - 1;
  const rsM1 = P.solveBest(d.form, d.cards, 1e9, rcm1);
  const solverM1 = rsM1.error ? -1 : rsM1.best;
  state.rcm1_tested++;
  if (solverM1 === bt.best) {
    state.rcm1_scorePreserved++;
  } else if (solverM1 < bt.best) {
    state.rcm1_scoreDropped++;
    const finding = {
      kind: 'RC-1_SCORE_DROPPED', seed, regime: d.regime, formName: d.formName, est,
      rcAuto: rcUsed, rcMinus1: rcm1, solverAtRcMinus1: solverM1, bruteBest: bt.best,
      note: 'RC-1 lost the true best total, not just a tie -- contradicts the "only skips ties" expectation',
      form: d.form, cards: d.cards
    };
    fs.appendFileSync(FINDINGS, JSON.stringify(finding) + '\n');
    console.log('!!! RC-1 SCORE DROPPED seed=' + seed + ' rcAuto=' + rcUsed + ' solverAtRC-1=' + solverM1 + ' brute=' + bt.best);
  } else {
    // solverM1 > bt.best would itself be a soundness bug (solver above brute) -- log it as such
    state.rcm1_scoreDropped++; // count as anomaly bucket too
    console.log('!!! RC-1 SOLVER ABOVE BRUTE seed=' + seed + ' solverAtRC-1=' + solverM1 + ' brute=' + bt.best);
  }

  // --- RC-2 smoke probe (expected to occasionally miss) ---
  const rcm2 = rcUsed - 2;
  const rsM2 = P.solveBest(d.form, d.cards, 1e9, rcm2);
  const solverM2 = rsM2.error ? -1 : rsM2.best;
  state.rcm2_tested++;
  if (solverM2 < bt.best) {
    state.rcm2_misses++;
  } else {
    state.rcm2_matches++;
  }
}

fs.writeFileSync(STATE, JSON.stringify(state));
console.log(`[fuzz-rcsens] tested=${state.tested} findings(soundness)=${state.findings} bruteTimeouts=${state.bruteTimeouts}`);
console.log(`[fuzz-rcsens] RC-1: tested=${state.rcm1_tested} scorePreserved=${state.rcm1_scorePreserved} scoreDroppedOrAnomaly=${state.rcm1_scoreDropped}`);
console.log(`[fuzz-rcsens] RC-2: tested=${state.rcm2_tested} misses=${state.rcm2_misses} (expected>0, proves RC is load-bearing) matches=${state.rcm2_matches}`);
console.log('[fuzz-rcsens] byRegime:', JSON.stringify(state.byRegime));
