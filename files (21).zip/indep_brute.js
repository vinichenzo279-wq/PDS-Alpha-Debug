'use strict';
// INDEPENDENT exhaustive enumerator. Deliberately shares NO traversal code or structure with the
// production solver: iterative odometer (index-vector increment) over per-slot candidate lists,
// no recursion, no ordering heuristics, no upper bounds, no pruning of any kind except the
// hold-group-uniqueness legality rule itself. Every legal assignment is scored. The ONLY shared
// code is scoreXI (injected) — deliberate: this harness tests SEARCH soundness (can the solver's
// pruning ever discard the true optimum?), and both sides must agree on what a squad is worth for
// that comparison to mean anything. scoring bugs are out of scope by design.
//
// Legality rule enumerated independently: one card per slot, card must list the slot's position,
// and no two chosen cards may share a hold group (hold string if set, else the card itself).

function bruteForce(form, cards, scoreXI, opts){
  opts = opts || {};
  const nodeCap = opts.leafCap !== undefined ? opts.leafCap : Infinity; // counts LEAVES tried (incl. illegal partials skipped)
  const deadline = opts.timeBudgetMs ? Date.now() + opts.timeBudgetMs : Infinity;
  const slots = form.slots;
  const N = slots.length;

  // per-slot candidate index lists (indices into cards[])
  const cand = [];
  for (let s = 0; s < N; s++) {
    const list = [];
    for (let i = 0; i < cards.length; i++) {
      if (cards[i].pos.indexOf(slots[s]) !== -1) list.push(i);
    }
    if (list.length === 0) return { best: -1, bestXI: null, leaves: 0, complete: true, infeasible: true };
    cand.push(list);
  }

  // group id per card (independent derivation)
  const groupOf = cards.map(c => (c.hold !== null && c.hold !== undefined) ? ('H:' + c.hold) : ('S:' + c.id));

  const idx = new Array(N).fill(0);   // odometer digits
  const chosen = new Array(N);        // card indices for current assignment
  let best = -1, bestXI = null, leaves = 0, checked = 0;
  let complete = true;

  // odometer loop: at each state, validate the FULL assignment from scratch (no incremental
  // state carried between iterations — slower, but immune to backtracking-bookkeeping bugs,
  // which is the entire point of an independent oracle).
  outer:
  while (true) {
    checked++;
    if (checked > nodeCap) { complete = false; break; }
    if ((checked & 8191) === 0 && Date.now() > deadline) { complete = false; break; }

    // build + validate current assignment
    let legal = true;
    const seen = Object.create(null);
    for (let s = 0; s < N; s++) {
      const ci = cand[s][idx[s]];
      chosen[s] = ci;
      const g = groupOf[ci];
      if (seen[g]) { legal = false; break; }
      seen[g] = true;
    }
    if (legal) {
      leaves++;
      const xi = chosen.map(ci => cards[ci]);
      const sc = scoreXI(xi);
      if (sc.total > best) { best = sc.total; bestXI = xi.slice(); }
    }

    // increment odometer
    let s = N - 1;
    while (s >= 0) {
      idx[s]++;
      if (idx[s] < cand[s].length) continue outer;
      idx[s] = 0;
      s--;
    }
    break; // odometer wrapped fully -> done
  }

  return { best, bestXI, leaves, checked, complete, infeasible: false };
}

function estimateCombos(form, cards) {
  let prod = 1;
  for (const s of form.slots) {
    let n = 0;
    for (const c of cards) if (c.pos.indexOf(s) !== -1) n++;
    if (n === 0) return 0;
    prod *= n;
    if (prod > 1e15) return prod;
  }
  return prod;
}

module.exports = { bruteForce, estimateCombos };
