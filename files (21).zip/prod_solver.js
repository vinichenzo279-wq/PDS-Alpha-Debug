'use strict';
// Extracted verbatim from index.html (Draft Solver) — scoreXI, solveBest, maxPossibleRating
// and their exact dependency closure (futRatingRaw, leagueOf, trueChem, ubDComponent,
// ubEGlobal, minCostMaxFlow, spMaxBoundPerSlot, ubH2Bound). No UI/DOM code included.
function futRatingRaw(rs){const S=rs.reduce((a,b)=>a+b,0),A=S/rs.length;let sp=0;for(const r of rs)if(r>A)sp+=r-A;return (S+sp)/rs.length;}
function futRating(rs){return Math.floor(futRatingRaw(rs));}
function leagueOf(c){return c.type==='icon'?'Icons':c.type==='hero'?c.league:'England Premier League'}
// Correct Pacwyn chemistry, used ONLY when full 33 isn't reached (a bust anyway).
// icons & heroes always 3 chem each.
// icons ALSO contribute +2 to their nation count AND +1 to every league count (universal wildcard).
// heroes contribute a flat +2 to their own league count.
// normals earn nation(2/5/8->1/2/3) + club(2/4/7->1/2/3) + league(3/5/8->1/2/3), capped 3.
// league pool: normals=Prem, icons add +1 to ALL leagues, prem-heroes +2 to Prem; non-prem heroes +2 to their own league.
function trueChem(xi){
  const natCnt={},clubCnt={},lgCnt={};let icons=0,normals=0;
  xi.forEach(c=>{
    if(c.type==='icon'){
      icons++;
      natCnt[c.nation]=(natCnt[c.nation]||0)+2;
    } else if(c.type==='hero'){
      natCnt[c.nation]=(natCnt[c.nation]||0)+1;
      const lg=leagueOf(c);
      lgCnt[lg]=(lgCnt[lg]||0)+2; // flat +2 per hero
    } else {
      normals++;
      natCnt[c.nation]=(natCnt[c.nation]||0)+1;
      clubCnt[c.club]=(clubCnt[c.club]||0)+1;
    }
  });
  // icons add +1 to every league. Prem is always relevant (all normals are prem).
  // Apply to Prem unconditionally, and to any other hero leagues already in lgCnt.
  if(icons>0){
    lgCnt['England Premier League']=(lgCnt['England Premier League']||0)+icons;
    for(const lg of Object.keys(lgCnt)){
      if(lg!=='England Premier League')lgCnt[lg]+=icons;
    }
  }
  // premLeague: normals + hero/icon contributions now all in lgCnt['England Premier League']
  const premLeague=normals+(lgCnt['England Premier League']||0);
  const nP=n=>n>=8?3:n>=5?2:n>=2?1:0;
  const cP=n=>n>=7?3:n>=4?2:n>=2?1:0;
  const lP=n=>n>=8?3:n>=5?2:n>=3?1:0;
  let t=0;
  xi.forEach(c=>{
    if(c.type==='icon'||c.type==='hero'){t+=3;return;}
    const lg=leagueOf(c);
    const lgScore=lg==='England Premier League'?lP(premLeague):lP(lgCnt[lg]||0);
    t+=Math.min(3,nP(natCnt[c.nation]||0)+cP(clubCnt[c.club]||0)+lgScore);
  });
  return t;
}
function scoreXI(xi){
  const ratingExact=futRatingRaw(xi.map(c=>c.rating)),rating=Math.floor(ratingExact);
  const nations=new Set(xi.map(c=>c.nation)).size;
  const leagues=new Set(xi.map(leagueOf)).size;
  const premClubs=new Set(xi.filter(c=>c.type==='normal').map(c=>c.club)).size;
  const hasIcon=xi.some(c=>c.type==='icon'),hasHero=xi.some(c=>c.type==='hero');
  const clubs=premClubs+(hasIcon?1:0)+(hasHero?1:0);
  const glue=xi.filter(c=>c.type==='icon'||c.type==='normal').length;
  const premHeroCount=xi.filter(c=>c.type==='hero'&&c.league==='England Premier League').length;
  // premPool mirrors trueChem's premLeague: normals + icons (both in glue) + prem heroes flat +2 each
  const premPool=glue+premHeroCount*2;
  const full=premPool>=8||xi.every(c=>c.type==='icon'||c.type==='hero');
  const chem=full?3*xi.length:trueChem(xi);
  return {rating,ratingExact,chem,nations,leagues,clubs,full,glue,total:rating+chem+nations+leagues+clubs,
    nationSet:new Set(xi.map(c=>c.nation)),leagueSet:new Set(xi.map(leagueOf)),
    clubSet:new Set(xi.filter(c=>c.type==='normal').map(c=>c.club))};
}

/* ============================ SOLVER (DFS + bound) ============================ */
function solveBest(form,cards,nodeCap,ratingCeil,seedBest,seedXIs,skipTies,diversitySeed){
  const ST=!!skipTies; // "Skip ties": prune branches that can only TIE the best (strict-improvement B&B) and stop collecting tied XIs. Provably keeps the optimal SCORE (never prunes a strictly-better branch, whose admissible bound must exceed best); only tied lineups are dropped.
  const RC=ratingCeil!==undefined?ratingCeil:99;
  const slots=form.slots;
  // v11.0 presort — rating-desc first as always (v5.1 best-first), but ties between EQUAL-rated
  // candidates are now broken by within-slot rarity: 1/(count of this nation in this slot's own
  // pool) + for normals 1/(count of this club in this slot's pool), weighted 0.4 each. Max nudge
  // 0.8 < 1, ratings are integers, so a lower-rated card can NEVER be tried before a higher-rated
  // one (verified over 20k random pools: 0 rating-order violations) — this is purely a tie-break.
  // Rationale: an equal-rated card that's the only one of its nation/club here banks a "free"
  // diversity point earlier, so capped searches sit on a better incumbent when cut off. Computed
  // ONCE per slot before the search (same cost class as the old sort); ordering only — candidates,
  // pruning, UB, and traversal structure are untouched, so any completed search returns the exact
  // same optimum as before (verified: identical best on every fixture; total node count identical
  // in 149/150 broad fuzz drafts). Where it earns its keep is CAPPED searches on huge drafts
  // (est. 10^8–10^12 combos, 10M-node cap, head-to-head on identical drafts): 56 hard trials —
  // 50 all-tied, and of the 6 divergences divstatic won 5 (+1 pt each) and lost 1 (seed 91041,
  // −2 pts). Also tested and REJECTED in the same campaign: (a) per-node dynamic re-sorting by
  // live path state (the removed v5.6 idea, re-tried at up to 150M nodes) — never beat this static
  // version on final score, 4–25% slower wall-time, reconfirming the v8.2 removal; (b) eight
  // isolated single-factor tie-breaks (position-flexibility both directions, nation/club/league
  // rarity alone, icon-first/normal-first type priority) — zero effect on total nodes in 120
  // broad trials each, and the only hard-trial divergence had club/league/icon-first variants
  // LOSING a point; the nation+club BLEND is the only ordering found to add anything.
  //
  // v12.0 DIVERSITY: when `diversitySeed` is a number, each slot's candidate list is instead
  // FULLY SHUFFLED (deterministically, from that seed) rather than divstatic-ordered. This throws
  // away best-first on purpose so the search walks a completely different region of the tree — used
  // only by the optional, default-off "search diversity" wrapper (solveWithDiversity below), which
  // spends part of the node budget on divstatic first (best incumbent) and the rest on one or more
  // seeded-shuffle passes, keeping whichever pass scored highest. As a FORCED default this is worse
  // (best-first ordering does real work — pure-shuffle lost to divstatic on ~65% of hard drafts),
  // but as an OPTIONAL alternate it strictly beat pure divstatic at equal budget on ~13% of hard
  // realistic drafts (+1 to +3 pts), symmetric high-variance — so it only ever helps here because
  // the wrapper keeps the max across passes, never the shuffle alone. Ordering-only, exactly like
  // the divstatic path: pruning/UB/traversal untouched, so a run that COMPLETES still returns the
  // true optimum regardless of seed. See the v12.0 CHANGELOG entry for the full experiment.
  const _divShuffle=(typeof diversitySeed==='number');
  let _dseed=(diversitySeed|0)||1;
  const _drand=()=>{_dseed|=0;_dseed=(_dseed+0x6D2B79F5)|0;let t=Math.imul(_dseed^(_dseed>>>15),1|_dseed);t=(t+Math.imul(t^(t>>>7),61|t))^t;return((t^(t>>>14))>>>0)/4294967296;};
  const cand=slots.map(s=>{
    const list=cards.filter(c=>c.pos.includes(s));
    if(_divShuffle){ // deterministic Fisher–Yates from the per-call seed (advances _dseed across slots)
      const a=list.slice();
      for(let i=a.length-1;i>0;i--){const j=Math.floor(_drand()*(i+1));const tmp=a[i];a[i]=a[j];a[j]=tmp;}
      return a;
    }
    const natCount={},clubCount={};
    for(const c of list){
      natCount[c.nation]=(natCount[c.nation]||0)+1;
      if(c.type==='normal')clubCount[c.club]=(clubCount[c.club]||0)+1;
    }
    return list.map(c=>({c,k:c.rating+0.4/(natCount[c.nation]||1)+(c.type==='normal'?0.4/(clubCount[c.club]||1):0)}))
      .sort((a,b)=>b.k-a.k).map(x=>x.c);
  });
  if(cand.some(l=>l.length===0))
    return {error:'A slot has no eligible card: '+slots.filter((s,i)=>cand[i].length===0).join(', ')};
  // v5.5 #2: cache _lg (leagueOf) and _group on every candidate once instead of recomputing in the hot loop
  for(const slot of cand)for(const c of slot){
    if(c._lg===undefined)c._lg=leagueOf(c);
    if(c._group===undefined)c._group=c.hold||('C'+c.id);
  }
  const order=slots.map((s,i)=>i).sort((a,b)=>cand[a].length-cand[b].length);
  // v6 UB precompute — per remaining slot, the OLD bound assumed a flat "+2" for anything
  // that wasn't the one reserved "first icon"/"first hero" slot. That's safe (never an
  // underestimate) but loose whenever a slot's candidate pool is icon-only or hero-only —
  // e.g. a position where a user has stacked several icons and has no normal/hero card that
  // fits there. A 2nd+ icon can only ever add +1 (nation; "Icons" league + the icon club-
  // bonus are awarded once, to whichever icon comes first), so an icon-only slot's true max
  // is +1, not +2. This is computed ONCE per solveBest() call (static — resorting cand[] for
  // traversal order doesn't change which TYPES are present) as suffix aggregates, so the
  // per-node bound check below stays O(1), same as before.
  const slotTypes=cand.map(list=>{const s=new Set();for(const c of list)s.add(c.type);return s;});
  // v12.4.0: per-slot "every hero option here is a Prem-league hero" flag. A hero whose own
  // league IS 'England Premier League' doesn't add a fresh league the way a non-Prem hero does --
  // that league point is the same shared Prem bucket normals/premUnseen already cover globally,
  // earned once no matter how many Prem sources could supply it. So a slot whose only hero
  // candidates are Prem-league heroes can guarantee nation (+1) from that option, not nation+
  // league (+2) -- the old code credited +2 unconditionally, double-counting against premUnseen
  // in this one narrow case. See v12.4.0 CHANGELOG.
  const slotHeroAllPrem=cand.map(list=>{
    const heroes=list.filter(c=>c.type==='hero');
    return heroes.length>0&&heroes.every(c=>c.league==='England Premier League');
  });
  const N=slots.length;
  const ubBaseline=new Array(N),ubSuffixBase=new Array(N+1).fill(0);
  const ubTopIconV=new Array(N+1),ubTopIconI=new Array(N+1),ubTopIconV2=new Array(N+1),ubTopIconI2=new Array(N+1);
  const ubTopHeroV=new Array(N+1),ubTopHeroI=new Array(N+1),ubTopHeroV2=new Array(N+1),ubTopHeroI2=new Array(N+1);
  ubTopIconV[N]=-Infinity;ubTopIconI[N]=-1;ubTopIconV2[N]=-Infinity;ubTopIconI2[N]=-1;
  ubTopHeroV[N]=-Infinity;ubTopHeroI[N]=-1;ubTopHeroV2[N]=-Infinity;ubTopHeroI2[N]=-1;
  for(let k=N-1;k>=0;k--){
    const idx=order[k];
    const st=slotTypes[idx];
    // v12.4.0: hero baseline is 2 (nation+own league) unless every hero option here is Prem-only,
    // in which case it's 1 (nation only -- the league point is the shared Prem bucket, not a
    // fresh per-slot one).
    const heroBase=slotHeroAllPrem[idx]?1:2;
    let b=-Infinity;
    if(st.has('normal'))b=2;
    if(st.has('hero')&&b<heroBase)b=heroBase;
    if(st.has('icon')&&b<1)b=1;
    ubBaseline[k]=b;ubSuffixBase[k]=ubSuffixBase[k+1]+b;
    let iv=ubTopIconV[k+1],ii=ubTopIconI[k+1],iv2=ubTopIconV2[k+1],ii2=ubTopIconI2[k+1];
    if(st.has('icon')){const g=3-b;if(g>iv){iv2=iv;ii2=ii;iv=g;ii=k;}else if(g>iv2){iv2=g;ii2=k;}}
    ubTopIconV[k]=iv;ubTopIconI[k]=ii;ubTopIconV2[k]=iv2;ubTopIconI2[k]=ii2;
    // v12.4.0: the "first hero" bonus is always exactly +1 -- the one-time hero-club flag
    // (scoreXI's hasHero -> clubs+1) -- never 3-b. Previously b was always 2 for any hero-
    // possible slot, so 3-b always happened to come out to 1 anyway; now that Prem-exclusive
    // slots correctly get b=1, leaving this as 3-b would silently reinflate to 2, re-adding the
    // league point baseline just removed. Hardcoding the true, category-independent gain avoids
    // that regression and keeps every previously-existing case byte-identical (g was always 1
    // there too, just derived instead of stated).
    let hv=ubTopHeroV[k+1],hi=ubTopHeroI[k+1],hv2=ubTopHeroV2[k+1],hi2=ubTopHeroI2[k+1];
    if(st.has('hero')){const g=1;if(g>hv){hv2=hv;hi2=hi;hv=g;hi=k;}else if(g>hv2){hv2=g;hi2=k;}}
    ubTopHeroV[k]=hv;ubTopHeroI[k]=hi;ubTopHeroV2[k]=hv2;ubTopHeroI2[k]=hi2;
  }
  let best=(typeof seedBest==="number"&&seedBest>=0)?seedBest:-1;
  let bestXIs=(best>=0&&seedXIs&&seedXIs.length)?seedXIs.map(x=>({xi:x.xi,sc:x.sc,foundAt:0,seed:true})):[];
  // Highest TRUE squad rating (floor(ratingExact), the same integer that enters sc.total) seen across
  // every complete XI scored. RC only ever enters the search as the rating ceiling in the pruning UB
  // (ub = RC+33+chem/diversity); the score itself never clamps rating. So comparing this max to RC
  // tells the user whether RC was actually binding: max<RC means RC never touched a real squad (sound,
  // and RC could be lowered to save time); max===RC is the boundary (a higher-rated squad, if one
  // exists, would rate >RC and could have been pruned before we ever scored it); max>RC means the UB
  // underestimated at least one branch's rating, so better squads were likely pruned. One integer
  // compare per leaf — sc.rating is already computed for the score, so this adds no measurable cost.
  let maxRating=-1;
  if(bestXIs.length)for(const b of bestXIs){const rr=b.sc&&b.sc.rating;if(typeof rr==='number'&&rr>maxRating)maxRating=rr;}
  let nodes=0;const CAP=nodeCap||3000000;let capped=false;
  const usedGroups=new Set(),pick=new Array(slots.length).fill(null);
  // v5.5 #1: incremental diversity state — add on descent, delete on backtrack; eliminates
  // ~9M Set allocations at the 3M-node cap that the old per-node filter/map/Set pattern caused.
  const seenNat=new Set(),seenLg=new Set(),seenClub=new Set();
  let partialIcon=0,partialHero=0;
  function dfs(k){
    if(nodes++>CAP){capped=true;return;}
    if(capped)return;
    if(k===order.length){
      const xi=pick.slice(),sc=scoreXI(xi);
      if(sc.rating>maxRating)maxRating=sc.rating;   // cheap: sc.rating already computed for the score
      if(sc.total>best){best=sc.total;const key=xi.map(c=>c.id).sort().join(',');bestXIs=[{xi,sc,foundAt:nodes,key}]}
      else if(!ST && sc.total===best){
        const key=xi.map(c=>c.id).sort().join(',');
        if(!bestXIs.some(b=>(b.key||(b.key=b.xi.map(c=>c.id).sort().join(',')))===key))bestXIs.push({xi,sc,foundAt:nodes,key});
      }
      return;
    }
    const slotIdx=order[k];
    // v6 tighter UB — per remaining slot, use its ACTUAL candidate-type composition
    // (ubBaseline/ubSuffixBase, precomputed once above) instead of assuming every slot
    // can flex to +2. Baseline per slot (no "first icon/hero" bonus yet): normal=2
    // (nation+club), hero=2 (nation+own league), icon=1 (nation only — "Icons" league
    // and the icon club-bonus are only ever awarded once, to the first icon overall).
    // On top of the suffix's total baseline we optimally award the at-most-one remaining
    // "first icon" bonus (+2 over that slot's baseline) and at-most-one "first hero" bonus
    // (+1 over baseline) to whichever eligible slots gain the most — trying both assignment
    // orders (icon picks first vs hero picks first) since a slot able to take either bonus
    // can only be awarded one of them. Falls back to the old flat "+2 everywhere" bound
    // whenever every remaining slot also has a normal/hero option (the common case), so this
    // only bites — and only helps — when a position pool has gone icon/hero-only.
    // Verified against 20k+ randomized states + brute force: never below the true max,
    // and strictly tighter than the old bound in ~45% of those states.
    if(best>=0){
      const premUnseen=seenLg.has('England Premier League')?0:1;
      const total0=ubSuffixBase[k];
      let bonusGain;
      if(partialIcon&&partialHero){
        bonusGain=0;
      }else{
        const ic0v=partialIcon?0:(ubTopIconV[k]>0?ubTopIconV[k]:0),ic0i=partialIcon?-1:ubTopIconI[k];
        const he0v=partialHero?0:(ubTopHeroV[k]>0?ubTopHeroV[k]:0),he0i=partialHero?-1:ubTopHeroI[k];
        let orderA=ic0v; // icon takes its best slot first
        if(!partialHero){
          if(he0i!==ic0i)orderA+=he0v;
          else orderA+=(ubTopHeroV2[k]>0?ubTopHeroV2[k]:0);
        }
        let orderB=he0v; // hero takes its best slot first
        if(!partialIcon){
          if(ic0i!==he0i)orderB+=ic0v;
          else orderB+=(ubTopIconV2[k]>0?ubTopIconV2[k]:0);
        }
        bonusGain=Math.max(orderA,orderB);
      }
      const ub=RC+33
        +seenNat.size+seenLg.size+seenClub.size+partialIcon+partialHero
        +total0+bonusGain+premUnseen;
      if(ST?ub<=best:ub<best)return; // ST: a branch that can only reach `best` is a tie we do not need
    }
    // v5.6 dynamic in-flight presort — reorders cand[slotIdx] using the *live* path state
    // (seenNat/seenLg/seenClub/partialIcon/partialHero) instead of the static rating-only
    // order computed once before the search began. A card's true value along THIS path is
    // rating + whatever NEW nation/league/club it would add right now; that marginal value
    // shifts every time a different sibling is picked higher up the tree, so resorting per
    // node keeps best-first traversal accurate as the search descends, not just at depth 0.
    // This is ordering only — every candidate already in cand[slotIdx] is still iterated and
    // the usedGroups skip + UB bound above are untouched, so no node is pruned that the static
    // order would have visited; we only change WHEN each sibling is tried, which lets `best`
    // converge faster and makes the existing UB cutoff bite earlier on capped searches.
    // Safe to sort in place: `order` is a fixed permutation computed once, so each depth k
    // owns exactly one slotIdx for the whole search — no other stack frame is ever mid-loop
    // over this same array, so resorting it here can't disturb a parent's in-progress iteration.
    // [v8.2 REMOVED: the v5.6 dynamic in-flight presort that lived here — a full comparator sort
    // (~10 Set.has per comparison) at EVERY node with >1 candidate. Measured head-to-head: optimum
    // identical on every fixture at every RC, capped-incumbent quality identical at 500k/3M caps on
    // the two hardest drafts, fingerprint 357,777 untouched — and removing it is 10-16% faster
    // wall-time across the board (nodes +1.8% on one fixture, each node far cheaper). The static
    // rating-order computed once before the search already finds the incumbent just as fast; the
    // endgame is bound-proving, which ordering cannot help. Same lesson as scarcity ordering and
    // the suffix resource caps: per-node cleverness must be measured, and it keeps losing.]
    for(const c of cand[slotIdx]){
      const g=c._group;
      if(usedGroups.has(g))continue;
      usedGroups.add(g);pick[slotIdx]=c;
      // Incremental updates (O(1) each)
      const addNat=seenNat.has(c.nation)?0:(seenNat.add(c.nation),1);
      const addLg =seenLg.has(c._lg)   ?0:(seenLg.add(c._lg),1);
      const addClub=c.type==='normal'&&!seenClub.has(c.club)?(seenClub.add(c.club),1):0;
      const addIcon=!partialIcon&&c.type==='icon'?1:0;if(addIcon)partialIcon=1;
      const addHero=!partialHero&&c.type==='hero'?1:0;if(addHero)partialHero=1;
      dfs(k+1);
      // Backtrack (O(1) each)
      if(addNat) seenNat.delete(c.nation);
      if(addLg)  seenLg.delete(c._lg);
      if(addClub)seenClub.delete(c.club);
      if(addIcon)partialIcon=0;
      if(addHero)partialHero=0;
      usedGroups.delete(g);pick[slotIdx]=null;
      if(capped)return;
    }
  }
  dfs(0);
  return {best,bestXIs,nodes,capped,slots,maxRating,rcUsed:RC};
}

// v12.0 — optional "search diversity" wrapper around solveBest. DEFAULT OFF: mode 0 (or falsy)
// runs plain divstatic exactly as before, one call, zero overhead — so nobody who leaves the
// setting alone is affected in any way. When a diversity mode is chosen, the SAME total node
// budget `cap` is split into phases: phase 1 is always divstatic (best-first, establishes a strong
// incumbent), and the remaining phases are seeded-shuffle passes (see solveBest's diversitySeed)
// that walk different regions of the tree. Every phase is seeded with the best score+lineups found
// so far (solveBest's seedBest/seedXIs), so a later phase's pruning starts hot and it can only ADD
// lineups/score relative to the phases BEFORE it in this same run — never lose ground already
// found earlier in the run. If ANY phase completes its whole tree (not capped), that result is
// the proven optimum and we stop early.
// CORRECTED v12.3.2 (see CHANGELOG): this does NOT mean the wrapper's result is >= a plain,
// uninterrupted divstatic solve at the same total budget — that was the original claim here and
// testing showed it's false. Phase 1 only gets a FRACTION of the budget, and divstatic's own
// best-first trajectory doesn't always plateau early; sometimes the back half of an uninterrupted
// run is still finding better incumbents, not just proving optimality. Cutting phase 1 short to
// make room for shuffle passes can lose that, and shuffle passes rarely retrace the specific path
// that would have found it. So: monotonic WITHIN a diversity run, not >= Off at equal budget.
// Phase plans below are exactly the ones measured (see CHANGELOG): fractions of the budget.
// helper: build a {divstatic frac} + N even shuffle passes plan, e.g. mkPlan(.5,4) ==
// mode 3's plan (50% divstatic + 4x12.5% shuffles). Used for the multi6/8/16 and aggrNN_4
// variants below so the fraction math can't drift out of sync with the label.
function ubDComponent(candList, positions, need){
  const groupOf=c=>c.hold||('C'+c.id);
  const groups={};
  for(const c of candList){
    const g=groupOf(c);
    if(!groups[g]) groups[g]={eligPos:new Set(), bestRating:-Infinity};
    for(const p of c.pos){
      if(positions.includes(p)){
        groups[g].eligPos.add(p);
        if(c.rating>groups[g].bestRating) groups[g].bestRating=c.rating;
      }
    }
  }
  const groupIds=Object.keys(groups)
    .filter(g=>groups[g].eligPos.size>0)
    .sort((a,b)=>groups[b].bestRating-groups[a].bestRating); // greedy processes highest weight first

  const posAssignments={}; for(const p of positions) posAssignments[p]=[];

  // Kuhn's-algorithm augmenting-path search: try to place `gid`, bumping/re-routing an existing
  // occupant to a different eligible position if that's what it takes to make room.
  function tryAugment(gid, visitedPos){
    for(const p of groups[gid].eligPos){
      if(visitedPos.has(p)) continue;
      visitedPos.add(p);
      if(posAssignments[p].length<need[p]){
        posAssignments[p].push(gid);
        return true;
      }
      for(let k=0;k<posAssignments[p].length;k++){
        const other=posAssignments[p][k];
        if(tryAugment(other, visitedPos)){
          posAssignments[p][k]=gid;
          return true;
        }
      }
    }
    return false;
  }

  const K=positions.reduce((s,p)=>s+need[p],0);
  const chosen=[];
  let matched=0;
  for(const gid of groupIds){
    if(tryAugment(gid, new Set())){
      matched++;
      chosen.push(groups[gid].bestRating);
      if(matched===K) break;
    }
  }
  if(matched<K) return {feasible:false};
  return {feasible:true, chosen};
}
// ============================================================================================
// UB-E CANNOT BE TIGHTENED FURTHER (documented v10.1.0.2, no logic change — this is a record of
// two failed follow-up attempts, kept here so nobody re-tries the same fix without knowing why it
// doesn't work). Neither attempt below is present in this file; this is a write-up of dead ends.
//
// THE ITCH: UB-E still credits a hold-group's contribution using its GLOBAL best rating (best
// rating among ANY member, at ANY eligible position), regardless of which specific position the
// matching actually assigns that group to. Concretely: hold group H has card A (rating 99,
// eligible ONLY for GK) and card B (rating 60, eligible ONLY for RW). If the matching assigns H's
// "slot" to RW (because some other group needed GK more), UB-E still credits 99 there, even though
// no real card could contribute 99 at RW. Feels like obvious slack to remove.
//
// ATTEMPT 1 ("UB-F"): keep UB-E's exact matching/placement decisions (unchanged — proven correct
// for FEASIBILITY), but once the matching stabilizes, credit each group at its FINAL assigned
// position using posBest[group][thatPosition] (best rating among ONLY the members actually
// eligible there) instead of the group's unconstrained global best.
// ATTEMPT 2 ("UB-G"): a genuinely from-scratch construction (not a patch on the UB-D/E lineage) —
// ground set = (hold-group, position) EDGES, each with its own honest position-specific weight, no
// group-level union-of-positions at all; greedily take edges in descending weight order subject to
// position capacity and one-edge-per-group.
//
// BOTH ARE UNSOUND. Fuzz-tested against the brute-force oracle (same harness used for UB-E's own
// v9.5.0 verification, extended with adversarial cross-component / shared-hold / extreme-spread
// generators): UB-F produced 862–876 violations per ~12,000 comparable trials across repeated
// runs; UB-G produced 963 violations per 11,020. Both undercounted the true max on REAL generated
// drafts, not just contrived inputs — this is a critical-class bug for either one, so neither was
// merged.
//
// WHY, NOT JUST THAT: this isn't a bug in the implementations that a smarter version could route
// around — position-specific (or edge-specific) crediting is fundamentally incompatible with the
// domination guarantee this whole file relies on, given futRatingRaw's shape. Concrete
// counterexample, using ratings in the app's normal 60-99 range:
//   Formation needs one GK and one RW.
//   Group 1 (one hold): card A, rating 100(*), eligible ONLY for GK. Card B, rating 90, eligible
//     ONLY for RW.
//   Group 2 (different hold): card C, rating 95, eligible ONLY for GK. Card D, rating 85, eligible
//     ONLY for RW.
//   (*ratings shown slightly outside 60-99 for round numbers; the same shape reproduces inside
//   60-99, e.g. 99/85/94/80 — the point is the CROSSING pattern, not the exact values.)
//   Only two real legal XIs exist: [A,D] = sorted [100,85], futRatingRaw = 96.25. Or
//   [C,B] = sorted [95,90], futRatingRaw = 93.75.
//   Neither sorted vector element-wise dominates the other: 100>95 but 85<90. So a method that
//   credits group 1 at "wherever it actually lands" gets EITHER [100,?] or [?,90] depending on
//   which position it's assigned — and if it happens to land group 1 at RW (crediting 90) while the
//   TRUE best actually needed group 1 at GK (crediting 100) and group 2 filling RW with D (85), the
//   position-specific method has no way to recover the 100 it left on the table: it only tracked
//   "group 1's value at RW", never "group 1's value at GK", because it discarded the global best in
//   favour of the position-specific one. Concretely this is where UB-F/UB-G's undercounts come
//   from: they lock in a value tied to a placement decision that turned out to be the wrong one to
//   have committed to, for THIS instance's actual numbers.
//   The only credit that's safe regardless of which of the two real XIs is the "true" one is the
//   group's UNCONSTRAINED best rating (100 for group 1, 95 for group 2) — i.e. exactly UB-E's
//   existing rule. Crediting anything tighter is, in the general case, a bet on which position a
//   group's best card will end up needing, and futRatingRaw's mean+spread-above-mean shape (which
//   over-weights the top value relative to a plain average, same reason raw sum-maximisation was
//   already rejected for UB-D — see the long comment above maxPossibleRating()) means that bet can
//   lose in either direction depending on the specific numbers involved. Also checked lexicographic-
//   max crediting (favour whichever real option has the single highest top value) as a possible
//   safe alternative — it isn't: [99,60] is lexicographically greater than [98,98] (99>98) but
//   scores LOWER under futRatingRaw (89.25 vs 98), so "pick the lex-greater option" is not a safe
//   proxy for "pick the futRatingRaw-greater option" either.
//
// CONCLUSION: UB-E is very likely at the practical ceiling for the matroid-greedy-domination
// technique this whole file uses, given futRatingRaw's specific scoring shape. Getting tighter than
// this would need a genuinely different kind of relaxation (e.g. bounding the mean and the
// spread-above-mean terms separately, rather than building one credited N-length vector and hoping
// it dominates) — not a smarter matching/weighting scheme layered on the same one. Not attempted
// here; flagging as the honest next lead if this is ever revisited, not a recommendation to build
// it blindly — anything new in this space still needs the same brute-force fuzz gauntlet before it
// goes near maxPossibleRating().
// ============================================================================================
// UB-E helper (added v9.5.0, safe to delete along with the "UB-E:" block in maxPossibleRating()
// if this method is ever found to be wrong — UB-A/B/C/D do not depend on it): identical algorithm
// to ubDComponent() (matroid-greedy + Kuhn's-algorithm augmenting-path placement), but run as ONE
// global problem over every eligible position in the formation instead of one component at a
// time — see the long "UB-E" comment above maxPossibleRating() for why this only ever tightens
// (never loosens) the bound relative to UB-D's per-component version.
function ubEGlobal(elig, slots, need){
  const groupOf=c=>c.hold||('C'+c.id);
  const positions=Object.keys(need);
  const groups={};
  for(const c of elig){
    const g=groupOf(c);
    if(!groups[g]) groups[g]={eligPos:new Set(), bestRating:-Infinity};
    for(const p of c.pos){
      if(need[p]!==undefined){
        groups[g].eligPos.add(p);
        if(c.rating>groups[g].bestRating) groups[g].bestRating=c.rating;
      }
    }
  }
  const groupIds=Object.keys(groups)
    .filter(g=>groups[g].eligPos.size>0)
    .sort((a,b)=>groups[b].bestRating-groups[a].bestRating);

  const posAssignments={}; for(const p of positions) posAssignments[p]=[];
  function tryAugment(gid, visitedPos){
    for(const p of groups[gid].eligPos){
      if(visitedPos.has(p)) continue;
      visitedPos.add(p);
      if(posAssignments[p].length<need[p]){
        posAssignments[p].push(gid);
        return true;
      }
      for(let k=0;k<posAssignments[p].length;k++){
        const other=posAssignments[p][k];
        if(tryAugment(other, visitedPos)){
          posAssignments[p][k]=gid;
          return true;
        }
      }
    }
    return false;
  }

  const N=slots.length;
  const chosen=[];
  let matched=0;
  for(const gid of groupIds){
    if(tryAugment(gid, new Set())){
      matched++;
      chosen.push(groups[gid].bestRating);
      if(matched===N) break;
    }
  }
  if(matched<N) return {feasible:false};
  return {feasible:true, chosen};
}
// UB-H2 helper 1/3 (added v10.3, safe to delete along with the "UB-H2:" block in
// maxPossibleRating() below if this method is ever found to be wrong -- UB-A/B/C/D/E do not depend
// on it): plain min-cost-max-flow over a small layered graph (SOURCE -> hold-groups -> positions ->
// SINK), used to find the EXACT maximum possible SUM of ratings over any real legal XI. This is a
// different objective from every UB-A..E matching (which chase futRatingRaw's mean+spread shape via
// domination) -- raw sum has no domination trap, so solving it exactly here is safe. Bellman-Ford
// shortest-path augmentation; the graph is small (hold-groups + positions + 2), so this is fast.
function minCostMaxFlow(numNodes, source, sink, edges, targetFlow){
  const graph = Array.from({length:numNodes}, ()=>[]);
  const edgeList = [];
  function addEdge(u,v,cap,cost){
    edgeList.push({u,v,cap,cost,flow:0});
    edgeList.push({u:v,v:u,cap:0,cost:-cost,flow:0});
    graph[u].push(edgeList.length-2);
    graph[v].push(edgeList.length-1);
  }
  for(const e of edges) addEdge(e.u,e.v,e.cap,e.cost);

  let totalFlow=0, totalCost=0;
  while(totalFlow<targetFlow){
    const dist = new Array(numNodes).fill(Infinity);
    const inQueue = new Array(numNodes).fill(false);
    const prevEdge = new Array(numNodes).fill(-1);
    dist[source]=0;
    const queue=[source]; inQueue[source]=true;
    let head=0, iterations=0;
    const maxIter = numNodes*numNodes*4+50;
    while(head<queue.length && iterations<maxIter){
      iterations++;
      const u=queue[head++]; inQueue[u]=false;
      for(const ei of graph[u]){
        const e=edgeList[ei];
        if(e.cap-e.flow<=0) continue;
        if(dist[u]+e.cost < dist[e.v]-1e-9){
          dist[e.v]=dist[u]+e.cost;
          prevEdge[e.v]=ei;
          if(!inQueue[e.v]){ queue.push(e.v); inQueue[e.v]=true; }
        }
      }
    }
    if(dist[sink]===Infinity) break; // no more augmenting paths
    let bottleneck=targetFlow-totalFlow;
    let v=sink;
    while(v!==source){
      const ei=prevEdge[v];
      const e=edgeList[ei];
      bottleneck=Math.min(bottleneck, e.cap-e.flow);
      v=e.u;
    }
    v=sink;
    while(v!==source){
      const ei=prevEdge[v];
      edgeList[ei].flow+=bottleneck;
      edgeList[ei^1].flow-=bottleneck;
      totalCost += edgeList[ei].cost*bottleneck;
      v=edgeList[ei].u;
    }
    totalFlow+=bottleneck;
  }
  return {flow:totalFlow, cost:totalCost};
}

// UB-H2 helper 2/3 (added v10.3): exact max of sp(x)=sum(max(0,x_i-mean(x))) over
// {L_i<=x_i<=U_i for each i} intersected with {sum(x)<=Smax}. sp is convex, so its max over this
// bounded box-plus-one-hyperplane region is attained at a vertex, and every such vertex has at
// most one coordinate not pinned to its own L_i/U_i bound. Enumerates both vertex families (pure
// box vertices, and one-flex-coordinate vertices forced by the sum constraint) and returns the
// best feasible one -- this is an EXACT computation of the max over the relaxed region, not a
// further relaxation. See the v10.3 CHANGELOG entry for the full soundness argument.
function spMaxBoundPerSlot(bounds, Smax){
  const N = bounds.length;
  const EPS = 1e-9;
  function spOf(vals){
    const S=vals.reduce((a,b)=>a+b,0), A=S/vals.length;
    let sp=0; for(const v of vals) if(v>A) sp+=v-A;
    return sp;
  }
  let best = -Infinity;

  const total = 1<<N;
  for(let mask=0; mask<total; mask++){
    const vals = new Array(N);
    let s = 0;
    for(let i=0;i<N;i++){
      const v = (mask & (1<<i)) ? bounds[i].U : bounds[i].L;
      vals[i] = v; s += v;
    }
    if(s <= Smax + EPS){
      const sp = spOf(vals);
      if(sp > best) best = sp;
    }
  }

  for(let flex=0; flex<N; flex++){
    const others = [];
    for(let i=0;i<N;i++) if(i!==flex) others.push(i);
    const M = others.length;
    const subTotal = 1<<M;
    for(let mask=0; mask<subTotal; mask++){
      const vals = new Array(N);
      let sumOthers = 0;
      for(let k=0;k<M;k++){
        const i = others[k];
        const v = (mask & (1<<k)) ? bounds[i].U : bounds[i].L;
        vals[i] = v; sumOthers += v;
      }
      let v = Smax - sumOthers;
      if(v < bounds[flex].L) v = bounds[flex].L;
      if(v > bounds[flex].U) v = bounds[flex].U;
      vals[flex] = v;
      const sp = spOf(vals);
      if(sp > best) best = sp;
    }
  }
  return best;
}

// UB-H2 helper 3/3 (added v10.3, safe to delete along with the "UB-H2:" block in
// maxPossibleRating() below if this method is ever found to be wrong): computes S_max (exact, via
// minCostMaxFlow) and sp_max (via spMaxBoundPerSlot, using PER-SLOT [L,U] -- best/worst rating
// among cards eligible for each individual slot's own position, not one global range shared by
// every slot) and returns (S_max+sp_max)/N, a valid upper bound on futRatingRaw for any real legal
// XI. Returns null if no legal XI exists (consistent with UB-A..E's own opt-out convention).
function ubH2Bound(elig, slots, need){
  const N = slots.length;
  const positions = Object.keys(need);
  const groupOf = c=>c.hold||('C'+c.id);

  const posBest={};
  const posLmin={}, posUmax={};
  for(const c of elig){
    const g=groupOf(c);
    if(!posBest[g]) posBest[g]={};
    for(const p of c.pos){
      if(need[p]!==undefined){
        if(posBest[g][p]===undefined || c.rating>posBest[g][p]) posBest[g][p]=c.rating;
        if(posLmin[p]===undefined || c.rating<posLmin[p]) posLmin[p]=c.rating;
        if(posUmax[p]===undefined || c.rating>posUmax[p]) posUmax[p]=c.rating;
      }
    }
  }
  const groupIds=Object.keys(posBest);

  const G=groupIds.length, P=positions.length;
  const SOURCE=0, groupBase=1, posBase=1+G, SINK=1+G+P;
  const numNodes=SINK+1;
  const edges=[];
  for(let gi=0; gi<G; gi++) edges.push({u:SOURCE, v:groupBase+gi, cap:1, cost:0});
  for(let gi=0; gi<G; gi++){
    const g=groupIds[gi];
    for(let pi=0; pi<P; pi++){
      const p=positions[pi];
      if(posBest[g][p]!==undefined) edges.push({u:groupBase+gi, v:posBase+pi, cap:1, cost:-posBest[g][p]});
    }
  }
  for(let pi=0; pi<P; pi++) edges.push({u:posBase+pi, v:SINK, cap:need[positions[pi]], cost:0});

  const {flow, cost} = minCostMaxFlow(numNodes, SOURCE, SINK, edges, N);
  if(flow<N) return null;

  const Smax = -cost;
  const bounds = slots.map(p => ({L: posLmin[p], U: posUmax[p]}));
  const spMax = spMaxBoundPerSlot(bounds, Smax);
  return (Smax + spMax)/N;
}
function maxPossibleRating(pool,form){
  if(!pool||!pool.length||!form)return null;
  const slots=form.slots,slotSet=new Set(slots),N=slots.length;
  const groupOf=c=>c.hold||('C'+c.id);
  const elig=pool.filter(c=>c.pos&&c.pos.some(p=>slotSet.has(p))); // a card that fits no slot can never be in an XI
  const ubs=[];
  // UB-A: hold-collapsed, position-relaxed top-11
  {
    const byGroup={};
    for(const c of elig){const g=groupOf(c);if(byGroup[g]===undefined||c.rating>byGroup[g])byGroup[g]=c.rating;}
    const rs=Object.keys(byGroup).map(k=>byGroup[k]).sort((a,b)=>b-a);
    if(rs.length>=N)ubs.push(futRatingRaw(rs.slice(0,N)));
  }
  // UB-B: per-position head-count, hold-distinct within the position
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const chosen=[];let feasible=true;
    for(const pos in need){
      const k=need[pos];
      const cand=elig.filter(c=>c.pos.includes(pos)).sort((a,b)=>b.rating-a.rating);
      const seen=new Set(),top=[];
      for(const c of cand){const g=groupOf(c);if(seen.has(g))continue;seen.add(g);top.push(c.rating);if(top.length===k)break;}
      if(top.length<k){feasible=false;break;} // too few distinct-hold cards for this position -> skip method
      for(const r of top)chosen.push(r);
    }
    if(feasible&&chosen.length===N)ubs.push(futRatingRaw(chosen));
  }
  // UB-C: position-adjacency components — union any two formation positions that share a real
  // eligible card in the pool (transitively, via union-find), then treat each resulting component
  // as ONE shared hold-distinct bucket (headcount = sum of its positions' needs). An LB/LM/LW card
  // unions those three positions into one bucket and can only be picked ONCE within it, fixing
  // UB-B's per-position double-count for versatile cards, while GK (which normally shares no
  // eligible card with any outfield position) still splits into its own singleton component instead
  // of "borrowing" bound from a stacked outfield position the way UB-A's single global bucket does.
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const posArr=Object.keys(need);
    const parent={};posArr.forEach(p=>parent[p]=p);
    const find=x=>{while(parent[x]!==x){parent[x]=parent[parent[x]];x=parent[x];}return x;};
    const union=(a,b)=>{const ra=find(a),rb=find(b);if(ra!==rb)parent[ra]=rb;};
    for(const c of elig){
      const rel=c.pos.filter(p=>need[p]!==undefined); // this card's positions that are actually needed by the formation
      for(let i=1;i<rel.length;i++)union(rel[0],rel[i]); // any card eligible for 2+ needed positions links them into one component
    }
    const comps={};
    for(const p of posArr){const r=find(p);(comps[r]=comps[r]||[]).push(p);}
    let feasible=true;const chosen=[];
    for(const r in comps){
      const compPos=new Set(comps[r]);
      const k=comps[r].reduce((s,p)=>s+need[p],0);
      const cand=elig.filter(c=>c.pos.some(p=>compPos.has(p))).sort((a,b)=>b.rating-a.rating);
      const seen=new Set(),top=[];
      for(const c of cand){const g=groupOf(c);if(seen.has(g))continue;seen.add(g);top.push(c.rating);if(top.length===k)break;}
      if(top.length<k){feasible=false;break;} // too few distinct-hold cards for this component -> skip method
      for(const rr of top)chosen.push(rr);
    }
    if(feasible&&chosen.length===N)ubs.push(futRatingRaw(chosen));
  }
  // UB-D: same components as UB-C, but each component's exact per-position capacity is verified
  // via matroid-greedy + augmenting-path placement instead of UB-C's "aggregate headcount only"
  // check — never looser than UB-C, sometimes strictly tighter. See ubDComponent() and the long
  // comment above this function for why this must NOT be a sum-maximising matching.
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const posArr=Object.keys(need);
    const parent={};posArr.forEach(p=>parent[p]=p);
    const find=x=>{while(parent[x]!==x){parent[x]=parent[parent[x]];x=parent[x];}return x;};
    const union=(a,b)=>{const ra=find(a),rb=find(b);if(ra!==rb)parent[ra]=rb;};
    for(const c of elig){
      const rel=c.pos.filter(p=>need[p]!==undefined);
      for(let i=1;i<rel.length;i++)union(rel[0],rel[i]);
    }
    const comps={};
    for(const p of posArr){const r=find(p);(comps[r]=comps[r]||[]).push(p);}
    let feasible=true;const chosen=[];
    for(const r in comps){
      const compPos=new Set(comps[r]);
      const candList=elig.filter(c=>c.pos.some(p=>compPos.has(p)));
      const result=ubDComponent(candList, comps[r], need);
      if(!result.feasible){feasible=false;break;}
      for(const rr of result.chosen)chosen.push(rr);
    }
    if(feasible&&chosen.length===N)ubs.push(futRatingRaw(chosen));
  }
  // UB-E: same matroid-greedy + augmenting-path placement as UB-D, but as ONE global problem over
  // every eligible position in the formation instead of splitting into components first — a
  // hold-group can only be placed (and credited) once overall, closing UB-D's narrower "once per
  // component" leak. Independently valid, but does NOT dominate UB-D (corrected v10.3.0.1 — neither
  // method dominates the other; kept side by side in the min() on equal footing). See ubEGlobal()
  // and the long "UB-E" comment above this function for the full argument and counterexample.
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const result=ubEGlobal(elig, slots, need);
    if(result.feasible && result.chosen.length===N)ubs.push(futRatingRaw(result.chosen));
  }
  // UB-H2: a genuinely different relaxation from A-E's matroid-greedy-domination family (see the
  // v10.3 CHANGELOG entry and the "UB-H2 helper" comments above ubH2Bound() for the full
  // soundness argument) — bounds futRatingRaw's sum and spread-above-mean terms SEPARATELY
  // instead of building one credited vector and hoping it dominates the true winner, so it isn't
  // subject to the UB-F/UB-G counterexample. Never proven to dominate A-E in every case (or vice
  // versa), so it's combined via min() rather than replacing them.
  {
    const need={};for(const s of slots)need[s]=(need[s]||0)+1;
    const h2=ubH2Bound(elig, slots, need);
    if(h2!==null)ubs.push(h2);
  }
  if(!ubs.length)return null;
  return Math.floor(Math.min(...ubs)); // min of valid upper bounds is still valid, and tightest
}function _rcCeilWarnHTML(ub,rc,xiCapped){
  // ub = maxPossibleRating(): a guaranteed upper bound on any legal squad's rating. Because ub >= the
  // true max legal rating M, RC vs ub decides soundness outright: RC >= ub  ==>  RC >= M  ==>  the
  // rating cap never pruned a real squad. Three states, all provable (not "likely"):
  //   RC <  ub : RC may be too low -> a better-rated squad could have been pruned. RED. Recommend RC=ub.
  //   RC == ub : RC is exactly the smallest ceiling that prunes nothing real. GREEN. Provably optimal.
  //   RC >  ub : sound (guaranteed optimal). Silent when the search finished; if it was node-capped,
  //              AMBER -> the useful move isn't "search deeper", it's LOWER RC to ub to prune harder.
  if(typeof ub!=='number'||typeof rc!=='number'||ub<0)return '';
  const capNote=xiCapped?'<div class="tiny" style="margin-top:4px">\u26a0 The XI search itself was capped at its node budget \u2014 finish a full, uncapped search (\u201csearch to the end\u201d) before treating this as final.</div>':'';
  if(rc<ub){
    return '<div class="note" style="border-color:var(--bad);margin-bottom:10px"><b>\u26a0 Rating Ceiling may be too low</b> \u2014 a legal squad on this draft can rate as high as '+ub+', which is '+(ub-rc)+' above your RC of '+rc+'. Pruning at this RC may have missed better solutions. Set RC to '+ub+' for a guaranteed-optimal search.</div>';
  }
  if(rc===ub){
    return '<div class="note" style="border-color:var(--good);margin-bottom:10px"><b>\u2713 Rating Ceiling is exactly optimal</b> \u2014 no legal squad on this draft can rate above '+ub+', so this RC prunes nothing real. It\u2019s the fastest ceiling that still guarantees the best solution'+(xiCapped?' once the search finishes.':'.')+capNote+'</div>';
  }
  // rc > ub : provably sound. Only worth a word if capped (nudge to lower RC instead of searching on).
  if(xiCapped){
    const lower=Math.max(75,ub); // slider floor, not the old 85 -- widened in v10.1
    return '<div class="note" style="border-color:var(--warn);margin-bottom:10px"><b>\u26a0 Rating Ceiling higher than needed</b> \u2014 no legal squad here can rate above '+ub+', below your RC of '+rc+'. Rather than search deeper at this RC, lower RC to '+lower+': it prunes harder and can finish faster, still guaranteed-optimal.</div>';
  }
  return ''; // rc > ub and the search completed uncapped: provably optimal, nothing to flag
}
module.exports = { scoreXI, solveBest, maxPossibleRating };
