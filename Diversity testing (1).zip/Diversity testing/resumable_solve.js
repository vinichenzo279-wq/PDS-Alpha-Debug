'use strict';
const { leagueOf, scoreXI } = require('./engine.js');

// Same cand[]/order[]/UB-table construction as buildSolver in solvers.js, but the traversal is
// an explicit-stack iterative DFS instead of recursion, so it can pause after a node budget and
// hand back a checkpoint (JSON-serializable) that a LATER process invocation can load and
// continue from -- byte-identical to what an uninterrupted run would have done, since the whole
// state (usedGroups/seenNat/seenLg/seenClub/partialIcon/partialHero) is fully determined by the
// sequence of chosen candidate-list-indices down from the root, so we only need to serialize that
// index path (plus best/bestXIs/nodes/maxRating) and replay it to rebuild everything else.
function buildResumableSolver(opts){
  const presortFn = opts.presortFn;

  return function solve(form, cards, ratingCeil, nodeBudget, checkpoint, hardCap){
    const RC = ratingCeil !== undefined ? ratingCeil : 99;
    const slots = form.slots;
    let cand = slots.map(s=>cards.filter(c=>c.pos.includes(s)));
    cand = cand.map(list=>presortFn(list, cards, form));
    if(cand.some(l=>l.length===0))
      return {error:'A slot has no eligible card: '+slots.filter((s,i)=>cand[i].length===0).join(', ')};
    for(const slot of cand)for(const c of slot){
      if(c._lg===undefined)c._lg=leagueOf(c);
      if(c._group===undefined)c._group=c.hold||('C'+c.id);
    }
    const order=slots.map((s,i)=>i).sort((a,b)=>cand[a].length-cand[b].length);
    const slotTypes=cand.map(list=>{const s=new Set();for(const c of list)s.add(c.type);return s;});
    const N=slots.length;
    const ubBaseline=new Array(N),ubSuffixBase=new Array(N+1).fill(0);
    const ubTopIconV=new Array(N+1),ubTopIconI=new Array(N+1),ubTopIconV2=new Array(N+1),ubTopIconI2=new Array(N+1);
    const ubTopHeroV=new Array(N+1),ubTopHeroI=new Array(N+1),ubTopHeroV2=new Array(N+1),ubTopHeroI2=new Array(N+1);
    ubTopIconV[N]=-Infinity;ubTopIconI[N]=-1;ubTopIconV2[N]=-Infinity;ubTopIconI2[N]=-1;
    ubTopHeroV[N]=-Infinity;ubTopHeroI[N]=-1;ubTopHeroV2[N]=-Infinity;ubTopHeroI2[N]=-1;
    for(let k=N-1;k>=0;k--){
      const st=slotTypes[order[k]];
      let b=-Infinity;
      if(st.has('normal'))b=2;
      if(st.has('hero')&&b<2)b=2;
      if(st.has('icon')&&b<1)b=1;
      ubBaseline[k]=b;ubSuffixBase[k]=ubSuffixBase[k+1]+b;
      let iv=ubTopIconV[k+1],ii=ubTopIconI[k+1],iv2=ubTopIconV2[k+1],ii2=ubTopIconI2[k+1];
      if(st.has('icon')){const g=3-b;if(g>iv){iv2=iv;ii2=ii;iv=g;ii=k;}else if(g>iv2){iv2=g;ii2=k;}}
      ubTopIconV[k]=iv;ubTopIconI[k]=ii;ubTopIconV2[k]=iv2;ubTopIconI2[k]=ii2;
      let hv=ubTopHeroV[k+1],hi=ubTopHeroI[k+1],hv2=ubTopHeroV2[k+1],hi2=ubTopHeroI2[k+1];
      if(st.has('hero')){const g=3-b;if(g>hv){hv2=hv;hi2=hi;hv=g;hi=k;}else if(g>hv2){hv2=g;hi2=k;}}
      ubTopHeroV[k]=hv;ubTopHeroI[k]=hi;ubTopHeroV2[k]=hv2;ubTopHeroI2[k]=hi2;
    }

    function computeUB(k){
      const premUnseen=seenLg.has('England Premier League')?0:1;
      const total0=ubSuffixBase[k];
      let bonusGain;
      if(partialIcon&&partialHero){bonusGain=0;}
      else{
        const ic0v=partialIcon?0:(ubTopIconV[k]>0?ubTopIconV[k]:0),ic0i=partialIcon?-1:ubTopIconI[k];
        const he0v=partialHero?0:(ubTopHeroV[k]>0?ubTopHeroV[k]:0),he0i=partialHero?-1:ubTopHeroI[k];
        let orderA=ic0v;
        if(!partialHero){ if(he0i!==ic0i)orderA+=he0v; else orderA+=(ubTopHeroV2[k]>0?ubTopHeroV2[k]:0); }
        let orderB=he0v;
        if(!partialIcon){ if(ic0i!==he0i)orderB+=ic0v; else orderB+=(ubTopIconV2[k]>0?ubTopIconV2[k]:0); }
        bonusGain=Math.max(orderA,orderB);
      }
      return RC+33+seenNat.size+seenLg.size+seenClub.size+partialIcon+partialHero+total0+bonusGain+premUnseen;
    }

    const usedGroups=new Set(), seenNat=new Set(), seenLg=new Set(), seenClub=new Set();
    let partialIcon=0, partialHero=0;
    const pick=new Array(N).fill(null);

    function applyPick(c){
      const g=c._group;
      usedGroups.add(g);
      const addNat=!seenNat.has(c.nation); if(addNat)seenNat.add(c.nation);
      const addLg=!seenLg.has(c._lg); if(addLg)seenLg.add(c._lg);
      const addClub=c.type==='normal'&&!seenClub.has(c.club); if(addClub)seenClub.add(c.club);
      const addIcon=!partialIcon&&c.type==='icon'; if(addIcon)partialIcon=1;
      const addHero=!partialHero&&c.type==='hero'; if(addHero)partialHero=1;
      return {g,addNat,addLg,addClub,addIcon,addHero};
    }
    function undoPick(applied, slotIdx, c){
      if(applied.addNat) seenNat.delete(c.nation);
      if(applied.addLg) seenLg.delete(c._lg);
      if(applied.addClub) seenClub.delete(c.club);
      if(applied.addIcon) partialIcon=0;
      if(applied.addHero) partialHero=0;
      usedGroups.delete(applied.g);
      pick[slotIdx]=null;
    }

    let best, bestXIs, nodes, maxRating;
    function evaluateLeaf(){
      const xi=pick.slice(), sc=scoreXI(xi);
      if(sc.rating>maxRating)maxRating=sc.rating;
      if(sc.total>best){ best=sc.total; bestXIs=[{xi,sc}]; }
      else if(sc.total===best && bestXIs.length<5){ bestXIs.push({xi,sc}); }
    }

    let stack=[];
    if(checkpoint && checkpoint.path.length===0){
      best=checkpoint.best; bestXIs=checkpoint.bestXIs||[]; nodes=checkpoint.nodes||0; maxRating=checkpoint.maxRating!==undefined?checkpoint.maxRating:-1;
      stack.push({k:0, slotIdx:order[0], list:cand[order[0]], i:-1, ub:undefined, applied:null, c:null});
      nodes++;
    } else if(checkpoint){
      best=checkpoint.best; bestXIs=checkpoint.bestXIs||[]; nodes=checkpoint.nodes; maxRating=checkpoint.maxRating;
      const path=checkpoint.path;
      for(let lvl=0; lvl<path.length-1; lvl++){
        const slotIdx=order[lvl], idx=path[lvl];
        const c=cand[slotIdx][idx];
        const applied=applyPick(c);
        pick[slotIdx]=c;
        stack.push({k:lvl, slotIdx, list:cand[slotIdx], i:idx, ub:undefined, applied, c});
      }
      const lastLvl=path.length-1;
      stack.push({k:lastLvl, slotIdx:order[lastLvl], list:cand[order[lastLvl]], i:path[lastLvl], ub:undefined, applied:null, c:null});
    } else {
      best=-1; bestXIs=[]; nodes=0; maxRating=-1;
      stack.push({k:0, slotIdx:order[0], list:cand[order[0]], i:-1, ub:undefined, applied:null, c:null});
      nodes++; // entering dfs(0)
    }

    const startNodes = nodes;
    let capped=false;

    while(stack.length){
      if(hardCap && nodes>=hardCap){ capped=true; break; }
      if(nodes - startNodes >= nodeBudget){ break; } // pause point for this invocation
      const frame = stack[stack.length-1];
      const k = frame.k;
      if(frame.ub===undefined){
        frame.ub = (best>=0) ? computeUB(k) : -Infinity;
        if(best>=0 && frame.ub<best){
          stack.pop();
          if(stack.length){
            const parent=stack[stack.length-1];
            undoPick(parent.applied, parent.slotIdx, parent.c);
            parent.applied=null; parent.c=null;
          }
          continue;
        }
      }
      frame.i++;
      if(frame.i >= frame.list.length){
        stack.pop();
        if(stack.length){
          const parent=stack[stack.length-1];
          undoPick(parent.applied, parent.slotIdx, parent.c);
          parent.applied=null; parent.c=null;
        }
        continue;
      }
      const c = frame.list[frame.i];
      if(usedGroups.has(c._group)) continue;

      const applied = applyPick(c);
      pick[frame.slotIdx]=c;
      frame.applied=applied; frame.c=c;

      const nk = k+1;
      nodes++;
      if(hardCap && nodes>=hardCap){
        capped=true;
        // this node itself still counts and should still be evaluated/pushed before we stop;
        // but to keep it simple we just stop right here (matches recursive: nodes++ then cap check
        // happens BEFORE the leaf/internal branch, so this call never gets evaluated). Undo it.
        undoPick(applied, frame.slotIdx, c);
        frame.applied=null; frame.c=null;
        break;
      }
      if(nk===N){
        evaluateLeaf();
        undoPick(applied, frame.slotIdx, c);
        frame.applied=null; frame.c=null;
        continue;
      } else {
        stack.push({k:nk, slotIdx:order[nk], list:cand[order[nk]], i:-1, ub:undefined, applied:null, c:null});
        continue;
      }
    }

    const done = stack.length===0 && !capped;
    let checkpointOut=null;
    if(!done){
      checkpointOut = { path: stack.map(f=>f.i), best, bestXIs, nodes, maxRating };
    }
    return {best, bestXIs, nodes, maxRating, capped, done, checkpoint: checkpointOut};
  };
}

module.exports = { buildResumableSolver };
