'use strict';
// node run_hybrid.js <seed> <phase1Budget> <totalBudget> [minBust maxBust minPer maxPer]
const { generateDraft } = require('./gendraft.js');
const { maxPossibleRating } = require('./engine.js');
const { buildResumableSolver } = require('./resumable_solver.js');

function mulberry32(seed){
  return function(){
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const divstaticSort = (list)=>{
  const natCount={}, clubCount={};
  for(const c of list){
    natCount[c.nation]=(natCount[c.nation]||0)+1;
    if(c.type==='normal') clubCount[c.club]=(clubCount[c.club]||0)+1;
  }
  return list.map(c=>{
    const natRarity = 1/(natCount[c.nation]||1);
    const clubRarity = c.type==='normal' ? 1/(clubCount[c.club]||1) : 0;
    return {c, score: c.rating + 0.4*natRarity + 0.4*clubRarity};
  }).sort((a,b)=>b.score-a.score).map(x=>x.c);
};
function pseudoRandomSort(seed){
  const rand = mulberry32(seed);
  return (list)=>{
    const a = list.slice();
    for(let i=a.length-1;i>0;i--){ const j=Math.floor(rand()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; }
    return a;
  };
}

const seed = parseInt(process.argv[2], 10);
const phase1Budget = parseInt(process.argv[3], 10);
const totalBudget = parseInt(process.argv[4], 10);
const minBust = parseInt(process.argv[5] || '0', 10), maxBust = parseInt(process.argv[6] || '0', 10);
const minPer = parseInt(process.argv[7] || '4', 10), maxPer = parseInt(process.argv[8] || '6', 10);

const d = generateDraft({seed, minBust, maxBust, minPer, maxPer});
let rc; try{ rc = maxPossibleRating(d.cards, d.subForm); }catch(e){ rc = 96; }
if(rc === null) rc = 96;

console.log(`seed=${seed} form=${d.formName} rc=${rc}`);

// PHASE 1: divstatic, run to completion or until phase1Budget nodes
const solveDiv = buildResumableSolver({ presortFn: divstaticSort });
const t0 = Date.now();
const p1 = solveDiv(d.subForm, d.cards, rc, phase1Budget, null, phase1Budget);
console.log(`[phase1 divstatic] nodes=${p1.nodes} best=${p1.best} done=${p1.done} ms=${Date.now()-t0}`);

if(p1.done){
  console.log(`Phase 1 already exhausted the tree -- no phase 2 needed. Proven best=${p1.best}, total nodes=${p1.nodes}`);
  process.exit(0);
}

// PHASE 2: pseudo-random, FRESH traversal from the root (path:[]), seeded with phase 1's incumbent
const solveRand = buildResumableSolver({ presortFn: pseudoRandomSort(seed*2654435761) });
const seedCheckpoint = { path: [], best: p1.best, bestXIs: p1.bestXIs, nodes: 0, maxRating: p1.maxRating };
const phase2Budget = totalBudget - p1.nodes;
const t1 = Date.now();
const p2 = solveRand(d.subForm, d.cards, rc, phase2Budget, seedCheckpoint, phase2Budget);
console.log(`[phase2 pseudorandom, seeded] nodes=${p2.nodes} best=${p2.best} done=${p2.done} ms=${Date.now()-t1}`);

const totalNodes = p1.nodes + p2.nodes;
console.log(`HYBRID RESULT: seed=${seed} finalBest=${p2.best} totalNodes=${totalNodes} (phase1=${p1.nodes}, phase2=${p2.nodes})`);
