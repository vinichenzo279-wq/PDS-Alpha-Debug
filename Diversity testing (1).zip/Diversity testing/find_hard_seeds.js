'use strict';
const { generateDraft, estimateCombos } = require('./gendraft.js');
const { maxPossibleRating } = require('./engine.js');
const { MODES, runMode } = require('./diversity_harness.js');

const CAP = parseInt(process.argv[2]||'3000000',10);
const N_WANTED = parseInt(process.argv[3]||'12',10);
const startSeed = parseInt(process.argv[4]||'50000',10);
const endSeed = parseInt(process.argv[5]||'70000',10);
const appendPath = process.argv[6]; // if given, load+extend this file's seed list instead of starting fresh
const presets = [
  {minBust:0, maxBust:1, minPer:3, maxPer:5},
  {minBust:0, maxBust:1, minPer:4, maxPer:6},
  {minBust:1, maxBust:2, minPer:3, maxPer:5},
  {minBust:0, maxBust:0, minPer:3, maxPer:4},
];

let found = appendPath && require('fs').existsSync(appendPath) ? JSON.parse(require('fs').readFileSync(appendPath,'utf8')) : [];
const already = new Set(found.map(f=>f.seed));
let attempts=0;
for(let seed=startSeed; seed<endSeed && found.length<N_WANTED; seed++){
  if(already.has(seed)) continue;
  attempts++;
  const preset = presets[seed % presets.length];
  const opts = Object.assign({seed}, preset);
  const d = generateDraft(opts);
  const est = estimateCombos(d.subForm, d.cards);
  if(est===0 || est<CAP*2) continue; // want the tree genuinely bigger than the cap
  let rc; try{ rc = maxPossibleRating(d.cards, d.subForm); }catch(e){ continue; }
  if(rc===null) continue;
  const r = runMode(d.subForm, d.cards, rc, CAP, seed, null); // Off/pure divstatic
  if(r.capped){
    found.push({seed, opts, formName:d.formName, activeSlots:d.activeSlots, numCards:d.cards.length, est, rc, offBest:r.best, offNodes:r.nodes, offMs:r.ms});
    console.log(`HIT seed=${seed} form=${d.formName} cards=${d.cards.length} est=${est} rc=${rc} offBest=${r.best} ms=${r.ms}`);
  }
  if(attempts%500===0) console.log(`...scanned ${attempts}, found ${found.length}`);
}
require('fs').writeFileSync('/home/claude/test/hard_seeds.json', JSON.stringify(found,null,2));
console.log(`Done. ${found.length} hard seeds saved to hard_seeds.json (cap=${CAP}, scanned ${attempts})`);
