'use strict';
const { generateDraft, estimateCombos } = require('./gendraft.js');
const { maxPossibleRating } = require('./engine.js');
const { buildResumableSolver } = require('./resumable_solve.js');

function mulberry32(seed){
  return function(){
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const divstaticSort = (list)=>{
  const natCount={}, clubCount={};
  for(const c of list){
    natCount[c.nation]=(natCount[c.nation]||0)+1;
    if(c.type==='normal') clubCount[c.club]=(clubCount[c.club]||0)+1;
  }
  return list.map(c=>{
    const natRarity = 1/(natCount[c.nation]||1);
    const clubRarity = c.type==='normal' ? 1/(clubCount[c.club]||1) : 0;
    return {c, score: c.rating + 0.4*natRarity + 0.4*clubRarity};
  }).sort((a,b)=>b.score-a.score).map(x=>x.c);
};
function pseudoRandomSort(seed){
  const rand = mulberry32(seed);
  return (list)=>{
    const a = list.slice();
    for(let i=a.length-1;i>0;i--){ const j=Math.floor(rand()*(i+1)); [a[i],a[j]]=[a[j],a[i]]; }
    return a;
  };
}

// mirrors mkPlan() in the HTML solver
function mkPlan(divFrac,nShuffles){
  const plan=divFrac>0?[{shuffle:false,frac:divFrac}]:[];
  const each=(1-divFrac)/nShuffles;
  for(let i=0;i<nShuffles;i++)plan.push({shuffle:true,frac:each});
  return plan;
}
const MODES = {
  off:      {label:'Off',      plan:null},
  light:    {label:'Light',    plan:[{shuffle:false,frac:.75},{shuffle:true,frac:.25}]},
  balanced: {label:'Balanced', plan:[{shuffle:false,frac:.5},{shuffle:true,frac:.5}]},
  multi4:   {label:'Multi4',   plan:mkPlan(.5,4)},
  fullrand: {label:'FullRandom', plan:[{shuffle:true,frac:1}]},
  multi6:   {label:'Multi6',   plan:mkPlan(.5,6)},
  multi8:   {label:'Multi8',   plan:mkPlan(.5,8)},
  multi16:  {label:'Multi16',  plan:mkPlan(.5,16)},
  aggr25:   {label:'Aggr25',   plan:mkPlan(.25,4)},
  aggr10:   {label:'Aggr10',   plan:mkPlan(.10,4)}
};

// Runs one mode's phase plan against a draft, total node budget `cap`. Mirrors solveWithDiversity
// exactly: phase 1 always divstatic-ordered (unless plan is null == pure Off), each subsequent
// phase is a FRESH root traversal with a different presort, seeded with the running best/bestXIs
// so pruning starts hot; we keep the best score seen across phases (ties don't need union here,
// we only need the score for this experiment, not the actual lineup list).
function runMode(form, cards, rc, cap, baseSeed, plan){
  if(!plan){
    const solve = buildResumableSolver({presortFn: divstaticSort});
    const t0=Date.now();
    const r = solve(form, cards, rc, cap, null, cap);
    return {best:r.best, nodes:r.nodes, capped:!r.done, ms:Date.now()-t0, phases:[{kind:'divstatic',budget:cap,nodes:r.nodes,best:r.best,capped:!r.done}]};
  }
  let best=-1, bestXIs=[], maxRating=-1, totalNodes=0, shufIdx=0, anyCapped=false;
  const phaseLog=[];
  const t0=Date.now();
  for(const ph of plan){
    const budget=Math.max(1,Math.round(cap*ph.frac));
    const presortFn = ph.shuffle ? pseudoRandomSort((baseSeed + 0x9E3779B1*(++shufIdx))>>>0) : divstaticSort;
    const solve = buildResumableSolver({presortFn});
    const checkpoint = {path:[], best, bestXIs, nodes:0, maxRating};
    const r = solve(form, cards, rc, budget, checkpoint, budget);
    totalNodes += r.nodes;
    const capped = !r.done;
    phaseLog.push({kind: ph.shuffle?'shuffle':'divstatic', budget, nodes:r.nodes, best:r.best, capped});
    if(r.best>best){ best=r.best; bestXIs=r.bestXIs; }
    if(r.maxRating>maxRating) maxRating=r.maxRating;
    if(!capped){ anyCapped=false; return {best, nodes:totalNodes, capped:false, ms:Date.now()-t0, phases:phaseLog, provenComplete:true}; }
    anyCapped=true;
  }
  return {best, nodes:totalNodes, capped:anyCapped, ms:Date.now()-t0, phases:phaseLog, provenComplete:false};
}

module.exports = { MODES, runMode, mkPlan, divstaticSort, pseudoRandomSort };
