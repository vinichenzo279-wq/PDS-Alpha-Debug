'use strict';
const fs = require('fs');
const { generateDraft } = require('./gendraft.js');
const { MODES, runMode } = require('./diversity_harness.js');

const CAP = parseInt(process.argv[2]||'2000000',10);
const outPath = process.argv[3] || '/home/claude/test/diversity_sweep.jsonl';
const startIdx = parseInt(process.argv[4]||'0',10);
const endIdx = parseInt(process.argv[5]||'999',10);
const allHardSeeds = JSON.parse(fs.readFileSync('/home/claude/test/hard_seeds.json','utf8'));
const hardSeeds = allHardSeeds.slice(startIdx, endIdx);

if(startIdx===0) fs.writeFileSync(outPath, '');
const modeNames = Object.keys(MODES);

for(const hs of hardSeeds){
  const d = generateDraft(hs.opts);
  const row = {seed: hs.seed, formName: hs.formName, numCards: hs.numCards, est: hs.est, rc: hs.rc, cap: CAP, modes:{}};
  for(const name of modeNames){
    const mode = MODES[name];
    const r = runMode(d.subForm, d.cards, hs.rc, CAP, hs.seed, mode.plan);
    row.modes[name] = {best:r.best, nodes:r.nodes, capped:r.capped, ms:r.ms, phases:r.phases};
  }
  const offBest = row.modes.off.best;
  const summary = modeNames.map(n=>{
    const b=row.modes[n].best;
    const tag = b>offBest?'+'+(b-offBest):(b<offBest?String(b-offBest):'=');
    return `${n}:${tag}`;
  }).join(' ');
  console.log(`seed=${hs.seed} form=${hs.formName} offBest=${offBest} | ${summary}`);
  fs.appendFileSync(outPath, JSON.stringify(row)+'\n');
}
console.log('Sweep done ->', outPath);
